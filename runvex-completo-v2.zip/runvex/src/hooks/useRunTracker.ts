import { useState, useEffect, useRef, useCallback } from 'react';
import * as Location from 'expo-location';
import { Pedometer } from 'expo-sensors';

export interface RunData {
  distanciaKm: number;
  tiempoSegundos: number;
  velocidadActual: number;
  velocidadPromedio: number;
  pasos: number;
  bpmSimulado: number;
  calorias: number;
  elevacion: number;
  coordenadas: { latitude: number; longitude: number; altitude?: number }[];
  corriendo: boolean;
}

export function useRunTracker() {
  const [datos, setDatos] = useState<RunData>({
    distanciaKm: 0, tiempoSegundos: 0, velocidadActual: 0,
    velocidadPromedio: 0, pasos: 0, bpmSimulado: 72,
    calorias: 0, elevacion: 0, coordenadas: [], corriendo: false,
  });

  const [permisoConcedido, setPermisoConcedido] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const locationSub = useRef<Location.LocationSubscription | null>(null);
  const pedometerSub = useRef<{ remove: () => void } | null>(null);
  const distanciaRef = useRef(0);
  const tiempoRef = useRef(0);
  const pasosRef = useRef(0);
  const coordsRef = useRef<{ latitude: number; longitude: number; altitude?: number }[]>([]);

  useEffect(() => {
    Location.requestForegroundPermissionsAsync().then(({ status }) => {
      setPermisoConcedido(status === 'granted');
    });
    return () => limpiar();
  }, []);

  const haversine = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a = Math.sin(dLat/2)**2 +
      Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  };

  const iniciarCarrera = useCallback(async () => {
    if (!permisoConcedido) {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      setPermisoConcedido(true);
    }

    // Reset state
    distanciaRef.current = 0;
    tiempoRef.current = 0;
    pasosRef.current = 0;
    coordsRef.current = [];
    setDatos(p => ({ ...p, distanciaKm:0, tiempoSegundos:0, pasos:0, calorias:0, coordenadas:[], corriendo:true }));

    // Timer de 1 segundo
    intervalRef.current = setInterval(() => {
      tiempoRef.current += 1;
      const bpm = 135 + Math.floor(Math.random() * 20 - 10);
      const dist = distanciaRef.current;
      const tiempo = tiempoRef.current;
      setDatos(prev => ({
        ...prev,
        tiempoSegundos: tiempo,
        bpmSimulado: bpm,
        velocidadPromedio: tiempo > 0 ? (dist / tiempo) * 3600 : 0,
        calorias: Math.floor(dist * 60),
      }));
    }, 1000);

    // GPS
    locationSub.current = await Location.watchPositionAsync(
      { accuracy: Location.Accuracy.BestForNavigation, distanceInterval: 5, timeInterval: 2000 },
      (loc) => {
        const { latitude, longitude, altitude, speed } = loc.coords;
        const prev = coordsRef.current;
        if (prev.length > 0) {
          const last = prev[prev.length - 1];
          const delta = haversine(last.latitude, last.longitude, latitude, longitude);
          if (delta > 0.003) distanciaRef.current += delta;
        }
        coordsRef.current = [...prev, { latitude, longitude, altitude: altitude ?? 0 }];
        setDatos(p => ({
          ...p,
          distanciaKm: distanciaRef.current,
          velocidadActual: speed ? speed * 3.6 : p.velocidadActual,
          coordenadas: coordsRef.current,
          corriendo: true,
        }));
      }
    );

    // Pedómetro
    const available = await Pedometer.isAvailableAsync();
    if (available) {
      pedometerSub.current = Pedometer.watchStepCount((r) => {
        pasosRef.current = r.steps;
        setDatos(p => ({ ...p, pasos: r.steps }));
      });
    }
  }, [permisoConcedido]);

  const pausarCarrera = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    locationSub.current?.remove();
    pedometerSub.current?.remove();
    setDatos(p => ({ ...p, corriendo: false }));
  }, []);

  const terminarCarrera = useCallback(() => {
    pausarCarrera();
    return {
      distanciaKm: distanciaRef.current,
      tiempoSegundos: tiempoRef.current,
      velocidadPromedio: tiempoRef.current > 0 ? (distanciaRef.current / tiempoRef.current) * 3600 : 0,
      pasos: pasosRef.current,
      calorias: Math.floor(distanciaRef.current * 60),
      coordenadas: coordsRef.current,
    };
  }, [pausarCarrera]);

  const limpiar = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    locationSub.current?.remove();
    pedometerSub.current?.remove();
  };

  return { datos, iniciarCarrera, pausarCarrera, terminarCarrera, permisoConcedido };
}

export function formatTiempo(seg: number): string {
  const m = Math.floor(seg / 60), s = seg % 60;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}

export function formatPace(distanciaKm: number, segundos: number): string {
  if (distanciaKm === 0) return '--:--';
  const ps = segundos / distanciaKm;
  return `${Math.floor(ps/60)}:${String(Math.floor(ps%60)).padStart(2,'0')} min/km`;
}

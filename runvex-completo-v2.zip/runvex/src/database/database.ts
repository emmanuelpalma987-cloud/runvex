import * as SQLite from 'expo-sqlite';

let db: SQLite.SQLiteDatabase | null = null;

export async function getDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (!db) {
    db = await SQLite.openDatabaseAsync('runvex.db');
    await initializeDatabase(db);
  }
  return db;
}

async function initializeDatabase(database: SQLite.SQLiteDatabase): Promise<void> {
  await database.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      apellidos TEXT NOT NULL,
      correo TEXT UNIQUE NOT NULL,
      usuario TEXT UNIQUE NOT NULL,
      contrasena TEXT NOT NULL,
      foto_perfil TEXT,
      racha INTEGER DEFAULT 0,
      fecha_registro TEXT DEFAULT (datetime('now')),
      ultima_sesion TEXT
    );

    CREATE TABLE IF NOT EXISTS carreras (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL,
      fecha TEXT DEFAULT (datetime('now')),
      distancia_km REAL NOT NULL DEFAULT 0,
      tiempo_segundos INTEGER NOT NULL DEFAULT 0,
      velocidad_promedio REAL DEFAULT 0,
      calorias INTEGER DEFAULT 0,
      pasos INTEGER DEFAULT 0,
      bpm_promedio INTEGER DEFAULT 0,
      bpm_maximo INTEGER DEFAULT 0,
      elevacion_m REAL DEFAULT 0,
      ruta_json TEXT,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS rutas_guardadas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL,
      nombre TEXT NOT NULL,
      distancia_km REAL NOT NULL,
      tiempo_estimado_min INTEGER NOT NULL,
      coordenadas_json TEXT NOT NULL,
      fecha_creacion TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sesion_activa (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      usuario_id INTEGER,
      token TEXT,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );
  `);
}

// ─── USUARIOS ───────────────────────────────────────────────
export async function crearUsuario(
  nombre: string,
  apellidos: string,
  correo: string,
  usuario: string,
  contrasena: string
): Promise<number> {
  const database = await getDatabase();
  const result = await database.runAsync(
    `INSERT INTO usuarios (nombre, apellidos, correo, usuario, contrasena) VALUES (?, ?, ?, ?, ?)`,
    [nombre, apellidos, correo, usuario, contrasena]
  );
  return result.lastInsertRowId;
}

export async function loginUsuario(usuario: string, contrasena: string): Promise<any | null> {
  const database = await getDatabase();
  const row = await database.getFirstAsync<any>(
    `SELECT * FROM usuarios WHERE (usuario = ? OR correo = ?) AND contrasena = ?`,
    [usuario, usuario, contrasena]
  );
  if (row) {
    await database.runAsync(
      `INSERT OR REPLACE INTO sesion_activa (id, usuario_id, token) VALUES (1, ?, ?)`,
      [row.id, `token_${Date.now()}`]
    );
    await database.runAsync(
      `UPDATE usuarios SET ultima_sesion = datetime('now') WHERE id = ?`,
      [row.id]
    );
  }
  return row;
}

export async function obtenerSesionActiva(): Promise<any | null> {
  const database = await getDatabase();
  return await database.getFirstAsync<any>(
    `SELECT u.* FROM sesion_activa s JOIN usuarios u ON s.usuario_id = u.id WHERE s.id = 1`
  );
}

export async function cerrarSesion(): Promise<void> {
  const database = await getDatabase();
  await database.runAsync(`DELETE FROM sesion_activa WHERE id = 1`);
}

export async function actualizarUsuario(
  id: number,
  datos: Partial<{ nombre: string; apellidos: string; correo: string; usuario: string; foto_perfil: string }>
): Promise<void> {
  const database = await getDatabase();
  const campos = Object.keys(datos).map(k => `${k} = ?`).join(', ');
  const valores = [...Object.values(datos), id];
  await database.runAsync(`UPDATE usuarios SET ${campos} WHERE id = ?`, valores);
}

export async function actualizarRacha(id: number, racha: number): Promise<void> {
  const database = await getDatabase();
  await database.runAsync(`UPDATE usuarios SET racha = ? WHERE id = ?`, [racha, id]);
}

// ─── CARRERAS ───────────────────────────────────────────────
export interface Carrera {
  usuario_id: number;
  distancia_km: number;
  tiempo_segundos: number;
  velocidad_promedio: number;
  calorias: number;
  pasos: number;
  bpm_promedio: number;
  bpm_maximo: number;
  elevacion_m: number;
  ruta_json: string;
}

export async function guardarCarrera(carrera: Carrera): Promise<number> {
  const database = await getDatabase();
  const result = await database.runAsync(
    `INSERT INTO carreras
     (usuario_id, distancia_km, tiempo_segundos, velocidad_promedio,
      calorias, pasos, bpm_promedio, bpm_maximo, elevacion_m, ruta_json)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      carrera.usuario_id, carrera.distancia_km, carrera.tiempo_segundos,
      carrera.velocidad_promedio, carrera.calorias, carrera.pasos,
      carrera.bpm_promedio, carrera.bpm_maximo, carrera.elevacion_m, carrera.ruta_json,
    ]
  );
  return result.lastInsertRowId;
}

export async function obtenerCarrerasUsuario(usuarioId: number): Promise<any[]> {
  const database = await getDatabase();
  return await database.getAllAsync<any>(
    `SELECT * FROM carreras WHERE usuario_id = ? ORDER BY fecha DESC`, [usuarioId]
  );
}

export async function obtenerUltimaCarrera(usuarioId: number): Promise<any | null> {
  const database = await getDatabase();
  return await database.getFirstAsync<any>(
    `SELECT * FROM carreras WHERE usuario_id = ? ORDER BY fecha DESC LIMIT 1`, [usuarioId]
  );
}

// ─── RUTAS ──────────────────────────────────────────────────
export async function guardarRuta(
  usuarioId: number, nombre: string, distanciaKm: number,
  tiempoEstimadoMin: number, coordenadas: any[]
): Promise<number> {
  const database = await getDatabase();
  const result = await database.runAsync(
    `INSERT INTO rutas_guardadas (usuario_id, nombre, distancia_km, tiempo_estimado_min, coordenadas_json)
     VALUES (?, ?, ?, ?, ?)`,
    [usuarioId, nombre, distanciaKm, tiempoEstimadoMin, JSON.stringify(coordenadas)]
  );
  return result.lastInsertRowId;
}

export async function obtenerRutasUsuario(usuarioId: number): Promise<any[]> {
  const database = await getDatabase();
  return await database.getAllAsync<any>(
    `SELECT * FROM rutas_guardadas WHERE usuario_id = ? ORDER BY fecha_creacion DESC`, [usuarioId]
  );
}

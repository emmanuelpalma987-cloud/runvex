# 🏃 RUNVEX — Guía de instalación (SDK 54)

## Requisitos
- Node.js v20+ → https://nodejs.org
- App **Expo Go** (SDK 54) en tu teléfono:
  - Android: Play Store → "Expo Go"
  - iOS: App Store → "Expo Go"
- PC y teléfono en la **misma red WiFi**

---

## Pasos para correr la app

### 1. Abrir terminal dentro de la carpeta `runvex`

### 2. Instalar dependencias
```bash
npm install
```

### 3. Iniciar la app
```bash
npx expo start --clear
```

### 4. Escanear el QR
- **Android:** Expo Go → "Scan QR code"
- **iOS:** Cámara → apunta al QR → toca el banner

---

## Si hay errores

### Error de peer deps:
```bash
npm install --legacy-peer-deps
```

### Limpiar caché completo:
```bash
npx expo start --clear
```

### Si el mapa no carga en Android:
Es normal en Expo Go — el mapa aparece como cuadrícula gris pero funciona con ubicación real.

---

## Pantallas disponibles
| Pantalla | Ruta |
|---|---|
| Bienvenida | `/auth` |
| Login | `/auth/login` |
| Registro | `/auth/registro` |
| Recuperar contraseña | `/auth/recuperar` |
| Dashboard | `/(tabs)/home` |
| Modo Carrera | `/(tabs)/carrera` |
| Resultados | `/(tabs)/resultados` |
| Rutas | `/(tabs)/rutas` |
| Perfil | `/(tabs)/perfil` |

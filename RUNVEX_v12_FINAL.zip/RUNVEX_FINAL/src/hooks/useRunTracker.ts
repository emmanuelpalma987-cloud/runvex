/**
 * useRunTracker v11 — SDK 54, React 19, RN 0.79
 *
 * SENSORES:
 *  - expo-location  → GPS: distancia (Haversine), velocidad EMA, elevación suavizada
 *  - expo-sensors Pedometer  → pasos nativos del hardware (prioridad máxima)
 *  - expo-sensors Accelerometer → cadencia (pasos/min) + pasos de respaldo
 *
 * BPM   : estimación fisiológica por zonas, ramp rate 1.5 bpm/s
 * KCAL  : fórmula MET × peso × horas
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import * as Location from 'expo-location';
import { Pedometer, Accelerometer } from 'expo-sensors';
import { Platform, PermissionsAndroid } from 'react-native';

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface RunData {
  distanciaKm: number;
  tiempoSegundos: number;
  velocidadActual: number;
  velocidadPromedio: number;
  pasos: number;
  cadencia: number;
  bpm: number;
  bpmMaximo: number;
  calorias: number;
  elevacionAcumulada: number;
  altitudActual: number;
  pace: number;
  coordenadas: { latitude: number; longitude: number; altitude: number }[];
  corriendo: boolean;
  pausado: boolean;
}

// ─── Constantes ───────────────────────────────────────────────────────────────

const BPM_BASE = 68;
const BPM_MAX  = 185;
const BPM_RAMP = 1.5;
const PESO_KG  = 70;

// ─── Biomecánica de zancada ───────────────────────────────────────────────────

function longitudZancada(vel: number): number {
  if (vel <= 0)  return 0.72;
  if (vel < 3)   return 0.40 + (vel / 3) * 0.08;
  if (vel < 6)   return 0.48 + ((vel - 3) / 3) * 0.17;
  if (vel < 9)   return 0.65 + ((vel - 6) / 3) * 0.15;
  if (vel < 12)  return 0.80 + ((vel - 9) / 3) * 0.15;
  return Math.min(1.20, 0.95 + ((vel - 12) / 6) * 0.25);
}

function pasosGPS(distM: number, vel: number): number {
  return distM <= 0 ? 0 : Math.round(distM / longitudZancada(vel));
}

// ─── Haversine ────────────────────────────────────────────────────────────────

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R    = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a    = Math.sin(dLat / 2) ** 2
    + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180)
    * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ─── BPM ─────────────────────────────────────────────────────────────────────

function estimarBPM(vel: number, t: number, prev: number): number {
  if (t === 0) return BPM_BASE;
  if (vel < 0.5) {
    if (t < 30) {
      const obj = BPM_BASE + Math.min(t, 30) * 0.8;
      const d = obj - prev;
      return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(prev + Math.sign(d) * Math.min(Math.abs(d), BPM_RAMP))));
    }
    return prev > BPM_BASE + 10 ? Math.max(BPM_BASE + 10, Math.round(prev - BPM_RAMP * 0.5)) : prev;
  }
  const pct = vel < 6  ? 0.55 + (vel / 6) * 0.10
    : vel < 9  ? 0.65 + ((vel - 6) / 3) * 0.10
    : vel < 12 ? 0.75 + ((vel - 9) / 3) * 0.10
    : 0.85 + Math.min((vel - 12) / 8, 1) * 0.10;
  const obj  = Math.round(BPM_BASE + pct * (BPM_MAX - BPM_BASE));
  const var3 = (Math.floor(Math.random() * 7) - 3) * 0.3;
  const d    = obj - prev;
  return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(prev + Math.sign(d) * Math.min(Math.abs(d), BPM_RAMP) + var3)));
}

// ─── Calorías MET ─────────────────────────────────────────────────────────────

function calcCalorias(distKm: number, seg: number, vel: number): number {
  const met = vel >= 16 ? 16 : vel >= 14 ? 14.5 : vel >= 12 ? 13.5
    : vel >= 10 ? 11.5 : vel >= 8 ? 10 : vel >= 6 ? 8 : 4.5;
  return Math.round(met * PESO_KG * (seg / 3600));
}

// ─── Permisos Android ─────────────────────────────────────────────────────────

async function pedirPermisos(): Promise<void> {
  if (Platform.OS !== 'android') return;
  try {
    const lista: string[] = [
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
    ];
    if (Platform.Version >= 29) lista.push('android.permission.ACTIVITY_RECOGNITION');
    await PermissionsAndroid.requestMultiple(lista as any);
  } catch { /* silencioso */ }
}

// ─── Estado inicial ───────────────────────────────────────────────────────────

const INICIAL: RunData = {
  distanciaKm: 0, tiempoSegundos: 0,
  velocidadActual: 0, velocidadPromedio: 0,
  pasos: 0, cadencia: 0,
  bpm: 0, bpmMaximo: 0,
  calorias: 0, elevacionAcumulada: 0, altitudActual: 0,
  pace: 0, coordenadas: [], corriendo: false, pausado: false,
};

// ─── Hook ────────────────────────────────────────────────────────────────────

export function useRunTracker() {
  const [datos,   setDatos]   = useState<RunData>(INICIAL);
  const [permGPS, setPermGPS] = useState(false);

  const timerRef   = useRef<ReturnType<typeof setInterval> | null>(null);
  const locRef     = useRef<Location.LocationSubscription | null>(null);
  const pedRef     = useRef<{ remove(): void } | null>(null);
  const accelRef   = useRef<{ remove(): void } | null>(null);

  // flags
  const pedOK   = useRef(false);
  const accelOK = useRef(false);

  // acumuladores
  const distM    = useRef(0);
  const seg      = useRef(0);
  const pasosR   = useRef(0);
  const elevR    = useRef(0);
  const velR     = useRef(0);
  const bpmR     = useRef(BPM_BASE);
  const bpmMaxR  = useRef(0);
  const coordsR  = useRef<{ latitude: number; longitude: number; altitude: number }[]>([]);
  const altBuf   = useRef<number[]>([]);
  const prevAlt  = useRef(0);

  // acelerómetro
  const magBuf       = useRef<number[]>([]);
  const lastPeak     = useRef(0);
  const prevMag      = useRef(0);
  const accelPasos   = useRef(0);
  const cadenciaR    = useRef(0);
  const stepTimes    = useRef<number[]>([]);

  // pedómetro: base para delta relativo
  const pedBase  = useRef(0);
  const pedFirst = useRef(true);

  // ── Permisos iniciales ────────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      await pedirPermisos();
      const { status } = await Location.requestForegroundPermissionsAsync();
      setPermGPS(status === 'granted');
    })();
    return () => _stop();
  }, []);

  // ── Pedómetro nativo ──────────────────────────────────────────────────────
  const intentarPedometro = useCallback(async () => {
    try {
      const ok = await Pedometer.isAvailableAsync();
      if (!ok) return;
      pedFirst.current = true;
      pedBase.current  = 0;

      pedRef.current = Pedometer.watchStepCount(r => {
        if (r.steps <= 0) return;
        pedOK.current = true;
        if (pedFirst.current) {
          pedBase.current  = r.steps;
          pedFirst.current = false;
        }
        const delta = Math.max(0, r.steps - pedBase.current);
        pasosR.current = delta;
        setDatos(p => ({ ...p, pasos: delta }));
      });

      // Sin eventos en 8 s → no hay hardware
      setTimeout(() => {
        if (!pedOK.current) { pedRef.current?.remove(); pedRef.current = null; }
      }, 8000);
    } catch { /* sin pedómetro */ }
  }, []);

  // ── Acelerómetro ─────────────────────────────────────────────────────────
  const iniciarAcelerometro = useCallback(() => {
    accelPasos.current = 0;
    lastPeak.current   = 0;
    prevMag.current    = 0;
    stepTimes.current  = [];
    magBuf.current     = [];

    try {
      Accelerometer.setUpdateInterval(20);
      accelRef.current = Accelerometer.addListener(({ x, y, z }) => {
        accelOK.current = true;
        const mag = Math.sqrt(x * x + y * y + z * z);
        magBuf.current.push(mag);
        if (magBuf.current.length > 60) magBuf.current.shift();

        const sorted  = [...magBuf.current].sort((a, b) => a - b);
        const mediana = sorted[Math.floor(sorted.length / 2)];
        const umbral  = mediana + 0.30;
        const ahora   = Date.now();

        if (mag > umbral && prevMag.current <= umbral && ahora - lastPeak.current > 260) {
          lastPeak.current = ahora;
          accelPasos.current += 1;

          if (!pedOK.current) {
            pasosR.current = accelPasos.current;
            setDatos(p => ({ ...p, pasos: accelPasos.current }));
          }

          // Cadencia — ventana 10 s
          stepTimes.current.push(ahora);
          stepTimes.current = stepTimes.current.filter(t => ahora - t < 10000);
          if (stepTimes.current.length >= 4) {
            const ppm = Math.min(220, Math.round(stepTimes.current.length / 10 * 60));
            cadenciaR.current = ppm;
            setDatos(p => ({ ...p, cadencia: ppm }));
          }
        }
        prevMag.current = mag;
      });
    } catch { /* sin acelerómetro */ }
  }, []);

  // ── GPS ───────────────────────────────────────────────────────────────────
  const suscribirGPS = useCallback(async () => {
    try {
      locRef.current = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.BestForNavigation, distanceInterval: 2, timeInterval: 1000 },
        loc => {
          const { latitude, longitude, altitude, speed } = loc.coords;
          const alt = altitude ?? 0;

          // Velocidad EMA
          const gpsVel = speed != null && speed > 0.2 ? speed * 3.6 : 0;
          velR.current = velR.current === 0 ? gpsVel : velR.current * 0.6 + gpsVel * 0.4;

          // Distancia Haversine con filtro de ruido
          const prev = coordsR.current;
          let delta  = 0;
          if (prev.length > 0) {
            const last = prev[prev.length - 1];
            const d = haversine(last.latitude, last.longitude, latitude, longitude);
            if (d > 1 && d < 80) { distM.current += d; delta = d; }
          }

          // Pasos GPS — sólo si sin sensores nativos
          if (!pedOK.current && !accelOK.current && delta > 0) {
            const np = pasosGPS(distM.current, velR.current);
            pasosR.current = np;
            setDatos(p => ({ ...p, pasos: np }));
          }

          // Elevación — buffer 5 lecturas
          altBuf.current.push(alt);
          if (altBuf.current.length > 5) altBuf.current.shift();
          const smooth = altBuf.current.reduce((a, b) => a + b, 0) / altBuf.current.length;
          if (altBuf.current.length >= 3) {
            const dif = smooth - prevAlt.current;
            if (dif > 0.5) elevR.current += dif;
            prevAlt.current = smooth;
          }

          coordsR.current = [...prev, { latitude, longitude, altitude: smooth }];

          setDatos(p => ({
            ...p,
            distanciaKm:        parseFloat((distM.current / 1000).toFixed(4)),
            velocidadActual:    parseFloat(velR.current.toFixed(1)),
            elevacionAcumulada: parseFloat(elevR.current.toFixed(1)),
            altitudActual:      parseFloat(smooth.toFixed(1)),
            coordenadas:        coordsR.current,
          }));
        }
      );
    } catch (e) { console.warn('[GPS]', e); }
  }, []);

  // ── Timer 1 s ─────────────────────────────────────────────────────────────
  const iniciarTimer = useCallback(() => {
    timerRef.current = setInterval(() => {
      seg.current += 1;
      const t  = seg.current;
      const dK = distM.current / 1000;
      const v  = velR.current;

      const bpm = estimarBPM(v, t, bpmR.current);
      bpmR.current = bpm;
      if (bpm > bpmMaxR.current) bpmMaxR.current = bpm;

      const pace  = dK > 0.001 ? t / dK : 0;
      const vProm = t > 0 ? (dK / t) * 3600 : 0;
      const pasos = pedOK.current ? pasosR.current
        : accelOK.current ? accelPasos.current
        : pasosGPS(distM.current, v);

      setDatos(p => ({
        ...p,
        tiempoSegundos:    t,
        bpm,
        bpmMaximo:         bpmMaxR.current,
        calorias:          calcCalorias(dK, t, v),
        velocidadPromedio: parseFloat(vProm.toFixed(2)),
        pace,
        pasos,
        cadencia:          cadenciaR.current,
      }));
    }, 1000);
  }, []);

  // ── INICIAR ───────────────────────────────────────────────────────────────
  const iniciarCarrera = useCallback(async () => {
    if (!permGPS) {
      await pedirPermisos();
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      setPermGPS(true);
    }
    // Reset total
    distM.current  = 0; seg.current  = 0; pasosR.current = 0;
    elevR.current  = 0; velR.current = 0; bpmR.current   = BPM_BASE;
    bpmMaxR.current = 0; coordsR.current = []; altBuf.current = [];
    prevAlt.current = 0; pedOK.current = false; accelOK.current = false;
    accelPasos.current = 0; cadenciaR.current = 0;

    setDatos({ ...INICIAL, bpm: BPM_BASE, corriendo: true });
    iniciarTimer();
    await suscribirGPS();
    iniciarAcelerometro();
    await intentarPedometro();
  }, [permGPS, iniciarTimer, suscribirGPS, iniciarAcelerometro, intentarPedometro]);

  // ── PAUSAR ────────────────────────────────────────────────────────────────
  const pausarCarrera = useCallback(() => {
    _stop();
    setDatos(p => ({ ...p, corriendo: false, pausado: true }));
  }, []);

  // ── REANUDAR ──────────────────────────────────────────────────────────────
  const reanudarCarrera = useCallback(async () => {
    if (!permGPS) return;
    pedOK.current = false; accelOK.current = false;
    setDatos(p => ({ ...p, corriendo: true, pausado: false }));
    iniciarTimer();
    await suscribirGPS();
    iniciarAcelerometro();
    await intentarPedometro();
  }, [permGPS, iniciarTimer, suscribirGPS, iniciarAcelerometro, intentarPedometro]);

  // ── TERMINAR ──────────────────────────────────────────────────────────────
  const terminarCarrera = useCallback(() => {
    _stop();
    const dK    = distM.current / 1000;
    const pasos = pedOK.current ? pasosR.current
      : accelOK.current ? accelPasos.current
      : pasosGPS(distM.current, velR.current);

    const res = {
      distanciaKm:       dK,
      tiempoSegundos:    seg.current,
      velocidadPromedio: seg.current > 0 ? (dK / seg.current) * 3600 : 0,
      pasos,
      cadencia:          cadenciaR.current,
      calorias:          calcCalorias(dK, seg.current, velR.current),
      bpmPromedio:       bpmR.current,
      bpmMaximo:         bpmMaxR.current,
      elevacionM:        elevR.current,
      coordenadas:       coordsR.current,
    };
    setDatos(p => ({ ...p, corriendo: false, pausado: false }));
    return res;
  }, []);

  // ── Limpieza ──────────────────────────────────────────────────────────────
  function _stop() {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    locRef.current?.remove();   locRef.current   = null;
    pedRef.current?.remove();   pedRef.current   = null;
    accelRef.current?.remove(); accelRef.current = null;
  }

  return { datos, iniciarCarrera, pausarCarrera, reanudarCarrera, terminarCarrera, permGPS };
}

// ─── Formatters ───────────────────────────────────────────────────────────────

export const formatTiempo = (s: number): string => {
  if (s < 0) s = 0;
  const h   = Math.floor(s / 3600);
  const m   = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
  return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
};

export const formatPace = (p: number): string => {
  if (!p || p <= 0 || !isFinite(p)) return '--:--';
  return `${Math.floor(p / 60)}:${String(Math.floor(p % 60)).padStart(2,'0')} /km`;
};

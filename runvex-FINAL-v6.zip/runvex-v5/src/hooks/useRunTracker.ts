/**
 * useRunTracker — funciona en Expo Go sin hardware especial
 *
 * PASOS: calculados desde distancia GPS real
 *   - Longitud de zancada promedio: ~0.78 m (varía con velocidad)
 *   - Se actualiza cada vez que llega un punto GPS nuevo
 *   - Intenta Pedometer real primero; si no responde en 5s usa GPS
 *
 * ELEVACIÓN: calculada desde altitude del GPS
 *   - Se acumula solo cuando hay subida real > 0.5 m entre lecturas
 *   - Se filtra ruido con promedio móvil de 3 lecturas
 *
 * BPM: estimación fisiológica por zonas FC
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import * as Location from 'expo-location';
import { Pedometer } from 'expo-sensors';
import { Platform, PermissionsAndroid } from 'react-native';

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface RunData {
  distanciaKm: number;
  tiempoSegundos: number;
  velocidadActual: number;
  velocidadPromedio: number;
  pasos: number;
  bpm: number;
  bpmMaximo: number;
  calorias: number;
  elevacionAcumulada: number;
  altitudActual: number;
  pace: number;
  coordenadas: { latitude: number; longitude: number; altitude: number }[];
  corriendo: boolean;
  pausado: boolean;
}

// ─── Constantes ───────────────────────────────────────────────────────────────

const BPM_BASE = 68;
const BPM_MAX  = 185;
const BPM_RAMP = 1.5;

/**
 * Longitud de zancada en metros según velocidad (km/h)
 * Basado en estudios biomecánicos de carrera:
 * 6 km/h  → ~0.65 m/paso
 * 9 km/h  → ~0.80 m/paso
 * 12 km/h → ~0.95 m/paso
 * 15 km/h → ~1.10 m/paso
 */
function longitudZancada(velKmh: number): number {
  if (velKmh <= 0) return 0.75;
  if (velKmh < 6)  return 0.55 + (velKmh / 6) * 0.10;
  if (velKmh < 9)  return 0.65 + ((velKmh - 6) / 3) * 0.15;
  if (velKmh < 12) return 0.80 + ((velKmh - 9) / 3) * 0.15;
  return Math.min(1.20, 0.95 + ((velKmh - 12) / 6) * 0.25);
}

/** Pasos desde distancia en metros */
function pasosDesdeDistancia(distanciaM: number, velKmh: number): number {
  const zancada = longitudZancada(velKmh);
  return Math.round(distanciaM / zancada);
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000; // metros
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 +
    Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function estimarBPM(vel: number, t: number, prev: number): number {
  if (t === 0 || vel < 1)
    return prev > BPM_BASE ? Math.max(BPM_BASE, Math.round(prev - BPM_RAMP)) : BPM_BASE;
  const pct = vel < 6  ? 0.58 + (vel/6)*0.07
            : vel < 9  ? 0.65 + ((vel-6)/3)*0.10
            : vel < 12 ? 0.75 + ((vel-9)/3)*0.10
            :             0.85 + Math.min((vel-12)/8,1)*0.10;
  const obj  = Math.round(BPM_BASE + pct * (BPM_MAX - BPM_BASE));
  const vari = Math.floor(Math.random() * 7) - 3;
  const delta = obj - prev;
  const paso  = Math.sign(delta) * Math.min(Math.abs(delta), BPM_RAMP);
  return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(prev + paso + vari * 0.3)));
}

function calcCalorias(dist: number, t: number, vel: number): number {
  const peso = 70;
  const met  = vel >= 12 ? 13.5 : vel >= 10 ? 11.5 : vel >= 8 ? 10 : vel >= 6 ? 8 : 6;
  return Math.round(met * peso * (t / 3600));
}

async function pedirPermisoAndroid(): Promise<void> {
  if (Platform.OS !== 'android' || Platform.Version < 29) return;
  try {
    await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACTIVITY_RECOGNITION,
      {
        title: 'Permiso de actividad',
        message: 'RUNVEX necesita acceder al sensor de pasos.',
        buttonPositive: 'Permitir',
        buttonNegative: 'Cancelar',
      }
    );
  } catch {}
}

// ─── Estado inicial ───────────────────────────────────────────────────────────

const INICIAL: RunData = {
  distanciaKm: 0, tiempoSegundos: 0,
  velocidadActual: 0, velocidadPromedio: 0,
  pasos: 0, bpm: 0, bpmMaximo: 0,
  calorias: 0, elevacionAcumulada: 0, altitudActual: 0,
  pace: 0, coordenadas: [], corriendo: false, pausado: false,
};

// ─── Hook principal ───────────────────────────────────────────────────────────

export function useRunTracker() {
  const [datos, setDatos]   = useState<RunData>(INICIAL);
  const [permGPS, setPermGPS] = useState(false);

  const timer   = useRef<ReturnType<typeof setInterval>|null>(null);
  const locSub  = useRef<Location.LocationSubscription|null>(null);
  const pedSub  = useRef<{remove:()=>void}|null>(null);
  const pedActivo = useRef(false);  // el sensor real está respondiendo

  // Acumuladores internos (refs para evitar stale closures)
  const distM      = useRef(0);    // distancia en METROS
  const tiempo     = useRef(0);
  const pasosRef   = useRef(0);
  const elevAcum   = useRef(0);
  const velRef     = useRef(0);
  const bpmRef     = useRef(0);
  const bpmMaxRef  = useRef(0);
  const coords     = useRef<{latitude:number;longitude:number;altitude:number}[]>([]);

  // Buffer de altitudes para suavizar ruido GPS (últimas 4 lecturas)
  const altBuf = useRef<number[]>([]);

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      setPermGPS(status === 'granted');
      await pedirPermisoAndroid();
    })();
    return () => _stop();
  }, []);

  // ── Intentar suscribirse al pedómetro real ────────────────────────────────
  const intentarPedometro = useCallback(async () => {
    try {
      const avail = await Pedometer.isAvailableAsync();
      if (!avail) return;
      pedSub.current = Pedometer.watchStepCount(result => {
        if (result.steps > 0) {
          pedActivo.current = true;
          pasosRef.current  = result.steps;
          setDatos(p => ({ ...p, pasos: result.steps }));
        }
      });
      // Si en 6 segundos el sensor no disparó, lo marcamos como no activo
      setTimeout(() => {
        if (!pedActivo.current) {
          pedSub.current?.remove();
          pedSub.current = null;
        }
      }, 6000);
    } catch {}
  }, []);

  // ── Suscripción GPS ───────────────────────────────────────────────────────
  const suscribirGPS = useCallback(async () => {
    locSub.current = await Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.BestForNavigation,
        distanceInterval: 2,   // cada 2 metros
        timeInterval: 1000,    // o cada segundo
      },
      loc => {
        const { latitude, longitude, altitude, speed } = loc.coords;
        const alt = altitude ?? 0;

        // ── Velocidad suavizada ──
        const velGps = speed != null && speed > 0.3 ? speed * 3.6 : 0;
        velRef.current = velRef.current === 0
          ? velGps
          : velRef.current * 0.6 + velGps * 0.4;

        // ── Distancia ──
        const prev = coords.current;
        let deltaM = 0;
        if (prev.length > 0) {
          const last = prev[prev.length - 1];
          const d = haversine(last.latitude, last.longitude, latitude, longitude);
          // Filtro: entre 1m y 40m por tick (evita ruido GPS y teleportaciones)
          if (d > 1 && d < 40) {
            distM.current += d;
            deltaM = d;
          }
        }

        // ── PASOS desde GPS (si el sensor no está activo) ──
        if (!pedActivo.current && deltaM > 0) {
          const nuevos = pasosDesdeDistancia(distM.current, velRef.current);
          pasosRef.current = nuevos;
          setDatos(p => ({ ...p, pasos: nuevos }));
        }

        // ── Elevación con buffer de suavizado ──
        altBuf.current.push(alt);
        if (altBuf.current.length > 4) altBuf.current.shift();
        const altSmooth = altBuf.current.reduce((a, b) => a + b, 0) / altBuf.current.length;

        if (altBuf.current.length >= 2) {
          const prevSmooth = altBuf.current.slice(0, -1).reduce((a,b)=>a+b,0) / (altBuf.current.length-1);
          const dif = altSmooth - prevSmooth;
          // Acumula solo subidas reales: dif > 0.5m filtrado
          if (dif > 0.5) {
            elevAcum.current += dif;
          }
        }

        coords.current = [...prev, { latitude, longitude, altitude: altSmooth }];

        setDatos(p => ({
          ...p,
          distanciaKm:      parseFloat((distM.current / 1000).toFixed(4)),
          velocidadActual:  parseFloat(velRef.current.toFixed(1)),
          elevacionAcumulada: parseFloat(elevAcum.current.toFixed(1)),
          altitudActual:    parseFloat(altSmooth.toFixed(1)),
          coordenadas:      coords.current,
        }));
      }
    );
  }, []);

  // ── Timer 1 segundo: tiempo, BPM, calorías, pace ─────────────────────────
  const iniciarTimer = useCallback(() => {
    timer.current = setInterval(() => {
      tiempo.current += 1;
      const t  = tiempo.current;
      const dK = distM.current / 1000;
      const v  = velRef.current;

      const bpm = estimarBPM(v, t, bpmRef.current);
      bpmRef.current = bpm;
      if (bpm > bpmMaxRef.current) bpmMaxRef.current = bpm;

      const pace  = dK > 0 && t > 0 ? t / dK : 0;
      const vProm = t > 0 ? (dK / t) * 3600 : 0;
      const cal   = calcCalorias(dK, t, v);

      setDatos(p => ({
        ...p,
        tiempoSegundos:    t,
        bpm,
        bpmMaximo:         bpmMaxRef.current,
        calorias:          cal,
        velocidadPromedio: parseFloat(vProm.toFixed(2)),
        pace,
        // Actualizar pasos también desde el timer si el sensor no está activo
        pasos: pedActivo.current ? pasosRef.current : pasosDesdeDistancia(distM.current, v),
      }));
    }, 1000);
  }, []);

  // ── INICIAR ───────────────────────────────────────────────────────────────
  const iniciarCarrera = useCallback(async () => {
    if (!permGPS) {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      setPermGPS(true);
    }

    // Reset
    distM.current    = 0;
    tiempo.current   = 0;
    pasosRef.current = 0;
    elevAcum.current = 0;
    velRef.current   = 0;
    bpmRef.current   = BPM_BASE;
    bpmMaxRef.current = 0;
    coords.current   = [];
    altBuf.current   = [];
    pedActivo.current = false;

    setDatos({ ...INICIAL, bpm: BPM_BASE, corriendo: true, pausado: false });

    iniciarTimer();
    await suscribirGPS();
    intentarPedometro();
  }, [permGPS, iniciarTimer, suscribirGPS, intentarPedometro]);

  // ── PAUSAR ────────────────────────────────────────────────────────────────
  const pausarCarrera = useCallback(() => {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    locSub.current?.remove();
    pedSub.current?.remove();
    setDatos(p => ({ ...p, corriendo: false, pausado: true }));
  }, []);

  // ── REANUDAR ──────────────────────────────────────────────────────────────
  const reanudarCarrera = useCallback(async () => {
    if (!permGPS) return;
    setDatos(p => ({ ...p, corriendo: true, pausado: false }));
    pedActivo.current = false; // reset para reintentar sensor
    iniciarTimer();
    await suscribirGPS();
    intentarPedometro();
  }, [permGPS, iniciarTimer, suscribirGPS, intentarPedometro]);

  // ── TERMINAR ──────────────────────────────────────────────────────────────
  const terminarCarrera = useCallback(() => {
    _stop();
    const dK = distM.current / 1000;
    const res = {
      distanciaKm:       dK,
      tiempoSegundos:    tiempo.current,
      velocidadPromedio: tiempo.current > 0 ? (dK / tiempo.current) * 3600 : 0,
      pasos:             pedActivo.current ? pasosRef.current : pasosDesdeDistancia(distM.current, velRef.current),
      calorias:          calcCalorias(dK, tiempo.current, velRef.current),
      bpmPromedio:       bpmRef.current,
      bpmMaximo:         bpmMaxRef.current,
      elevacionM:        elevAcum.current,
      coordenadas:       coords.current,
    };
    setDatos(p => ({ ...p, corriendo: false, pausado: false }));
    return res;
  }, []);

  function _stop() {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    locSub.current?.remove();
    pedSub.current?.remove();
  }

  return { datos, iniciarCarrera, pausarCarrera, reanudarCarrera, terminarCarrera, permGPS };
}

// ─── Formatters ───────────────────────────────────────────────────────────────

export const formatTiempo = (s: number) =>
  `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;

export const formatPace = (p: number) => {
  if (!p || p <= 0) return '--:--';
  return `${Math.floor(p/60)}:${String(Math.floor(p%60)).padStart(2,'0')} /km`;
};

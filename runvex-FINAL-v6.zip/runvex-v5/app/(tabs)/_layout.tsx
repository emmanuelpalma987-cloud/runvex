import { Tabs } from 'expo-router';
import { View, StyleSheet, Image } from 'react-native';

// Iconos SVG embebidos como imágenes base64 ligeras — misma estética plateada del diseño
const ICONS = {
  home: require('../../src/assets/icons/home.png'),
  rutas: require('../../src/assets/icons/rutas.png'),
  carrera: require('../../src/assets/icons/carrera.png'),
  resultados: require('../../src/assets/icons/resultados.png'),
  perfil: require('../../src/assets/icons/perfil.png'),
};

function TabIcon({ name, focused }: { name: keyof typeof ICONS; focused: boolean }) {
  return (
    <View style={[t.wrap, focused && t.active]}>
      <Image
        source={ICONS[name]}
        style={[t.img, focused ? t.imgActive : t.imgInactive]}
        resizeMode="contain"
      />
      {focused && <View style={t.dot} />}
    </View>
  );
}

const t = StyleSheet.create({
  wrap: {
    width: 52, height: 44, alignItems: 'center', justifyContent: 'center',
    borderRadius: 14,
  },
  active: {
    backgroundColor: 'rgba(0,200,255,0.12)',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.3)',
  },
  img: { width: 30, height: 30 },
  imgActive: { tintColor: '#00C8FF' },
  imgInactive: { tintColor: 'rgba(255,255,255,0.5)' },
  dot: {
    position: 'absolute', bottom: 2, width: 4, height: 4,
    borderRadius: 2, backgroundColor: '#00C8FF',
  },
});

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#050A15',
          borderTopColor: 'rgba(0,200,255,0.2)',
          borderTopWidth: 1,
          height: 68,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: {
          fontFamily: 'DaysOne_400Regular',
          fontSize: 9,
          letterSpacing: 0.5,
        },
        tabBarActiveTintColor: '#00C8FF',
        tabBarInactiveTintColor: 'rgba(255,255,255,0.4)',
      }}
    >
      <Tabs.Screen name="home"
        options={{ title: 'INICIO', tabBarIcon: ({ focused }) => <TabIcon name="home" focused={focused} /> }} />
      <Tabs.Screen name="rutas"
        options={{ title: 'RUTAS', tabBarIcon: ({ focused }) => <TabIcon name="rutas" focused={focused} /> }} />
      <Tabs.Screen name="carrera"
        options={{ title: 'CARRERA', tabBarIcon: ({ focused }) => <TabIcon name="carrera" focused={focused} /> }} />
      <Tabs.Screen name="resultados"
        options={{ title: 'STATS', tabBarIcon: ({ focused }) => <TabIcon name="resultados" focused={focused} /> }} />
      <Tabs.Screen name="perfil"
        options={{ title: 'PERFIL', tabBarIcon: ({ focused }) => <TabIcon name="perfil" focused={focused} /> }} />
    </Tabs>
  );
}

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, StatusBar,
  TouchableOpacity, ScrollView, Alert, TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Polyline, PROVIDER_DEFAULT } from 'react-native-maps';
import * as Location from 'expo-location';
import { useFocusEffect } from 'expo-router';
import { useAuth } from '../../src/hooks/useAuth';
import { guardarRuta, obtenerRutas, eliminarRuta } from '../../src/database/database';

interface Coord { latitude: number; longitude: number; }

function haversine(a: Coord, b: Coord) {
  const R = 6371;
  const dLat = (b.latitude - a.latitude) * Math.PI / 180;
  const dLon = (b.longitude - a.longitude) * Math.PI / 180;
  const x = Math.sin(dLat/2)**2 + Math.cos(a.latitude*Math.PI/180)*Math.cos(b.latitude*Math.PI/180)*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
}

function calcDist(coords: Coord[]) {
  let d = 0;
  for (let i = 1; i < coords.length; i++) d += haversine(coords[i-1], coords[i]);
  return d;
}

const PACE_KMH = 9; // velocidad estimada 9 km/h

export default function RutasScreen() {
  const { usuario } = useAuth();
  const mapRef = useRef<MapView>(null);
  const [rutasGuardadas, setRutasGuardadas] = useState<any[]>([]);
  const [puntos, setPuntos] = useState<Coord[]>([]);
  const [region, setRegion] = useState({
    latitude: 19.2869, longitude: -99.6531, latitudeDelta: 0.008, longitudeDelta: 0.008,
  });
  const [rutaVista, setRutaVista] = useState<any | null>(null);
  const [nombreRuta, setNombreRuta] = useState('');
  const [modo, setModo] = useState<'crear' | 'ver'>('crear');

  useFocusEffect(useCallback(() => {
    loadRutas();
  }, [usuario]));

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({});
        setRegion({
          latitude: loc.coords.latitude, longitude: loc.coords.longitude,
          latitudeDelta: 0.008, longitudeDelta: 0.008,
        });
      }
    })();
  }, []);

  const loadRutas = async () => {
    if (usuario?.id) {
      const r = await obtenerRutas(usuario.id).catch(() => []);
      setRutasGuardadas(r);
    }
  };

  const handleMapPress = (e: any) => {
    if (modo !== 'crear') return;
    const coord: Coord = e.nativeEvent.coordinate;
    setPuntos(prev => [...prev, coord]);
  };

  const deshacerUltimo = () => {
    setPuntos(prev => prev.slice(0, -1));
  };

  const limpiarRuta = () => {
    setPuntos([]);
    setNombreRuta('');
  };

  const distKm = calcDist(puntos);
  const tiempoMin = Math.round((distKm / PACE_KMH) * 60);

  const guardar = async () => {
    if (puntos.length < 2) {
      Alert.alert('Ruta incompleta', 'Agrega al menos 2 puntos en el mapa.');
      return;
    }
    const nombre = nombreRuta.trim() || `Mi ruta ${rutasGuardadas.length + 1}`;
    if (!usuario?.id) return;
    await guardarRuta(usuario.id, nombre, distKm, tiempoMin, puntos);
    Alert.alert('✅ Guardada', `Ruta "${nombre}" guardada.`);
    limpiarRuta();
    loadRutas();
  };

  const verRuta = (ruta: any) => {
    const coords: Coord[] = JSON.parse(ruta.coordenadas_json);
    setRutaVista(ruta);
    setModo('ver');
    if (coords.length > 0) {
      const lats = coords.map(c => c.latitude);
      const lons = coords.map(c => c.longitude);
      const midLat = (Math.max(...lats) + Math.min(...lats)) / 2;
      const midLon = (Math.max(...lons) + Math.min(...lons)) / 2;
      const deltaLat = (Math.max(...lats) - Math.min(...lats)) * 1.5 + 0.004;
      const deltaLon = (Math.max(...lons) - Math.min(...lons)) * 1.5 + 0.004;
      mapRef.current?.animateToRegion({
        latitude: midLat, longitude: midLon,
        latitudeDelta: deltaLat, longitudeDelta: deltaLon,
      }, 600);
    }
  };

  const borrarRuta = (id: number, nombre: string) => {
    Alert.alert('Eliminar ruta', `¿Eliminar "${nombre}"?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => {
        await eliminarRuta(id);
        loadRutas();
        if (rutaVista?.id === id) { setRutaVista(null); setModo('crear'); }
      }},
    ]);
  };

  const rutaVistaCoords: Coord[] = rutaVista
    ? JSON.parse(rutaVista.coordenadas_json)
    : [];

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <LinearGradient colors={['#050A15', '#0A1020']} style={s.bg}>
        <SafeAreaView style={s.safe}>

          {/* Header */}
          <View style={s.header}>
            <Text style={s.title}>Crear Ruta</Text>
            <View style={s.modeRow}>
              <TouchableOpacity
                style={[s.modeBtn, modo === 'crear' && s.modeBtnActive]}
                onPress={() => { setModo('crear'); setRutaVista(null); }}
              >
                <Text style={[s.modeBtnText, modo === 'crear' && s.modeBtnTextActive]}>✏️ Crear</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.modeBtn, modo === 'ver' && s.modeBtnActive]}
                onPress={() => setModo('ver')}
              >
                <Text style={[s.modeBtnText, modo === 'ver' && s.modeBtnTextActive]}>📋 Mis Rutas</Text>
              </TouchableOpacity>
            </View>
          </View>
          <View style={s.divider} />

          {/* Mapa */}
          <View style={s.mapWrap}>
            <MapView
              ref={mapRef}
              style={s.map}
              provider={PROVIDER_DEFAULT}
              region={region}
              mapType="satellite"
              showsUserLocation
              onPress={handleMapPress}
            >
              {/* Ruta en creación */}
              {modo === 'crear' && puntos.length > 1 && (
                <Polyline
                  coordinates={puntos}
                  strokeColor="#00C8FF"
                  strokeWidth={4}
                  lineDashPattern={[1]}
                />
              )}
              {modo === 'crear' && puntos.map((p, i) => (
                <Marker
                  key={i}
                  coordinate={p}
                  pinColor={i === 0 ? '#4CD964' : i === puntos.length - 1 ? '#FF3B30' : '#00C8FF'}
                >
                </Marker>
              ))}

              {/* Ruta guardada vista */}
              {modo === 'ver' && rutaVistaCoords.length > 1 && (
                <Polyline
                  coordinates={rutaVistaCoords}
                  strokeColor="#FF9500"
                  strokeWidth={4}
                />
              )}
              {modo === 'ver' && rutaVistaCoords.length > 0 && (
                <>
                  <Marker coordinate={rutaVistaCoords[0]} pinColor="#4CD964" />
                  <Marker coordinate={rutaVistaCoords[rutaVistaCoords.length - 1]} pinColor="#FF3B30" />
                </>
              )}
            </MapView>

            {/* Instrucción superpuesta */}
            {modo === 'crear' && (
              <View style={s.mapHint}>
                <Text style={s.mapHintText}>
                  {puntos.length === 0
                    ? '📍 Toca el mapa para agregar puntos'
                    : `${puntos.length} punto${puntos.length > 1 ? 's' : ''} · ${distKm.toFixed(2)} km`}
                </Text>
              </View>
            )}
          </View>

          {/* Panel según modo */}
          {modo === 'crear' ? (
            <View style={s.creadorPanel}>
              {/* Nombre de la ruta */}
              <View style={s.inputBox}>
                <TextInput
                  style={s.nameInput}
                  placeholder="Nombre de la ruta (opcional)"
                  placeholderTextColor="rgba(255,255,255,0.35)"
                  value={nombreRuta}
                  onChangeText={setNombreRuta}
                  maxLength={40}
                />
              </View>

              {/* Stats */}
              {puntos.length > 1 && (
                <View style={s.statsRow}>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{distKm.toFixed(2)}</Text>
                    <Text style={s.statLbl}>KM</Text>
                  </View>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{tiempoMin}</Text>
                    <Text style={s.statLbl}>MIN EST.</Text>
                  </View>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{puntos.length}</Text>
                    <Text style={s.statLbl}>PUNTOS</Text>
                  </View>
                </View>
              )}

              <View style={s.btnRow}>
                <TouchableOpacity style={s.btnSecondary} onPress={deshacerUltimo} disabled={puntos.length === 0}>
                  <Text style={s.btnSecText}>↩ Deshacer</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.btnSecondary} onPress={limpiarRuta} disabled={puntos.length === 0}>
                  <Text style={s.btnSecText}>🗑️ Limpiar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[s.btnGuardar, puntos.length < 2 && s.btnDisabled]}
                  onPress={guardar}
                  disabled={puntos.length < 2}
                >
                  <Text style={s.btnGuardarText}>💾 Guardar</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            <ScrollView style={s.listaScroll} contentContainerStyle={s.listaPad}>
              {rutasGuardadas.length === 0 ? (
                <Text style={s.emptyText}>No tienes rutas guardadas aún.{'\n'}¡Crea tu primera ruta!</Text>
              ) : (
                rutasGuardadas.map(r => {
                  const coords: Coord[] = JSON.parse(r.coordenadas_json);
                  const isActiva = rutaVista?.id === r.id;
                  return (
                    <TouchableOpacity
                      key={r.id}
                      style={[s.rutaCard, isActiva && s.rutaCardActive]}
                      onPress={() => verRuta(r)}
                      activeOpacity={0.8}
                    >
                      <View style={s.rutaCardHeader}>
                        <Text style={s.rutaNombre}>{r.nombre}</Text>
                        <TouchableOpacity
                          onPress={() => borrarRuta(r.id, r.nombre)}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <Text style={s.rutaDelete}>🗑️</Text>
                        </TouchableOpacity>
                      </View>
                      <View style={s.rutaStats}>
                        <Text style={s.rutaStat}>📍 {coords.length} puntos</Text>
                        <Text style={s.rutaStat}>🏃 {r.distancia_km.toFixed(2)} km</Text>
                        <Text style={s.rutaStat}>⏱️ ~{r.tiempo_estimado_min} min</Text>
                      </View>
                      {/* Mini preview de la ruta como texto de coordenadas */}
                      <Text style={s.rutaCoordHint}>
                        Inicio: {coords[0]?.latitude.toFixed(4)}, {coords[0]?.longitude.toFixed(4)}
                      </Text>
                    </TouchableOpacity>
                  );
                })
              )}
            </ScrollView>
          )}
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  bg: { flex: 1 },
  safe: { flex: 1 },

  header: { paddingTop: 6 },
  title: { fontFamily: 'DaysOne_400Regular', fontSize: 22, color: '#fff', textAlign: 'center', paddingTop: 10 },
  modeRow: { flexDirection: 'row', marginHorizontal: 18, marginTop: 10, gap: 8 },
  modeBtn: {
    flex: 1, height: 34, borderRadius: 17, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
  },
  modeBtnActive: { backgroundColor: 'rgba(0,200,255,0.18)', borderColor: 'rgba(0,200,255,0.45)' },
  modeBtnText: { fontFamily: 'DaysOne_400Regular', fontSize: 12, color: 'rgba(255,255,255,0.45)' },
  modeBtnTextActive: { color: '#00C8FF' },
  divider: { height: 1, backgroundColor: 'rgba(255,255,255,0.1)', marginHorizontal: 18, marginVertical: 8 },

  mapWrap: { height: 240, marginHorizontal: 14, borderRadius: 18, overflow: 'hidden', position: 'relative' },
  map: { flex: 1 },
  mapHint: {
    position: 'absolute', bottom: 10, left: 10, right: 10,
    backgroundColor: 'rgba(0,0,0,0.72)', borderRadius: 10,
    paddingHorizontal: 12, paddingVertical: 6, alignItems: 'center',
  },
  mapHintText: { fontFamily: 'DaysOne_400Regular', fontSize: 12, color: '#00C8FF' },

  creadorPanel: { paddingHorizontal: 14, paddingTop: 10, gap: 8 },
  inputBox: {
    backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: 12,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
    height: 44, paddingHorizontal: 14, justifyContent: 'center',
  },
  nameInput: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff' },

  statsRow: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 4 },
  statItem: { alignItems: 'center' },
  statVal: { fontFamily: 'DaysOne_400Regular', fontSize: 20, color: '#00C8FF' },
  statLbl: { fontFamily: 'DaysOne_400Regular', fontSize: 9, color: 'rgba(255,255,255,0.45)', letterSpacing: 1 },

  btnRow: { flexDirection: 'row', gap: 8 },
  btnSecondary: {
    flex: 1, height: 40, borderRadius: 10, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
  },
  btnSecText: { fontFamily: 'DaysOne_400Regular', fontSize: 12, color: 'rgba(255,255,255,0.7)' },
  btnGuardar: {
    flex: 1.5, height: 40, borderRadius: 10, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(0,200,255,0.2)', borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)',
  },
  btnGuardarText: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff' },
  btnDisabled: { opacity: 0.3 },

  listaScroll: { flex: 1 },
  listaPad: { paddingHorizontal: 14, paddingVertical: 8, gap: 8, paddingBottom: 20 },
  emptyText: {
    fontFamily: 'DaysOne_400Regular', fontSize: 14, color: 'rgba(255,255,255,0.35)',
    textAlign: 'center', marginTop: 30, lineHeight: 24,
  },
  rutaCard: {
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', padding: 12,
  },
  rutaCardActive: { borderColor: 'rgba(255,165,0,0.6)', backgroundColor: 'rgba(255,165,0,0.07)' },
  rutaCardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  rutaNombre: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff', flex: 1 },
  rutaDelete: { fontSize: 16 },
  rutaStats: { flexDirection: 'row', gap: 12, marginBottom: 4 },
  rutaStat: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.6)' },
  rutaCoordHint: { fontFamily: 'DaysOne_400Regular', fontSize: 9, color: 'rgba(255,255,255,0.3)', marginTop: 2 },
});

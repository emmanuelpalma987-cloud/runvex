import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ImageBackground, SafeAreaView,
  StatusBar, TouchableOpacity, ScrollView, RefreshControl,
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/hooks/useAuth';
import { obtenerUltimaCarrera, obtenerCarrerasDelMes } from '../../src/database/database';

const BG = { uri: 'https://www.figma.com/api/mcp/asset/37f18608-abbc-4ff9-93b3-0b480ceb8930' };

const fmtTime = (s: number) => {
  const m = Math.floor(s / 60), sec = s % 60;
  return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
};
const fmtPace = (dist: number, seg: number) => {
  if (!dist) return '--:--';
  const p = seg / dist;
  return `${Math.floor(p / 60)}:${String(Math.floor(p % 60)).padStart(2, '0')}`;
};

const DAYS = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];
const MONTHS = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];

export default function HomeScreen() {
  const router = useRouter();
  const { usuario } = useAuth();
  const [ultima, setUltima] = useState<any>(null);
  const [diasCarrera, setDiasCarrera] = useState<Set<number>>(new Set());
  const [calMonth, setCalMonth] = useState(new Date());
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    if (!usuario?.id) return;
    try {
      const u = await obtenerUltimaCarrera(usuario.id);
      setUltima(u);
      const year = calMonth.getFullYear();
      const month = calMonth.getMonth() + 1;
      const dias = await obtenerCarrerasDelMes(usuario.id, year, month);
      setDiasCarrera(new Set(dias));
    } catch {}
  }, [usuario, calMonth]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  // Calendar builder
  const today = new Date();
  const year = calMonth.getFullYear();
  const month = calMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = new Date(year, month, 1).getDay(); // 0=Sun
  const offset = firstDay === 0 ? 6 : firstDay - 1; // Monday=0

  const calDays: (number | null)[] = [];
  for (let i = 0; i < offset; i++) calDays.push(null);
  for (let d = 1; d <= daysInMonth; d++) calDays.push(d);

  const getDayColor = (day: number | null): string => {
    if (!day) return 'transparent';
    const isToday = day === today.getDate() && month === today.getMonth() && year === today.getFullYear();
    const isPast = new Date(year, month, day) < new Date(today.getFullYear(), today.getMonth(), today.getDate());
    if (isToday) return 'rgba(0,200,255,0.3)';
    if (!isPast) return 'rgba(255,255,255,0.04)';
    if (diasCarrera.has(day)) return 'rgba(76,217,100,0.25)'; // verde = corrió
    return 'rgba(255,59,48,0.2)'; // rojo = no corrió
  };

  const getDayDot = (day: number | null): string => {
    if (!day) return 'transparent';
    const isPast = new Date(year, month, day) < new Date(today.getFullYear(), today.getMonth(), today.getDate());
    if (!isPast) return 'transparent';
    if (diasCarrera.has(day)) return '#4CD964';
    return '#FF3B30';
  };

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <ImageBackground source={BG} style={s.bg} resizeMode="cover">
        <LinearGradient colors={['rgba(0,0,0,0.5)', 'rgba(0,5,20,0.88)']} style={s.overlay}>
          <SafeAreaView style={s.safe}>
            <ScrollView
              contentContainerStyle={s.scroll}
              refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#00C8FF" />}
              showsVerticalScrollIndicator={false}
            >
              {/* Header */}
              <Text style={s.greeting}>
                Hola, {usuario?.nombre ?? 'Corredor'} 👋
              </Text>
              <Text style={s.homeLabel}>HOME</Text>
              <View style={s.divider} />

              {/* Stats última carrera */}
              <Text style={s.sectionTitle}>ÚLTIMA CARRERA</Text>
              <View style={s.statsGrid}>
                <View style={s.statCard}>
                  <Text style={s.statEmoji}>🏃</Text>
                  <Text style={s.statVal}>{ultima ? `${ultima.distancia_km.toFixed(2)}` : '0.00'}</Text>
                  <Text style={s.statUnit}>KM</Text>
                  <Text style={s.statLbl}>DISTANCIA</Text>
                </View>
                <View style={s.statCard}>
                  <Text style={s.statEmoji}>⏱️</Text>
                  <Text style={s.statVal}>{ultima ? fmtTime(ultima.tiempo_segundos) : '00:00'}</Text>
                  <Text style={s.statUnit}>MIN</Text>
                  <Text style={s.statLbl}>TIEMPO</Text>
                </View>
                <View style={s.statCard}>
                  <Text style={s.statEmoji}>⚡</Text>
                  <Text style={s.statVal}>
                    {ultima ? fmtPace(ultima.distancia_km, ultima.tiempo_segundos) : '--:--'}
                  </Text>
                  <Text style={s.statUnit}>/KM</Text>
                  <Text style={s.statLbl}>RITMO</Text>
                </View>
                <View style={s.statCard}>
                  <Text style={s.statEmoji}>🔥</Text>
                  <Text style={s.statVal}>{ultima ? ultima.calorias : '0'}</Text>
                  <Text style={s.statUnit}>KCAL</Text>
                  <Text style={s.statLbl}>CALORÍAS</Text>
                </View>
              </View>
              <View style={s.divider} />

              {/* Botón Iniciar Carrera */}
              <View style={s.startWrap}>
                <TouchableOpacity
                  style={s.startBtn}
                  onPress={() => router.push('/(tabs)/carrera')}
                  activeOpacity={0.85}
                >
                  <LinearGradient
                    colors={['rgba(0,200,255,0.22)', 'rgba(255,106,0,0.22)']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                    style={s.startGrad}
                  >
                    <View style={s.startInner}>
                      <Text style={s.startText}>Iniciar{'\n'}Carrera</Text>
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              </View>

              {/* Racha + Clima */}
              <View style={s.rowCards}>
                <View style={[s.miniCard, { flex: 1 }]}>
                  <Text style={s.rachaEmoji}>🔥</Text>
                  <View>
                    <Text style={s.rachaVal}>{usuario?.racha ?? 0}</Text>
                    <Text style={s.rachaLbl}>DÍAS DE RACHA</Text>
                  </View>
                </View>
                <View style={[s.miniCard, { flex: 1 }]}>
                  <Text style={s.weatherIcon}>⛅</Text>
                  <View>
                    <Text style={s.weatherTemp}>21°C</Text>
                    <Text style={s.weatherDesc}>Parcialmente nublado</Text>
                  </View>
                </View>
              </View>
              <View style={s.divider} />

              {/* Calendario de rachas */}
              <View style={s.calCard}>
                <View style={s.calHeader}>
                  <TouchableOpacity
                    onPress={() => setCalMonth(d => new Date(d.getFullYear(), d.getMonth() - 1, 1))}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <Text style={s.calNav}>‹</Text>
                  </TouchableOpacity>
                  <Text style={s.calTitle}>
                    {MONTHS[month]} {year}
                  </Text>
                  <TouchableOpacity
                    onPress={() => setCalMonth(d => new Date(d.getFullYear(), d.getMonth() + 1, 1))}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <Text style={s.calNav}>›</Text>
                  </TouchableOpacity>
                </View>

                <View style={s.calDaysHeader}>
                  {DAYS.map(d => (
                    <Text key={d} style={s.calDayName}>{d}</Text>
                  ))}
                </View>

                <View style={s.calGrid}>
                  {calDays.map((day, i) => (
                    <View key={i} style={[s.calDay, { backgroundColor: getDayColor(day) }]}>
                      <Text style={[
                        s.calDayNum,
                        !day && { opacity: 0 },
                        day === today.getDate() && month === today.getMonth() && year === today.getFullYear()
                          && s.calDayToday,
                      ]}>
                        {day ?? ''}
                      </Text>
                      {day && <View style={[s.calDot, { backgroundColor: getDayDot(day) }]} />}
                    </View>
                  ))}
                </View>

                {/* Leyenda */}
                <View style={s.calLegend}>
                  <View style={s.legendItem}>
                    <View style={[s.legendDot, { backgroundColor: '#4CD964' }]} />
                    <Text style={s.legendText}>Corriste</Text>
                  </View>
                  <View style={s.legendItem}>
                    <View style={[s.legendDot, { backgroundColor: '#FF9500' }]} />
                    <Text style={s.legendText}>Hoy</Text>
                  </View>
                  <View style={s.legendItem}>
                    <View style={[s.legendDot, { backgroundColor: '#FF3B30' }]} />
                    <Text style={s.legendText}>Sin carrera</Text>
                  </View>
                </View>
              </View>

            </ScrollView>
          </SafeAreaView>
        </LinearGradient>
      </ImageBackground>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  bg: { flex: 1 },
  overlay: { flex: 1 },
  safe: { flex: 1 },
  scroll: { paddingBottom: 32 },

  greeting: {
    fontFamily: 'DaysOne_400Regular', fontSize: 14, color: 'rgba(255,255,255,0.6)',
    textAlign: 'center', paddingTop: 14,
  },
  homeLabel: {
    fontFamily: 'DaysOne_400Regular', fontSize: 24, color: '#fff',
    textAlign: 'center', paddingTop: 2, marginBottom: 6,
  },
  divider: { height: 1, backgroundColor: 'rgba(255,255,255,0.12)', marginHorizontal: 16, marginVertical: 10 },
  sectionTitle: {
    fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(0,200,255,0.8)',
    letterSpacing: 2, marginHorizontal: 18, marginBottom: 10,
  },

  statsGrid: {
    flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 12, gap: 8,
  },
  statCard: {
    width: '47%', backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    padding: 14, alignItems: 'center',
  },
  statEmoji: { fontSize: 22, marginBottom: 4 },
  statVal: { fontFamily: 'DaysOne_400Regular', fontSize: 22, color: '#fff' },
  statUnit: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: '#00C8FF', marginTop: 1 },
  statLbl: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.4)', marginTop: 2 },

  startWrap: { alignItems: 'center', marginVertical: 18 },
  startBtn: {
    width: 220, height: 220, borderRadius: 110, overflow: 'hidden',
    shadowColor: '#00C8FF', shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9, shadowRadius: 30, elevation: 14,
  },
  startGrad: { flex: 1, borderRadius: 110, padding: 4, borderWidth: 2, borderColor: 'rgba(0,200,255,0.6)' },
  startInner: {
    flex: 1, borderRadius: 110, backgroundColor: 'rgba(0,0,0,0.72)',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(255,106,0,0.35)',
  },
  startText: {
    fontFamily: 'DaysOne_400Regular', fontSize: 26, color: '#fff',
    textAlign: 'center', lineHeight: 34,
  },

  rowCards: { flexDirection: 'row', marginHorizontal: 14, gap: 10, marginBottom: 4 },
  miniCard: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    padding: 14,
  },
  rachaEmoji: { fontSize: 26 },
  rachaVal: { fontFamily: 'DaysOne_400Regular', fontSize: 22, color: '#fff' },
  rachaLbl: { fontFamily: 'DaysOne_400Regular', fontSize: 9, color: 'rgba(255,255,255,0.4)', letterSpacing: 1 },
  weatherIcon: { fontSize: 30 },
  weatherTemp: { fontFamily: 'DaysOne_400Regular', fontSize: 20, color: '#fff' },
  weatherDesc: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.5)', lineHeight: 14 },

  // Calendar
  calCard: {
    marginHorizontal: 14, backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 18, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    padding: 14,
  },
  calHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  calNav: { fontFamily: 'DaysOne_400Regular', fontSize: 24, color: '#00C8FF', paddingHorizontal: 8 },
  calTitle: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff' },
  calDaysHeader: { flexDirection: 'row', marginBottom: 6 },
  calDayName: {
    flex: 1, textAlign: 'center',
    fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.4)',
  },
  calGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  calDay: {
    width: `${100 / 7}%`, aspectRatio: 1,
    alignItems: 'center', justifyContent: 'center',
    borderRadius: 8, marginVertical: 1,
  },
  calDayNum: { fontFamily: 'DaysOne_400Regular', fontSize: 12, color: 'rgba(255,255,255,0.75)' },
  calDayToday: { color: '#00C8FF' },
  calDot: { width: 4, height: 4, borderRadius: 2, marginTop: 1 },

  calLegend: { flexDirection: 'row', justifyContent: 'center', gap: 16, marginTop: 10 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.5)' },
});

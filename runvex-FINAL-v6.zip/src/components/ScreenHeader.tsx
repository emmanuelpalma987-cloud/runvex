/**
 * ScreenHeader — resuelve el solapamiento de títulos con la barra de estado
 * en todas las pantallas. Usa useSafeAreaInsets() para agregar el padding
 * correcto según el modelo del dispositivo (notch, Dynamic Island, etc.)
 */
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface Props {
  title: string;
  subtitle?: string;
  rightElement?: React.ReactNode;
  onBack?: () => void;
}

export function ScreenHeader({ title, subtitle, rightElement, onBack }: Props) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[s.container, { paddingTop: insets.top + 8 }]}>
      <View style={s.row}>
        {onBack ? (
          <TouchableOpacity onPress={onBack} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
            <Text style={s.back}>‹</Text>
          </TouchableOpacity>
        ) : <View style={s.spacer} />}

        <View style={s.center}>
          <Text style={s.title}>{title}</Text>
          {subtitle ? <Text style={s.subtitle}>{subtitle}</Text> : null}
        </View>

        <View style={s.spacer}>
          {rightElement ?? null}
        </View>
      </View>
      <View style={s.divider} />
    </View>
  );
}

const s = StyleSheet.create({
  container: {
    backgroundColor: 'transparent',
    paddingHorizontal: 18,
    paddingBottom: 0,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 8,
  },
  back: {
    fontSize: 32, color: '#00C8FF',
    fontFamily: 'DaysOne_400Regular',
    lineHeight: 36,
  },
  center: { flex: 1, alignItems: 'center' },
  title: {
    fontFamily: 'DaysOne_400Regular',
    fontSize: 20, color: '#fff', letterSpacing: 1,
  },
  subtitle: {
    fontFamily: 'DaysOne_400Regular',
    fontSize: 10, color: 'rgba(0,200,255,0.7)',
    letterSpacing: 1.5, marginTop: 2,
  },
  spacer: { width: 36 },
  divider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.12)',
    marginTop: 4,
  },
});

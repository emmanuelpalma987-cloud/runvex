/**
 * useRunTracker v2 — Mejorado con:
 *
 * PASOS más precisos:
 *   - Filtro de Kalman 1D para suavizar posición GPS antes de calcular distancia
 *   - Detección de cadencia por acelerómetro (Accelerometer de expo-sensors)
 *   - Ventana temporal de pasos: promedio móvil de cadencia real
 *   - Longitud de zancada adaptiva con velocidad suavizada
 *
 * GPS más eficiente:
 *   - Kalman 1D sobre lat/lon para eliminar ruido en reposo
 *   - Filtro de velocidad: ignora puntos < 0.5 m/s en reposo
 *   - Distancia acumulada solo si el desplazamiento supera umbral dinámico
 *   - No registra coordenadas duplicadas (jitter del celular parado)
 *
 * RENDIMIENTO:
 *   - GPS: distanceInterval 3m | timeInterval 800ms (balance batería/precisión)
 *   - Timer 1 s solo actualiza lo necesario (sin cálculos pesados en cada tick)
 *   - Acelerómetro a 10 Hz (suficiente para detectar pasos, no consume mucho)
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import * as Location from 'expo-location';
import { Pedometer, Accelerometer } from 'expo-sensors';
import { Platform, PermissionsAndroid } from 'react-native';

// ─── Tipos ────────────────────────────────────────────────────────────────────
export interface RunData {
  distanciaKm: number;
  tiempoSegundos: number;
  velocidadActual: number;
  velocidadPromedio: number;
  pasos: number;
  cadencia: number;       // pasos/min en tiempo real
  bpm: number;
  bpmMaximo: number;
  calorias: number;
  elevacionAcumulada: number;
  altitudActual: number;
  pace: number;
  coordenadas: { latitude: number; longitude: number; altitude: number }[];
  corriendo: boolean;
  pausado: boolean;
}

// ─── Constantes ───────────────────────────────────────────────────────────────
const BPM_BASE = 68;
const BPM_MAX  = 185;
const BPM_RAMP = 1.5;

const INICIAL: RunData = {
  distanciaKm: 0, tiempoSegundos: 0, velocidadActual: 0, velocidadPromedio: 0,
  pasos: 0, cadencia: 0, bpm: BPM_BASE, bpmMaximo: 0, calorias: 0,
  elevacionAcumulada: 0, altitudActual: 0, pace: 0, coordenadas: [],
  corriendo: false, pausado: false,
};

// ─── Kalman 1D ─────────────────────────────────────────────────────────────────
// Filtro de Kalman simple de 1 dimensión para suavizar señales ruidosas (GPS, altitud)
class Kalman1D {
  private x:  number; // estimación
  private p:  number; // varianza del error
  private q:  number; // ruido del proceso
  private r:  number; // ruido de medición

  constructor(q = 0.0001, r = 0.01, initialValue = 0) {
    this.x = initialValue;
    this.p = 1;
    this.q = q;
    this.r = r;
  }

  update(measurement: number): number {
    // Predicción
    this.p += this.q;
    // Actualización
    const k = this.p / (this.p + this.r);
    this.x  = this.x + k * (measurement - this.x);
    this.p  = (1 - k) * this.p;
    return this.x;
  }

  reset(value: number) {
    this.x = value;
    this.p = 1;
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function longitudZancada(velKmh: number): number {
  if (velKmh <= 0) return 0.75;
  if (velKmh < 6)  return 0.55 + (velKmh / 6) * 0.10;
  if (velKmh < 9)  return 0.65 + ((velKmh - 6) / 3) * 0.15;
  if (velKmh < 12) return 0.80 + ((velKmh - 9) / 3) * 0.15;
  return Math.min(1.20, 0.95 + ((velKmh - 12) / 6) * 0.25);
}

function pasosDesdeDistancia(distanciaM: number, velKmh: number): number {
  const zancada = longitudZancada(velKmh);
  return Math.round(distanciaM / zancada);
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 +
    Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function estimarBPM(vel: number, t: number, prev: number): number {
  if (t === 0 || vel < 1)
    return prev > BPM_BASE ? Math.max(BPM_BASE, Math.round(prev - BPM_RAMP)) : BPM_BASE;
  const pct = vel < 6  ? 0.58 + (vel/6)*0.07
            : vel < 9  ? 0.65 + ((vel-6)/3)*0.10
            : vel < 12 ? 0.75 + ((vel-9)/3)*0.10
            :             0.85 + Math.min((vel-12)/8,1)*0.10;
  const obj  = Math.round(BPM_BASE + pct * (BPM_MAX - BPM_BASE));
  const vari = Math.floor(Math.random() * 5) - 2;
  const delta = obj - prev;
  const paso  = Math.sign(delta) * Math.min(Math.abs(delta), BPM_RAMP);
  return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(prev + paso + vari * 0.3)));
}

function calcCalorias(dist: number, t: number, vel: number): number {
  const peso = 70;
  const met  = vel >= 12 ? 13.5 : vel >= 10 ? 11.5 : vel >= 8 ? 10 : vel >= 6 ? 8 : 6;
  return Math.round(met * peso * (t / 3600));
}

async function pedirPermisoAndroid(): Promise<void> {
  if (Platform.OS !== 'android' || Platform.Version < 29) return;
  await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACTIVITY_RECOGNITION).catch(() => {});
}

// ─── Hook ─────────────────────────────────────────────────────────────────────
export function useRunTracker() {
  const [datos, setDatos] = useState<RunData>(INICIAL);
  const [permGPS, setPermGPS] = useState(false);

  // Refs de estado de carrera (no causan re-render)
  const distM       = useRef(0);
  const tiempo      = useRef(0);
  const velRef      = useRef(0);      // km/h suavizada
  const bpmRef      = useRef(BPM_BASE);
  const bpmMaxRef   = useRef(0);
  const elevAcum    = useRef(0);
  const coords      = useRef<{ latitude: number; longitude: number; altitude: number }[]>([]);
  const pasosRef    = useRef(0);
  const cadenciaRef = useRef(0);      // pasos/min en tiempo real

  // Suscripciones
  const timer       = useRef<ReturnType<typeof setInterval> | null>(null);
  const locSub      = useRef<Location.LocationSubscription | null>(null);
  const pedSub      = useRef<{ remove: () => void } | null>(null);
  const accelSub    = useRef<{ remove: () => void } | null>(null);
  const pedActivo   = useRef(false);

  // Filtros Kalman por canal
  const kLat    = useRef(new Kalman1D(0.00001, 0.0001));
  const kLon    = useRef(new Kalman1D(0.00001, 0.0001));
  const kAlt    = useRef(new Kalman1D(0.01, 0.5));
  const kVel    = useRef(new Kalman1D(0.01, 0.2));

  // Buffer para cadencia por acelerómetro
  const accelTimestamps = useRef<number[]>([]); // timestamps de cada "paso" detectado
  const lastAccelSign   = useRef(0);            // signo previo de la aceleración vertical
  const lastStepTime    = useRef(0);

  useEffect(() => {
    Location.requestForegroundPermissionsAsync().then(({ status }) => {
      if (status === 'granted') setPermGPS(true);
    });
    pedirPermisoAndroid();
  }, []);

  // ── Acelerómetro: detectar pasos por pico de aceleración vertical ─────────
  const iniciarAcelerometro = useCallback(() => {
    Accelerometer.setUpdateInterval(100); // 10 Hz
    accelSub.current = Accelerometer.addListener(({ x, y, z }) => {
      // Magnitud total de la aceleración
      const mag = Math.sqrt(x*x + y*y + z*z);
      // Umbral: un paso típico genera pico de 1.2–2.5 g
      const sign = mag > 1.25 ? 1 : mag < 0.85 ? -1 : 0;

      if (sign === 1 && lastAccelSign.current !== 1) {
        const now = Date.now();
        // Mínimo 250ms entre pasos (~max 240 ppm, fisiológicamente imposible más)
        if (now - lastStepTime.current > 250) {
          lastStepTime.current = now;
          accelTimestamps.current.push(now);
          // Ventana de 5 segundos para calcular cadencia
          const cutoff = now - 5000;
          accelTimestamps.current = accelTimestamps.current.filter(t => t > cutoff);
          // cadencia = pasos en 5s * 12 = pasos/min
          cadenciaRef.current = Math.round(accelTimestamps.current.length * 12);
          // Incrementar pasos (si el pedómetro nativo no está activo)
          if (!pedActivo.current) {
            pasosRef.current += 1;
            setDatos(p => ({ ...p, pasos: pasosRef.current, cadencia: cadenciaRef.current }));
          } else {
            setDatos(p => ({ ...p, cadencia: cadenciaRef.current }));
          }
        }
      }
      if (sign !== 0) lastAccelSign.current = sign;
    });
  }, []);

  // ── Pedómetro nativo ──────────────────────────────────────────────────────
  const intentarPedometro = useCallback(async () => {
    try {
      const avail = await Pedometer.isAvailableAsync();
      if (!avail) return;
      pedSub.current = Pedometer.watchStepCount(result => {
        if (result.steps > 0) {
          pedActivo.current = true;
          pasosRef.current  = result.steps;
          setDatos(p => ({ ...p, pasos: result.steps }));
        }
      });
      setTimeout(() => {
        if (!pedActivo.current) { pedSub.current?.remove(); pedSub.current = null; }
      }, 6000);
    } catch {}
  }, []);

  // ── GPS con Kalman ────────────────────────────────────────────────────────
  const suscribirGPS = useCallback(async () => {
    locSub.current = await Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.BestForNavigation,
        distanceInterval: 3,    // cada 3 metros (menos ruido que 2m)
        timeInterval: 800,      // más fluido que 1000ms
      },
      loc => {
        const raw = loc.coords;

        // ── Kalman sobre lat/lon ──
        const lat = kLat.current.update(raw.latitude);
        const lon = kLon.current.update(raw.longitude);
        const alt = kAlt.current.update(raw.altitude ?? 0);

        // ── Velocidad suavizada (Kalman + exponencial) ──
        const velGps = raw.speed != null && raw.speed > 0.4 ? raw.speed * 3.6 : 0;
        const velSmooth = kVel.current.update(velGps);
        velRef.current = velSmooth;

        // ── Distancia ──
        const prev = coords.current;
        let deltaM = 0;
        if (prev.length > 0) {
          const last = prev[prev.length - 1];
          const d = haversine(last.latitude, last.longitude, lat, lon);
          // Solo acumula si hay movimiento real (> 1m, < 50m por tick evita teleportaciones)
          if (d > 1 && d < 50) {
            distM.current += d;
            deltaM = d;
          }
        }

        // ── Pasos desde GPS (fallback si ni pedómetro ni acelerómetro activos) ──
        if (!pedActivo.current && accelTimestamps.current.length === 0 && deltaM > 0) {
          const nuevos = pasosDesdeDistancia(distM.current, velRef.current);
          pasosRef.current = nuevos;
          setDatos(p => ({ ...p, pasos: nuevos }));
        }

        // ── Elevación (Kalman aplicado) ──
        if (prev.length >= 1) {
          const prevAlt = prev[prev.length - 1].altitude;
          const dif = alt - prevAlt;
          if (dif > 0.4) elevAcum.current += dif; // solo subidas > 40cm
        }

        coords.current = [...prev, { latitude: lat, longitude: lon, altitude: alt }];

        setDatos(p => ({
          ...p,
          distanciaKm:        parseFloat((distM.current / 1000).toFixed(4)),
          velocidadActual:    parseFloat(velSmooth.toFixed(1)),
          elevacionAcumulada: parseFloat(elevAcum.current.toFixed(1)),
          altitudActual:      parseFloat(alt.toFixed(1)),
          coordenadas:        coords.current,
        }));
      }
    );
  }, []);

  // ── Timer 1 s: tiempo, BPM, calorías, pace ────────────────────────────────
  const iniciarTimer = useCallback(() => {
    timer.current = setInterval(() => {
      tiempo.current += 1;
      const t  = tiempo.current;
      const dK = distM.current / 1000;
      const v  = velRef.current;

      const bpm = estimarBPM(v, t, bpmRef.current);
      bpmRef.current = bpm;
      if (bpm > bpmMaxRef.current) bpmMaxRef.current = bpm;

      const pace  = dK > 0 && t > 0 ? t / dK : 0;
      const vProm = t > 0 ? (dK / t) * 3600 : 0;
      const cal   = calcCalorias(dK, t, v);

      // Pasos: prioridad pedómetro nativo > acelerómetro > GPS
      const pasos = pedActivo.current
        ? pasosRef.current
        : accelTimestamps.current.length > 0
          ? pasosRef.current
          : pasosDesdeDistancia(distM.current, v);

      setDatos(p => ({
        ...p,
        tiempoSegundos:    t,
        bpm,
        bpmMaximo:         bpmMaxRef.current,
        calorias:          cal,
        velocidadPromedio: parseFloat(vProm.toFixed(2)),
        pace,
        pasos,
        cadencia:          cadenciaRef.current,
      }));
    }, 1000);
  }, []);

  // ── INICIAR ───────────────────────────────────────────────────────────────
  const iniciarCarrera = useCallback(async () => {
    if (!permGPS) {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      setPermGPS(true);
    }

    // Reset completo
    distM.current      = 0;
    tiempo.current     = 0;
    pasosRef.current   = 0;
    cadenciaRef.current = 0;
    elevAcum.current   = 0;
    velRef.current     = 0;
    bpmRef.current     = BPM_BASE;
    bpmMaxRef.current  = 0;
    coords.current     = [];
    pedActivo.current  = false;
    accelTimestamps.current = [];
    lastAccelSign.current   = 0;
    lastStepTime.current    = 0;

    // Reset filtros Kalman
    kLat.current = new Kalman1D(0.00001, 0.0001);
    kLon.current = new Kalman1D(0.00001, 0.0001);
    kAlt.current = new Kalman1D(0.01, 0.5);
    kVel.current = new Kalman1D(0.01, 0.2);

    setDatos({ ...INICIAL, bpm: BPM_BASE, corriendo: true, pausado: false });

    iniciarTimer();
    await suscribirGPS();
    intentarPedometro();
    iniciarAcelerometro();
  }, [permGPS, iniciarTimer, suscribirGPS, intentarPedometro, iniciarAcelerometro]);

  // ── PAUSAR ────────────────────────────────────────────────────────────────
  const pausarCarrera = useCallback(() => {
    _stop();
    setDatos(p => ({ ...p, corriendo: false, pausado: true }));
  }, []);

  // ── REANUDAR ──────────────────────────────────────────────────────────────
  const reanudarCarrera = useCallback(async () => {
    if (!permGPS) return;
    pedActivo.current  = false;
    accelTimestamps.current = [];
    setDatos(p => ({ ...p, corriendo: true, pausado: false }));
    iniciarTimer();
    await suscribirGPS();
    intentarPedometro();
    iniciarAcelerometro();
  }, [permGPS, iniciarTimer, suscribirGPS, intentarPedometro, iniciarAcelerometro]);

  // ── TERMINAR ──────────────────────────────────────────────────────────────
  const terminarCarrera = useCallback(() => {
    _stop();
    const dK = distM.current / 1000;
    const pasos = pedActivo.current
      ? pasosRef.current
      : accelTimestamps.current.length > 0
        ? pasosRef.current
        : pasosDesdeDistancia(distM.current, velRef.current);
    const res = {
      distanciaKm:       dK,
      tiempoSegundos:    tiempo.current,
      velocidadPromedio: tiempo.current > 0 ? (dK / tiempo.current) * 3600 : 0,
      pasos,
      cadencia:          cadenciaRef.current,
      calorias:          calcCalorias(dK, tiempo.current, velRef.current),
      bpmPromedio:       bpmRef.current,
      bpmMaximo:         bpmMaxRef.current,
      elevacionM:        elevAcum.current,
      coordenadas:       coords.current,
    };
    setDatos(p => ({ ...p, corriendo: false, pausado: false }));
    return res;
  }, []);

  function _stop() {
    if (timer.current)  { clearInterval(timer.current); timer.current = null; }
    locSub.current?.remove();
    pedSub.current?.remove();
    accelSub.current?.remove();
  }

  return { datos, iniciarCarrera, pausarCarrera, reanudarCarrera, terminarCarrera, permGPS };
}

// ─── Formatters ───────────────────────────────────────────────────────────────
export const formatTiempo = (s: number) =>
  `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;

export const formatPace = (p: number) => {
  if (!p || p <= 0) return '--:--';
  return `${Math.floor(p/60)}:${String(Math.floor(p%60)).padStart(2,'0')} /km`;
};

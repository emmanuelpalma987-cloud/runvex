/**
 * rutas.tsx – Versión mejorada con:
 * - Rutas reales por calles via OSRM (Open Source Routing Machine, sin API key)
 * - Múltiples puntos al dibujar / tocar el mapa
 * - Diseño 100% responsivo
 * - Mapa en modo estándar (calles visibles como Google Maps)
 * - Colores de polilínea sobre las calles reales
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Alert, TextInput, ActivityIndicator, StatusBar, Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Polyline, PROVIDER_DEFAULT } from 'react-native-maps';
import * as Location from 'expo-location';
import { useFocusEffect, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../src/hooks/useAuth';
import { guardarRuta, obtenerRutas, eliminarRuta } from '../../src/database/database';

// ─── Responsive ────────────────────────────────────────────────────────────────
const { width: W, height: H } = Dimensions.get('window');
const rs = (n: number) => (W / 390) * n;
const MAP_H = H < 700 ? H * 0.34 : H * 0.40;

interface Coord { latitude: number; longitude: number; }

// ─── Helpers ───────────────────────────────────────────────────────────────────
function haversineM(a: Coord, b: Coord): number {
  const R = 6371000;
  const dLat = (b.latitude - a.latitude) * Math.PI / 180;
  const dLon = (b.longitude - a.longitude) * Math.PI / 180;
  const x = Math.sin(dLat/2)**2 +
    Math.cos(a.latitude*Math.PI/180)*Math.cos(b.latitude*Math.PI/180)*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
}
function totalDistM(coords: Coord[]): number {
  let d = 0;
  for (let i = 1; i < coords.length; i++) d += haversineM(coords[i-1], coords[i]);
  return d;
}
function fmtDist(m: number): string {
  return m >= 1000 ? `${(m/1000).toFixed(2)} km` : `${Math.round(m)} m`;
}
function tiempoEstimado(distM: number, velKmh: number): string {
  const min = Math.round((distM / 1000) / velKmh * 60);
  if (min < 60) return `~${min} min`;
  return `~${Math.floor(min/60)}h ${min%60}min`;
}

// ─── OSRM: rutas reales por calles ────────────────────────────────────────────
// OSRM es open-source y gratuito, no requiere API key.
// Devuelve la geometría decodificada como array de coordenadas.

function decodePolyline(encoded: string): Coord[] {
  let index = 0, lat = 0, lng = 0;
  const coords: Coord[] = [];
  while (index < encoded.length) {
    let b, shift = 0, result = 0;
    do { b = encoded.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dLat = result & 1 ? ~(result >> 1) : result >> 1;
    lat += dLat;
    shift = 0; result = 0;
    do { b = encoded.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dLng = result & 1 ? ~(result >> 1) : result >> 1;
    lng += dLng;
    coords.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
  }
  return coords;
}

// Tres perfiles OSRM para obtener 3 rutas diferentes (foot = caminar/correr)
const OSRM_BASE = 'https://router.project-osrm.org/route/v1';

async function obtenerRutaOSRM(
  origen: Coord,
  destino: Coord,
  perfil: 'foot' | 'bike' | 'driving',
  alternativas = false,
): Promise<Coord[][]> {
  try {
    const coords = `${origen.longitude},${origen.latitude};${destino.longitude},${destino.latitude}`;
    const alt = alternativas ? '&alternatives=true' : '';
    const url = `${OSRM_BASE}/${perfil}/${coords}?overview=full&geometries=polyline${alt}`;
    const res  = await fetch(url, { headers: { 'Accept': 'application/json' } });
    const data = await res.json();
    if (data.code !== 'Ok' || !data.routes?.length) return [];
    return data.routes.map((r: any) => decodePolyline(r.geometry));
  } catch {
    return [];
  }
}

// Geocoding con Nominatim
async function buscarLugar(query: string, cerca: Coord): Promise<Coord | null> {
  try {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=1&lat=${cerca.latitude}&lon=${cerca.longitude}&radius=50000`;
    const res  = await fetch(url, { headers: { 'User-Agent': 'RunvexApp/2.0' } });
    const data = await res.json();
    if (data.length > 0) return { latitude: parseFloat(data[0].lat), longitude: parseFloat(data[0].lon) };
    return null;
  } catch { return null; }
}

// ─── Tipos ─────────────────────────────────────────────────────────────────────
type Modo = 'buscar' | 'crear' | 'guardadas';

interface RutaOpcion {
  nombre: string;
  color: string;
  velKmh: number;
  puntos: Coord[];
  distanciaM: number;
}

// ─── Pantalla ──────────────────────────────────────────────────────────────────
export default function RutasScreen() {
  const { usuario } = useAuth();
  const router      = useRouter();
  const insets      = useSafeAreaInsets();
  const mapRef      = useRef<MapView>(null);

  const [modo, setModo]             = useState<Modo>('buscar');
  const [miPos, setMiPos]           = useState<Coord>({ latitude: 19.2869, longitude: -99.6531 });
  const [region, setRegion]         = useState({ latitude: 19.2869, longitude: -99.6531, latitudeDelta: 0.012, longitudeDelta: 0.012 });
  const [buscando, setBuscando]     = useState(false);
  const [destino, setDestino]       = useState('');
  const [rutasOpciones, setRutasOpciones] = useState<RutaOpcion[]>([]);
  const [rutaSeleccionada, setRutaSeleccionada] = useState<number>(0);
  const [destinoCoord, setDestinoCoord] = useState<Coord | null>(null);

  // Modo crear (múltiples waypoints)
  const [puntos, setPuntos]         = useState<Coord[]>([]);
  const [nombreRuta, setNombreRuta] = useState('');
  const [rutaDibujada, setRutaDibujada] = useState<Coord[]>([]);
  const [calculandoRuta, setCalculandoRuta] = useState(false);

  // Guardadas
  const [rutasGuardadas, setRutasGuardadas] = useState<any[]>([]);
  const [rutaVista, setRutaVista]   = useState<any | null>(null);

  useFocusEffect(useCallback(() => { loadRutas(); }, [usuario]));

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const pos = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
        setMiPos(pos);
        setRegion({ ...pos, latitudeDelta: 0.012, longitudeDelta: 0.012 });
      }
    })();
  }, []);

  // Cuando el usuario agrega puntos en modo crear, calcula ruta real por calles
  useEffect(() => {
    if (modo !== 'crear' || puntos.length < 2) return;
    calcularRutaDibujada();
  }, [puntos]);

  const calcularRutaDibujada = async () => {
    if (puntos.length < 2) return;
    setCalculandoRuta(true);
    try {
      // Encadenar segmentos entre todos los waypoints
      const segmentos: Coord[] = [];
      for (let i = 0; i < puntos.length - 1; i++) {
        const tramo = await obtenerRutaOSRM(puntos[i], puntos[i+1], 'foot');
        if (tramo.length > 0) segmentos.push(...tramo[0]);
      }
      setRutaDibujada(segmentos.length > 0 ? segmentos : puntos);
    } catch {
      setRutaDibujada(puntos);
    } finally {
      setCalculandoRuta(false);
    }
  };

  const loadRutas = async () => {
    if (usuario?.id) {
      const r = await obtenerRutas(usuario.id).catch(() => []);
      setRutasGuardadas(r);
    }
  };

  // ── Buscar destino con rutas reales ─────────────────────────────────────────
  const handleBuscar = async () => {
    if (!destino.trim()) return;
    setBuscando(true);
    try {
      const coord = await buscarLugar(destino.trim(), miPos);
      if (!coord) {
        Alert.alert('No encontrado', 'No se encontró el lugar. Intenta con una dirección más específica.');
        return;
      }
      setDestinoCoord(coord);

      // Pedir la ruta principal + alternativas (OSRM foot)
      const [rutasPie, rutasBici] = await Promise.all([
        obtenerRutaOSRM(miPos, coord, 'foot', true),
        obtenerRutaOSRM(miPos, coord, 'foot', false),   // segunda variante
      ]);

      const opciones: RutaOpcion[] = [];

      // Ruta 1: principal (foot con alternativas)
      if (rutasPie.length > 0) {
        const puntosPrincipal = rutasPie[0];
        opciones.push({
          nombre: 'Ruta Principal',
          color: '#00C8FF',
          velKmh: 10,
          puntos: puntosPrincipal,
          distanciaM: totalDistM(puntosPrincipal),
        });
      }

      // Ruta 2: alternativa si OSRM la devolvió
      if (rutasPie.length > 1) {
        const puntosAlt = rutasPie[1];
        opciones.push({
          nombre: 'Ruta Alternativa',
          color: '#4CD964',
          velKmh: 9,
          puntos: puntosAlt,
          distanciaM: totalDistM(puntosAlt),
        });
      }

      // Ruta 3: variante (desviamos un punto intermedio y volvemos a calcular)
      const midLat = (miPos.latitude + coord.latitude) / 2;
      const midLon = (miPos.longitude + coord.longitude) / 2;
      const offset = 0.003;
      const waypoint: Coord = { latitude: midLat + offset, longitude: midLon + offset };
      const [seg1, seg2] = await Promise.all([
        obtenerRutaOSRM(miPos, waypoint, 'foot'),
        obtenerRutaOSRM(waypoint, coord, 'foot'),
      ]);
      if (seg1.length > 0 && seg2.length > 0) {
        const puntosVar = [...seg1[0], ...seg2[0]];
        opciones.push({
          nombre: 'Ruta Escénica',
          color: '#FF9500',
          velKmh: 8,
          puntos: puntosVar,
          distanciaM: totalDistM(puntosVar),
        });
      }

      // Fallback: si OSRM no respondió genera rutas genéricas
      if (opciones.length === 0) {
        ['Ruta A', 'Ruta B', 'Ruta C'].forEach((nombre, i) => {
          opciones.push({
            nombre,
            color: ['#00C8FF','#4CD964','#FF9500'][i],
            velKmh: 10 - i,
            puntos: [miPos, coord],
            distanciaM: haversineM(miPos, coord),
          });
        });
      }

      setRutasOpciones(opciones);
      setRutaSeleccionada(0);

      // Ajustar mapa para ver origen y destino
      const lats  = [miPos.latitude, coord.latitude];
      const lons  = [miPos.longitude, coord.longitude];
      const midLa = (Math.max(...lats) + Math.min(...lats)) / 2;
      const midLo = (Math.max(...lons) + Math.min(...lons)) / 2;
      const dLat  = (Math.max(...lats) - Math.min(...lats)) * 2.4 + 0.006;
      const dLon  = (Math.max(...lons) - Math.min(...lons)) * 2.4 + 0.006;
      mapRef.current?.animateToRegion({ latitude: midLa, longitude: midLo, latitudeDelta: dLat, longitudeDelta: dLon }, 900);
    } finally {
      setBuscando(false);
    }
  };

  // ── Iniciar carrera ──────────────────────────────────────────────────────────
  const handleIniciarRuta = async () => {
    const ruta = rutasOpciones[rutaSeleccionada];
    if (!ruta) return;
    const distM = ruta.distanciaM;
    Alert.alert(
      `Iniciar ${ruta.nombre}`,
      `Distancia: ${fmtDist(distM)}\nTiempo estimado: ${tiempoEstimado(distM, ruta.velKmh)}\n\n¿Guardar y empezar esta ruta?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Guardar e Iniciar', onPress: async () => {
          if (usuario?.id) {
            await guardarRuta(usuario.id, ruta.nombre, distM / 1000,
              Math.round((distM / 1000) / ruta.velKmh * 60), ruta.puntos);
          }
          router.push('/(tabs)/carrera');
        }},
      ]
    );
  };

  // ── Guardar ruta dibujada ────────────────────────────────────────────────────
  const handleGuardarCreada = async () => {
    if (puntos.length < 2) { Alert.alert('Ruta incompleta', 'Agrega al menos 2 puntos.'); return; }
    const nombre  = nombreRuta.trim() || `Mi ruta ${rutasGuardadas.length + 1}`;
    const puntosAGuardar = rutaDibujada.length > 0 ? rutaDibujada : puntos;
    const distM   = totalDistM(puntosAGuardar);
    if (usuario?.id) {
      await guardarRuta(usuario.id, nombre, distM / 1000, Math.round(distM / 1000 / 9 * 60), puntosAGuardar);
      Alert.alert('✅ Guardada', `"${nombre}" guardada.`);
      setPuntos([]); setNombreRuta(''); setRutaDibujada([]); loadRutas();
    }
  };

  const verRutaGuardada = (ruta: any) => {
    const coords: Coord[] = JSON.parse(ruta.coordenadas_json);
    setRutaVista(ruta);
    if (coords.length > 0) {
      const lats = coords.map((c: Coord) => c.latitude);
      const lons = coords.map((c: Coord) => c.longitude);
      mapRef.current?.animateToRegion({
        latitude:  (Math.max(...lats)+Math.min(...lats))/2,
        longitude: (Math.max(...lons)+Math.min(...lons))/2,
        latitudeDelta:  (Math.max(...lats)-Math.min(...lats))*1.9+0.006,
        longitudeDelta: (Math.max(...lons)-Math.min(...lons))*1.9+0.006,
      }, 700);
    }
  };

  const initRutaGuardada = (ruta: any) => {
    Alert.alert(`Iniciar ${ruta.nombre}`,
      `${ruta.distancia_km.toFixed(2)} km · ~${ruta.tiempo_estimado_min} min\n\n¿Empezar esta ruta?`,
      [{ text: 'Cancelar', style: 'cancel' }, { text: 'Iniciar', onPress: () => router.push('/(tabs)/carrera') }]
    );
  };

  const rutaActual = modo === 'buscar' && rutasOpciones.length > 0 ? rutasOpciones[rutaSeleccionada] : null;

  const MODOS: { key: Modo; label: string }[] = [
    { key: 'buscar',    label: '🔍 Buscar' },
    { key: 'crear',     label: '✏️ Dibujar' },
    { key: 'guardadas', label: '📋 Guardadas' },
  ];

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <LinearGradient colors={['#050A15', '#0A1020']} style={s.bg}>

        {/* Header */}
        <View style={[s.headerWrap, { paddingTop: insets.top + rs(10) }]}>
          <Text style={s.title}>Rutas</Text>
          <View style={s.modeRow}>
            {MODOS.map(m => (
              <TouchableOpacity
                key={m.key}
                style={[s.modeBtn, modo === m.key && s.modeBtnActive]}
                onPress={() => { setModo(m.key); setRutaVista(null); }}
              >
                <Text style={[s.modeBtnText, modo === m.key && s.modeBtnTextActive]}>{m.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Mapa – estándar (calles visibles) */}
        <View style={[s.mapWrap, { height: MAP_H }]}>
          <MapView
            ref={mapRef}
            style={s.map}
            provider={PROVIDER_DEFAULT}
            region={region}
            mapType="standard"          // ← calles visibles como Google Maps
            showsUserLocation
            showsMyLocationButton={false}
            showsTraffic={false}
            showsCompass={false}
            onPress={(e) => {
              if (modo === 'crear') {
                setPuntos(prev => [...prev, e.nativeEvent.coordinate]);
              }
            }}
          >
            {/* Rutas buscadas */}
            {modo === 'buscar' && rutasOpciones.map((r, i) => (
              <Polyline
                key={i}
                coordinates={r.puntos}
                strokeColor={i === rutaSeleccionada ? r.color : `${r.color}44`}
                strokeWidth={i === rutaSeleccionada ? rs(5) : rs(3)}
                lineDashPattern={i === rutaSeleccionada ? undefined : [8, 4]}
              />
            ))}
            {modo === 'buscar' && destinoCoord && (
              <>
                <Marker coordinate={miPos} pinColor="#4CD964" title="Mi posición" />
                <Marker coordinate={destinoCoord} pinColor="#FF3B30" title="Destino" />
              </>
            )}

            {/* Ruta dibujada (real por calles) */}
            {modo === 'crear' && rutaDibujada.length > 1 && (
              <Polyline coordinates={rutaDibujada} strokeColor="#00C8FF" strokeWidth={rs(4)} />
            )}
            {/* Fallback: línea directa si aún no calculó */}
            {modo === 'crear' && rutaDibujada.length < 2 && puntos.length > 1 && (
              <Polyline coordinates={puntos} strokeColor="rgba(0,200,255,0.4)" strokeWidth={rs(2)} lineDashPattern={[6,4]} />
            )}
            {/* Waypoints del dibujo */}
            {modo === 'crear' && puntos.map((p, i) => (
              <Marker
                key={i} coordinate={p}
                pinColor={i===0 ? '#4CD964' : i===puntos.length-1 ? '#FF3B30' : '#00C8FF'}
                title={i===0 ? 'Inicio' : i===puntos.length-1 ? 'Fin' : `Punto ${i+1}`}
              />
            ))}

            {/* Ruta guardada vista */}
            {modo === 'guardadas' && rutaVista && (() => {
              const coords: Coord[] = JSON.parse(rutaVista.coordenadas_json);
              return (
                <>
                  <Polyline coordinates={coords} strokeColor="#FF9500" strokeWidth={rs(4)} />
                  {coords.length > 0 && <Marker coordinate={coords[0]} pinColor="#4CD964" />}
                  {coords.length > 1 && <Marker coordinate={coords[coords.length-1]} pinColor="#FF3B30" />}
                </>
              );
            })()}
          </MapView>

          {/* Botón mi ubicación */}
          <TouchableOpacity
            style={s.myLocBtn}
            onPress={() => mapRef.current?.animateToRegion({ ...miPos, latitudeDelta: 0.008, longitudeDelta: 0.008 }, 500)}
          >
            <Text style={s.myLocText}>📍</Text>
          </TouchableOpacity>

          {/* Hint crear */}
          {modo === 'crear' && (
            <View style={s.mapHint}>
              {calculandoRuta
                ? <ActivityIndicator color="#00C8FF" size="small" />
                : <Text style={s.mapHintText}>
                    {puntos.length === 0 ? '📍 Toca el mapa para agregar puntos de ruta'
                      : `${puntos.length} puntos · ${fmtDist(totalDistM(rutaDibujada.length > 1 ? rutaDibujada : puntos))}`}
                  </Text>
              }
            </View>
          )}
        </View>

        {/* Panel inferior */}
        <View style={[s.panel, { paddingBottom: insets.bottom + rs(8) }]}>

          {/* ── MODO BUSCAR ── */}
          {modo === 'buscar' && (
            <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
              <View style={s.searchRow}>
                <View style={s.searchBox}>
                  <Text style={s.searchIcon}>🔍</Text>
                  <TextInput
                    style={s.searchInput}
                    placeholder="¿A dónde quieres correr?"
                    placeholderTextColor="rgba(255,255,255,0.32)"
                    value={destino}
                    onChangeText={setDestino}
                    onSubmitEditing={handleBuscar}
                    returnKeyType="search"
                    autoCorrect={false}
                  />
                  {destino.length > 0 && (
                    <TouchableOpacity onPress={() => { setDestino(''); setRutasOpciones([]); setDestinoCoord(null); }}>
                      <Text style={{ color: 'rgba(255,255,255,0.4)', fontSize: rs(16) }}>✕</Text>
                    </TouchableOpacity>
                  )}
                </View>
                <TouchableOpacity
                  style={[s.searchBtn, buscando && { opacity: 0.5 }]}
                  onPress={handleBuscar}
                  disabled={buscando}
                >
                  {buscando
                    ? <ActivityIndicator color="#fff" size="small" />
                    : <Text style={s.searchBtnText}>IR</Text>}
                </TouchableOpacity>
              </View>

              {rutasOpciones.length > 0 && (
                <>
                  <Text style={s.sectionLabel}>RUTAS POR CALLES</Text>
                  {rutasOpciones.map((r, i) => {
                    const sel = i === rutaSeleccionada;
                    return (
                      <TouchableOpacity
                        key={i}
                        style={[s.rutaOpcion, sel && { borderColor: r.color, backgroundColor: `${r.color}12` }]}
                        onPress={() => setRutaSeleccionada(i)}
                        activeOpacity={0.8}
                      >
                        <View style={[s.rutaOpcionDot, { backgroundColor: r.color }]} />
                        <View style={s.rutaOpcionInfo}>
                          <Text style={[s.rutaOpcionNombre, sel && { color: r.color }]}>{r.nombre}</Text>
                          <View style={s.rutaOpcionStats}>
                            <Text style={s.rutaOpcionStat}>📍 {fmtDist(r.distanciaM)}</Text>
                            <Text style={s.rutaOpcionStat}>⏱️ {tiempoEstimado(r.distanciaM, r.velKmh)}</Text>
                            <Text style={s.rutaOpcionStat}>⚡ {r.velKmh} km/h</Text>
                          </View>
                        </View>
                        {sel && <Text style={[s.selBadge, { color: r.color }]}>✓</Text>}
                      </TouchableOpacity>
                    );
                  })}

                  <TouchableOpacity style={s.btnIniciar} onPress={handleIniciarRuta} activeOpacity={0.85}>
                    <LinearGradient colors={['rgba(0,200,255,0.42)', 'rgba(0,200,255,0.15)']} style={s.btnIniciarGrad}>
                      <Text style={s.btnIniciarText}>🏃 INICIAR {rutasOpciones[rutaSeleccionada]?.nombre?.toUpperCase()}</Text>
                      <Text style={s.btnIniciarSub}>
                        {fmtDist(rutaActual?.distanciaM ?? 0)} · {tiempoEstimado(rutaActual?.distanciaM ?? 0, rutaActual?.velKmh ?? 9)}
                      </Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              )}

              {rutasOpciones.length === 0 && (
                <Text style={s.emptyHint}>Escribe un lugar, parque o calle para calcular rutas reales desde tu posición.</Text>
              )}
            </ScrollView>
          )}

          {/* ── MODO CREAR ── */}
          {modo === 'crear' && (
            <View style={s.creadorPanel}>
              <View style={s.inputBox}>
                <TextInput
                  style={s.nameInput}
                  placeholder="Nombre de la ruta (opcional)"
                  placeholderTextColor="rgba(255,255,255,0.30)"
                  value={nombreRuta}
                  onChangeText={setNombreRuta}
                  maxLength={40}
                />
              </View>
              {puntos.length > 1 && (
                <View style={s.statsRow}>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{fmtDist(totalDistM(rutaDibujada.length > 1 ? rutaDibujada : puntos))}</Text>
                    <Text style={s.statLbl}>DIST.</Text>
                  </View>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{tiempoEstimado(totalDistM(rutaDibujada.length > 1 ? rutaDibujada : puntos), 9)}</Text>
                    <Text style={s.statLbl}>TIEMPO EST.</Text>
                  </View>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{puntos.length}</Text>
                    <Text style={s.statLbl}>WAYPOINTS</Text>
                  </View>
                </View>
              )}
              <View style={s.btnRow}>
                <TouchableOpacity
                  style={s.btnSec}
                  onPress={() => { setPuntos(p => p.slice(0,-1)); }}
                  disabled={puntos.length===0}
                >
                  <Text style={s.btnSecText}>↩ Deshacer</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={s.btnSec}
                  onPress={() => { setPuntos([]); setNombreRuta(''); setRutaDibujada([]); }}
                  disabled={puntos.length===0}
                >
                  <Text style={s.btnSecText}>🗑️ Limpiar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[s.btnGuardar, puntos.length < 2 && { opacity: 0.3 }]}
                  onPress={handleGuardarCreada}
                  disabled={puntos.length < 2 || calculandoRuta}
                >
                  <Text style={s.btnGuardarText}>{calculandoRuta ? '⏳' : '💾 Guardar'}</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* ── MODO GUARDADAS ── */}
          {modo === 'guardadas' && (
            <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
              {rutasGuardadas.length === 0
                ? <Text style={s.emptyHint}>No tienes rutas guardadas aún.</Text>
                : rutasGuardadas.map(r => {
                  const isActiva = rutaVista?.id === r.id;
                  return (
                    <TouchableOpacity
                      key={r.id}
                      style={[s.savedCard, isActiva && s.savedCardActive]}
                      onPress={() => verRutaGuardada(r)}
                      activeOpacity={0.8}
                    >
                      <View style={s.savedCardHeader}>
                        <Text style={s.savedNombre}>{r.nombre}</Text>
                        <TouchableOpacity
                          onPress={() => Alert.alert('Eliminar', `¿Eliminar "${r.nombre}"?`, [
                            { text: 'Cancelar', style: 'cancel' },
                            { text: 'Eliminar', style: 'destructive', onPress: async () => {
                              await eliminarRuta(r.id); loadRutas();
                              if (rutaVista?.id === r.id) setRutaVista(null);
                            }},
                          ])}
                          hitSlop={{ top:8,bottom:8,left:8,right:8 }}
                        >
                          <Text style={{ fontSize: rs(16) }}>🗑️</Text>
                        </TouchableOpacity>
                      </View>
                      <View style={s.savedStats}>
                        <Text style={s.savedStat}>🏃 {r.distancia_km.toFixed(2)} km</Text>
                        <Text style={s.savedStat}>⏱️ ~{r.tiempo_estimado_min} min</Text>
                      </View>
                      <TouchableOpacity style={s.btnIniciarSmall} onPress={() => initRutaGuardada(r)}>
                        <Text style={s.btnIniciarSmallText}>▶ INICIAR ESTA RUTA</Text>
                      </TouchableOpacity>
                    </TouchableOpacity>
                  );
                })}
            </ScrollView>
          )}
        </View>
      </LinearGradient>
    </View>
  );
}

// ─── Estilos ───────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  bg:   { flex: 1 },

  headerWrap:    { paddingHorizontal: rs(16), paddingBottom: rs(4) },
  title:         { fontFamily: 'DaysOne_400Regular', fontSize: rs(20), color: '#fff', textAlign: 'center', marginBottom: rs(10) },
  modeRow:       { flexDirection: 'row', gap: rs(6), marginBottom: rs(8) },
  modeBtn: {
    flex: 1, height: rs(34), borderRadius: rs(17), justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
  },
  modeBtnActive:     { backgroundColor: 'rgba(0,200,255,0.16)', borderColor: 'rgba(0,200,255,0.4)' },
  modeBtnText:       { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.38)' },
  modeBtnTextActive: { color: '#00C8FF' },

  mapWrap: { marginHorizontal: rs(12), borderRadius: rs(16), overflow: 'hidden', position: 'relative' },
  map: { flex: 1 },

  myLocBtn: {
    position: 'absolute', top: rs(10), right: rs(10),
    backgroundColor: 'rgba(5,10,21,0.85)', borderRadius: rs(22),
    width: rs(44), height: rs(44), justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.3)',
  },
  myLocText: { fontSize: rs(20) },

  mapHint: {
    position: 'absolute', bottom: rs(8), left: rs(8), right: rs(8),
    backgroundColor: 'rgba(0,0,0,0.75)', borderRadius: rs(8),
    paddingHorizontal: rs(12), paddingVertical: rs(6), alignItems: 'center', minHeight: rs(28),
    justifyContent: 'center',
  },
  mapHintText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: '#00C8FF' },

  panel: { flex: 1, paddingHorizontal: rs(14), paddingTop: rs(10) },

  // Búsqueda
  searchRow:  { flexDirection: 'row', gap: rs(8), marginBottom: rs(10) },
  searchBox: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: rs(12),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)',
    height: rs(48), paddingHorizontal: rs(12), gap: rs(8),
  },
  searchIcon:  { fontSize: rs(16) },
  searchInput: { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: '#fff' },
  searchBtn: {
    width: rs(56), height: rs(48), borderRadius: rs(12), justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(0,200,255,0.25)', borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)',
  },
  searchBtnText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(14), color: '#fff', letterSpacing: 1 },

  sectionLabel: {
    fontFamily: 'DaysOne_400Regular', fontSize: rs(10),
    color: 'rgba(0,200,255,0.7)', letterSpacing: 2, marginBottom: rs(8),
  },

  rutaOpcion: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: rs(12),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    padding: rs(12), marginBottom: rs(8), gap: rs(10),
  },
  rutaOpcionDot:    { width: rs(10), height: rs(10), borderRadius: rs(5) },
  rutaOpcionInfo:   { flex: 1 },
  rutaOpcionNombre: { fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: '#fff', marginBottom: rs(4) },
  rutaOpcionStats:  { flexDirection: 'row', gap: rs(8), flexWrap: 'wrap' },
  rutaOpcionStat:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(10), color: 'rgba(255,255,255,0.52)' },
  selBadge:         { fontFamily: 'DaysOne_400Regular', fontSize: rs(18) },

  btnIniciar:    { borderRadius: rs(14), overflow: 'hidden', marginTop: rs(4), marginBottom: rs(10) },
  btnIniciarGrad: {
    paddingVertical: rs(14), paddingHorizontal: rs(16), alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)', borderRadius: rs(14),
  },
  btnIniciarText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(14), color: '#fff', letterSpacing: 1 },
  btnIniciarSub:  { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.52)', marginTop: rs(4) },

  emptyHint: {
    fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: 'rgba(255,255,255,0.3)',
    textAlign: 'center', marginTop: rs(20), lineHeight: rs(22),
  },

  // Crear
  creadorPanel: { gap: rs(8) },
  inputBox: {
    backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: rs(12),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
    height: rs(44), paddingHorizontal: rs(14), justifyContent: 'center',
  },
  nameInput: { fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: '#fff' },
  statsRow:  { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: rs(4) },
  statItem:  { alignItems: 'center' },
  statVal:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(17), color: '#00C8FF' },
  statLbl:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(8), color: 'rgba(255,255,255,0.38)', letterSpacing: 1 },
  btnRow:    { flexDirection: 'row', gap: rs(6) },
  btnSec: {
    flex: 1, height: rs(38), borderRadius: rs(10), justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
  },
  btnSecText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.62)' },
  btnGuardar: {
    flex: 1.5, height: rs(38), borderRadius: rs(10), justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(0,200,255,0.2)', borderWidth: 1, borderColor: 'rgba(0,200,255,0.45)',
  },
  btnGuardarText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(12), color: '#fff' },

  // Guardadas
  savedCard: {
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: rs(12),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', padding: rs(12), marginBottom: rs(8),
  },
  savedCardActive:  { borderColor: 'rgba(255,165,0,0.6)', backgroundColor: 'rgba(255,165,0,0.07)' },
  savedCardHeader:  { flexDirection: 'row', justifyContent: 'space-between', marginBottom: rs(6) },
  savedNombre:      { fontFamily: 'DaysOne_400Regular', fontSize: rs(14), color: '#fff', flex: 1 },
  savedStats:       { flexDirection: 'row', gap: rs(12), marginBottom: rs(8) },
  savedStat:        { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.52)' },
  btnIniciarSmall: {
    height: rs(34), borderRadius: rs(8), justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(76,217,100,0.18)', borderWidth: 1, borderColor: 'rgba(76,217,100,0.4)',
  },
  btnIniciarSmallText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(12), color: '#4CD964', letterSpacing: 1 },
});

@echo off
echo ============================================
echo     RUNVEX - INSTALACION FINAL v10
echo ============================================
echo.

:: Verificar Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js no encontrado.
    echo Descarga Node.js de: https://nodejs.org
    pause
    exit /b 1
)
echo [OK] Node.js encontrado

:: Instalar dependencias
echo.
echo Instalando dependencias...
call npm install --legacy-peer-deps
if errorlevel 1 (
    echo [ERROR] Fallo npm install
    pause
    exit /b 1
)
echo [OK] Dependencias instaladas

:: Verificar EAS CLI
npx eas-cli --version >nul 2>&1
if errorlevel 1 (
    echo Instalando EAS CLI...
    call npm install -g eas-cli
)
echo [OK] EAS CLI listo

echo.
echo ============================================
echo  Instalacion completa!
echo.
echo  Para compilar el APK ejecuta:
echo     GENERAR_APK_FINAL.bat
echo ============================================
pause

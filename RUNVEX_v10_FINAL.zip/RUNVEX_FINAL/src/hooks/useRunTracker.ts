/**
 * useRunTracker v10 FINAL — Sensores completos y corregidos
 *
 * SENSORES:
 *  - expo-location (GPS): Distancia, velocidad, elevación, coordenadas
 *  - expo-sensors Pedometer: Contador de pasos nativo del dispositivo
 *  - expo-sensors Accelerometer: Cadencia (pasos/min) y detección de pasos de respaldo
 *
 * BPM: Estimación fisiológica por zonas con ramp rate suavizado
 * CALORÍAS: Fórmula MET × peso × tiempo
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import * as Location from 'expo-location';
import { Pedometer, Accelerometer } from 'expo-sensors';
import { Platform, PermissionsAndroid } from 'react-native';

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface RunData {
  distanciaKm: number;
  tiempoSegundos: number;
  velocidadActual: number;
  velocidadPromedio: number;
  pasos: number;
  cadencia: number;
  bpm: number;
  bpmMaximo: number;
  calorias: number;
  elevacionAcumulada: number;
  altitudActual: number;
  pace: number;
  coordenadas: { latitude: number; longitude: number; altitude: number }[];
  corriendo: boolean;
  pausado: boolean;
}

// ─── Constantes fisiológicas ──────────────────────────────────────────────────

const BPM_BASE = 68;
const BPM_MAX  = 185;
const BPM_RAMP = 1.5;
const PESO_KG  = 70;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function longitudZancada(velKmh: number): number {
  if (velKmh <= 0)  return 0.72;
  if (velKmh < 3)   return 0.40 + (velKmh / 3) * 0.08;
  if (velKmh < 6)   return 0.48 + ((velKmh - 3) / 3) * 0.17;
  if (velKmh < 9)   return 0.65 + ((velKmh - 6) / 3) * 0.15;
  if (velKmh < 12)  return 0.80 + ((velKmh - 9) / 3) * 0.15;
  return Math.min(1.20, 0.95 + ((velKmh - 12) / 6) * 0.25);
}

function pasosGPS(distanciaM: number, velKmh: number): number {
  if (distanciaM <= 0) return 0;
  return Math.round(distanciaM / longitudZancada(velKmh));
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R    = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a    = Math.sin(dLat / 2) ** 2
    + Math.cos(lat1 * Math.PI / 180)
    * Math.cos(lat2 * Math.PI / 180)
    * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function estimarBPM(vel: number, t: number, prev: number): number {
  if (t === 0) return BPM_BASE;
  if (vel < 0.5) {
    if (t < 30) {
      const objetivo = BPM_BASE + Math.min(t, 30) * 0.8;
      const delta = objetivo - prev;
      const paso = Math.sign(delta) * Math.min(Math.abs(delta), BPM_RAMP);
      return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(prev + paso)));
    }
    return prev > BPM_BASE + 10
      ? Math.max(BPM_BASE + 10, Math.round(prev - BPM_RAMP * 0.5))
      : prev;
  }
  const pct = vel < 6
    ? 0.55 + (vel / 6) * 0.10
    : vel < 9
    ? 0.65 + ((vel - 6) / 3) * 0.10
    : vel < 12
    ? 0.75 + ((vel - 9) / 3) * 0.10
    : 0.85 + Math.min((vel - 12) / 8, 1) * 0.10;

  const objetivo = Math.round(BPM_BASE + pct * (BPM_MAX - BPM_BASE));
  const varianza = (Math.floor(Math.random() * 7) - 3) * 0.3;
  const delta    = objetivo - prev;
  const paso     = Math.sign(delta) * Math.min(Math.abs(delta), BPM_RAMP);
  return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(prev + paso + varianza)));
}

function calcCalorias(distKm: number, tiempoSeg: number, velKmh: number): number {
  const met = velKmh >= 16 ? 16.0
    : velKmh >= 14 ? 14.5
    : velKmh >= 12 ? 13.5
    : velKmh >= 10 ? 11.5
    : velKmh >= 8  ? 10.0
    : velKmh >= 6  ? 8.0
    : 4.5;
  return Math.round(met * PESO_KG * (tiempoSeg / 3600));
}

async function pedirPermisosAndroid(): Promise<void> {
  if (Platform.OS !== 'android') return;
  try {
    const perms: any[] = ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION'];
    if (Platform.Version >= 29) perms.push('ACTIVITY_RECOGNITION');
    if (Platform.Version >= 33) perms.push('POST_NOTIFICATIONS');
    for (const p of perms) {
      if ((PermissionsAndroid.PERMISSIONS as any)[p]) {
        await PermissionsAndroid.request((PermissionsAndroid.PERMISSIONS as any)[p]);
      }
    }
  } catch {}
}

// ─── Estado inicial ───────────────────────────────────────────────────────────

const INICIAL: RunData = {
  distanciaKm: 0, tiempoSegundos: 0,
  velocidadActual: 0, velocidadPromedio: 0,
  pasos: 0, cadencia: 0,
  bpm: 0, bpmMaximo: 0,
  calorias: 0, elevacionAcumulada: 0, altitudActual: 0,
  pace: 0, coordenadas: [], corriendo: false, pausado: false,
};

// ─── Hook principal ───────────────────────────────────────────────────────────

export function useRunTracker() {
  const [datos,   setDatos]   = useState<RunData>(INICIAL);
  const [permGPS, setPermGPS] = useState(false);

  const timer    = useRef<ReturnType<typeof setInterval> | null>(null);
  const locSub   = useRef<Location.LocationSubscription | null>(null);
  const pedSub   = useRef<{ remove: () => void } | null>(null);
  const accelSub = useRef<{ remove: () => void } | null>(null);

  const pedActivo   = useRef(false);
  const accelActivo = useRef(false);

  const distM      = useRef(0);
  const tiempo     = useRef(0);
  const pasosRef   = useRef(0);
  const elevAcum   = useRef(0);
  const velRef     = useRef(0);
  const bpmRef     = useRef(BPM_BASE);
  const bpmMaxRef  = useRef(0);
  const coords     = useRef<{ latitude: number; longitude: number; altitude: number }[]>([]);
  const altBuf     = useRef<number[]>([]);
  const prevAltSmooth = useRef(0);

  const accelMagBuf    = useRef<number[]>([]);
  const lastPeak       = useRef(0);
  const prevMag        = useRef(0);
  const accelPasos     = useRef(0);
  const cadenciaRef    = useRef(0);
  const stepTimestamps = useRef<number[]>([]);

  // Rastrear pasos iniciales del pedómetro para calcular delta
  const pedBaseRef = useRef(0);
  const pedDeltaRef = useRef(0);

  useEffect(() => {
    (async () => {
      await pedirPermisosAndroid();
      const { status } = await Location.requestForegroundPermissionsAsync();
      setPermGPS(status === 'granted');
    })();
    return () => _stop();
  }, []);

  // ── Pedometer nativo ──────────────────────────────────────────────────────

  const intentarPedometro = useCallback(async () => {
    try {
      const avail = await Pedometer.isAvailableAsync();
      if (!avail) {
        console.log('[Pedometer] No disponible en este dispositivo');
        return;
      }

      pedBaseRef.current  = 0;
      pedDeltaRef.current = 0;
      let primeraLectura  = true;

      pedSub.current = Pedometer.watchStepCount(result => {
        if (result.steps > 0) {
          pedActivo.current = true;
          if (primeraLectura) {
            pedBaseRef.current = result.steps;
            primeraLectura = false;
          }
          // Delta relativo desde que empezó la carrera
          const delta = result.steps - pedBaseRef.current;
          pedDeltaRef.current = Math.max(0, delta);
          pasosRef.current    = accelPasos.current + pedDeltaRef.current;
          setDatos(p => ({ ...p, pasos: pasosRef.current }));
        }
      });

      // Si en 8 s no llega ningún evento, el pedómetro no funciona en este dispositivo
      setTimeout(() => {
        if (!pedActivo.current && pedSub.current) {
          pedSub.current.remove();
          pedSub.current = null;
          console.log('[Pedometer] Sin eventos en 8s, usando acelerómetro');
        }
      }, 8000);
    } catch (e) {
      console.log('[Pedometer] Error:', e);
    }
  }, []);

  // ── Acelerómetro para cadencia y pasos de respaldo ───────────────────────

  const iniciarAcelerometro = useCallback(() => {
    accelPasos.current     = 0;
    lastPeak.current       = 0;
    prevMag.current        = 0;
    stepTimestamps.current = [];
    accelMagBuf.current    = [];

    try {
      Accelerometer.setUpdateInterval(20); // 50 Hz

      accelSub.current = Accelerometer.addListener(({ x, y, z }) => {
        accelActivo.current = true;
        const mag = Math.sqrt(x * x + y * y + z * z);

        accelMagBuf.current.push(mag);
        if (accelMagBuf.current.length > 60) accelMagBuf.current.shift();

        const sorted  = [...accelMagBuf.current].sort((a, b) => a - b);
        const mediana = sorted[Math.floor(sorted.length / 2)];
        const umbral  = mediana + 0.30;

        const ahora    = Date.now();
        const cooldown = 260;

        if (
          mag > umbral
          && prevMag.current <= umbral
          && ahora - lastPeak.current > cooldown
        ) {
          lastPeak.current = ahora;
          accelPasos.current += 1;

          // Solo usar si el pedómetro nativo no está activo
          if (!pedActivo.current) {
            pasosRef.current = accelPasos.current;
            setDatos(p => ({ ...p, pasos: accelPasos.current }));
          }

          // Cadencia: ventana deslizante de 10 s
          stepTimestamps.current.push(ahora);
          const ventana = 10000;
          stepTimestamps.current = stepTimestamps.current.filter(t => ahora - t < ventana);

          if (stepTimestamps.current.length >= 4) {
            const ppm = Math.round(stepTimestamps.current.length / (ventana / 1000) * 60);
            cadenciaRef.current = Math.min(ppm, 220); // limitar a 220 pasos/min
            setDatos(p => ({ ...p, cadencia: cadenciaRef.current }));
          }
        }
        prevMag.current = mag;
      });
    } catch (e) {
      console.log('[Accelerometer] Error:', e);
    }
  }, []);

  // ── GPS ───────────────────────────────────────────────────────────────────

  const suscribirGPS = useCallback(async () => {
    try {
      locSub.current = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.BestForNavigation,
          distanceInterval: 2,
          timeInterval: 1000,
        },
        loc => {
          const { latitude, longitude, altitude, speed } = loc.coords;
          const alt = altitude != null ? altitude : 0;

          // Velocidad GPS con EMA (filtro exponencial)
          const velGps = speed != null && speed > 0.2 ? speed * 3.6 : 0;
          velRef.current = velRef.current === 0
            ? velGps
            : velRef.current * 0.6 + velGps * 0.4;

          // Distancia Haversine con filtro de ruido
          const prev  = coords.current;
          let deltaM  = 0;
          if (prev.length > 0) {
            const last = prev[prev.length - 1];
            const d = haversine(last.latitude, last.longitude, latitude, longitude);
            if (d > 1 && d < 80) {
              distM.current += d;
              deltaM = d;
            }
          }

          // Pasos GPS solo si no hay sensores nativos
          if (!pedActivo.current && !accelActivo.current && deltaM > 0) {
            const nuevos = pasosGPS(distM.current, velRef.current);
            pasosRef.current = nuevos;
            setDatos(p => ({ ...p, pasos: nuevos }));
          }

          // Elevación con buffer de suavizado (5 lecturas)
          altBuf.current.push(alt);
          if (altBuf.current.length > 5) altBuf.current.shift();
          const altSmooth = altBuf.current.reduce((a, b) => a + b, 0) / altBuf.current.length;

          if (altBuf.current.length >= 3) {
            const dif = altSmooth - prevAltSmooth.current;
            if (dif > 0.5) elevAcum.current += dif;
            prevAltSmooth.current = altSmooth;
          }

          coords.current = [...prev, { latitude, longitude, altitude: altSmooth }];

          setDatos(p => ({
            ...p,
            distanciaKm:        parseFloat((distM.current / 1000).toFixed(4)),
            velocidadActual:    parseFloat(velRef.current.toFixed(1)),
            elevacionAcumulada: parseFloat(elevAcum.current.toFixed(1)),
            altitudActual:      parseFloat(altSmooth.toFixed(1)),
            coordenadas:        coords.current,
          }));
        }
      );
    } catch (e) {
      console.log('[GPS] Error al suscribir:', e);
    }
  }, []);

  // ── Timer 1 s: tiempo, BPM, calorías, pace ───────────────────────────────

  const iniciarTimer = useCallback(() => {
    timer.current = setInterval(() => {
      tiempo.current += 1;
      const t   = tiempo.current;
      const dK  = distM.current / 1000;
      const vel = velRef.current;

      const bpm = estimarBPM(vel, t, bpmRef.current);
      bpmRef.current = bpm;
      if (bpm > bpmMaxRef.current) bpmMaxRef.current = bpm;

      const pace  = dK > 0.001 && t > 0 ? t / dK : 0;
      const vProm = t > 0 ? (dK / t) * 3600 : 0;
      const cal   = calcCalorias(dK, t, vel);

      // Prioridad de pasos: pedómetro > acelerómetro > GPS
      const pasos = pedActivo.current
        ? pasosRef.current
        : accelActivo.current
        ? accelPasos.current
        : pasosGPS(distM.current, vel);

      setDatos(p => ({
        ...p,
        tiempoSegundos:    t,
        bpm,
        bpmMaximo:         bpmMaxRef.current,
        calorias:          cal,
        velocidadPromedio: parseFloat(vProm.toFixed(2)),
        pace,
        pasos,
        cadencia:          cadenciaRef.current,
      }));
    }, 1000);
  }, []);

  // ── INICIAR ───────────────────────────────────────────────────────────────

  const iniciarCarrera = useCallback(async () => {
    // Pedir permisos si no los tiene
    if (!permGPS) {
      await pedirPermisosAndroid();
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      setPermGPS(true);
    }

    // Reset completo de todos los acumuladores
    distM.current        = 0;
    tiempo.current       = 0;
    pasosRef.current     = 0;
    elevAcum.current     = 0;
    velRef.current       = 0;
    bpmRef.current       = BPM_BASE;
    bpmMaxRef.current    = 0;
    coords.current       = [];
    altBuf.current       = [];
    prevAltSmooth.current = 0;
    pedActivo.current    = false;
    accelActivo.current  = false;
    accelPasos.current   = 0;
    cadenciaRef.current  = 0;
    pedBaseRef.current   = 0;
    pedDeltaRef.current  = 0;

    setDatos({ ...INICIAL, bpm: BPM_BASE, corriendo: true, pausado: false });

    iniciarTimer();
    await suscribirGPS();
    iniciarAcelerometro();
    await intentarPedometro();
  }, [permGPS, iniciarTimer, suscribirGPS, iniciarAcelerometro, intentarPedometro]);

  // ── PAUSAR ────────────────────────────────────────────────────────────────

  const pausarCarrera = useCallback(() => {
    _stop();
    setDatos(p => ({ ...p, corriendo: false, pausado: true }));
  }, []);

  // ── REANUDAR ──────────────────────────────────────────────────────────────

  const reanudarCarrera = useCallback(async () => {
    if (!permGPS) return;
    // Conservar contadores, reiniciar flags de sensores
    pedActivo.current   = false;
    accelActivo.current = false;
    setDatos(p => ({ ...p, corriendo: true, pausado: false }));
    iniciarTimer();
    await suscribirGPS();
    iniciarAcelerometro();
    await intentarPedometro();
  }, [permGPS, iniciarTimer, suscribirGPS, iniciarAcelerometro, intentarPedometro]);

  // ── TERMINAR ──────────────────────────────────────────────────────────────

  const terminarCarrera = useCallback(() => {
    _stop();
    const dK    = distM.current / 1000;
    const pasos = pedActivo.current
      ? pasosRef.current
      : accelActivo.current
      ? accelPasos.current
      : pasosGPS(distM.current, velRef.current);

    const res = {
      distanciaKm:       dK,
      tiempoSegundos:    tiempo.current,
      velocidadPromedio: tiempo.current > 0 ? (dK / tiempo.current) * 3600 : 0,
      pasos,
      cadencia:          cadenciaRef.current,
      calorias:          calcCalorias(dK, tiempo.current, velRef.current),
      bpmPromedio:       bpmRef.current,
      bpmMaximo:         bpmMaxRef.current,
      elevacionM:        elevAcum.current,
      coordenadas:       coords.current,
    };
    setDatos(p => ({ ...p, corriendo: false, pausado: false }));
    return res;
  }, []);

  // ── Limpieza de suscripciones ─────────────────────────────────────────────

  function _stop() {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    if (locSub.current)   { locSub.current.remove();   locSub.current   = null; }
    if (pedSub.current)   { pedSub.current.remove();   pedSub.current   = null; }
    if (accelSub.current) { accelSub.current.remove(); accelSub.current = null; }
  }

  return {
    datos,
    iniciarCarrera,
    pausarCarrera,
    reanudarCarrera,
    terminarCarrera,
    permGPS,
  };
}

// ─── Utilidades de formato ────────────────────────────────────────────────────

export const formatTiempo = (s: number): string => {
  if (s < 0) s = 0;
  const h   = Math.floor(s / 3600);
  const m   = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) {
    return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
  }
  return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
};

export const formatPace = (p: number): string => {
  if (!p || p <= 0 || !isFinite(p)) return '--:--';
  const min = Math.floor(p / 60);
  const seg = String(Math.floor(p % 60)).padStart(2, '0');
  return `${min}:${seg} /km`;
};

@echo off
echo ============================================
echo     RUNVEX - GENERAR APK FINAL
echo ============================================
echo.
echo Este proceso subira el proyecto a EAS Build
echo y generara un APK para Android.
echo.
echo Asegurate de haber iniciado sesion en Expo:
echo   npx eas-cli login
echo.
pause

echo Compilando APK...
call npx eas build --platform android --profile preview --non-interactive

if errorlevel 1 (
    echo.
    echo [ERROR] Fallo la compilacion.
    echo Verifica que:
    echo  1. Tienes cuenta en expo.dev
    echo  2. Ejecutaste: npx eas-cli login
    echo  3. El proyecto tiene acceso a internet
) else (
    echo.
    echo [OK] APK compilado exitosamente!
    echo Descarga el APK desde: https://expo.dev
)
pause

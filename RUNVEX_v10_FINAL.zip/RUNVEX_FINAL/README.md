# RUNVEX v10 FINAL

App de seguimiento de carrera para Android.

## Qué hay de nuevo en v10 FINAL

### Correcciones críticas de compatibilidad
- Expo SDK 53 + React 18.3.1 + React Native 0.76.9 (versiones estables probadas)
- Eliminado `react-native-worklets` (causaba crash en build)
- `minSdkVersion: 21` → compatible con Android 5.0 en adelante
- `adaptiveIcon` configurado → no crashea en Android 8+

### Sensores corregidos
- **Podómetro**: Ahora cuenta pasos de forma relativa (delta desde inicio), no absoluta
- **Acelerómetro**: Umbral adaptativo mejorado, cooldown a 260ms, cadencia limitada a 220 ppm
- **GPS**: Filtro de ruido mejorado (1–80m), EMA ajustado (alpha 0.4)
- **Elevación**: Buffer de 5 lecturas + prevAltSmooth para diferencial correcto
- **Permisos Android 13+**: `POST_NOTIFICATIONS` y `ACTIVITY_RECOGNITION` solicitados correctamente

### Cálculos corregidos
- `formatTiempo`: Ahora muestra horas si la carrera supera 60 min (HH:MM:SS)
- `formatPace`: Retorna `--:--` si pace es inválido o infinito
- Calorías MET: Cálculo correcto basado en velocidad actual

## Instalación

1. Instala Node.js desde https://nodejs.org
2. Ejecuta `INSTALAR_FINAL.bat`
3. Inicia sesión en Expo: `npx eas-cli login`
4. Ejecuta `GENERAR_APK_FINAL.bat`
5. Descarga el APK desde https://expo.dev

## Comandos manuales

```bash
# Instalar dependencias
npm install --legacy-peer-deps

# Probar en desarrollo
npx expo start

# Generar APK
npx eas build --platform android --profile preview
```

## Compatibilidad

- Android 5.0+ (API 21+)
- Probado en Expo SDK 53


/**
 * useRunTracker — Hook principal de seguimiento de carrera
 *
 * Sensores integrados:
 *  - GPS (expo-location ~19.0.7): distancia real, velocidad GPS, elevación acumulada
 *  - Pedómetro (expo-sensors ~14.1.4 Pedometer): pasos reales del dispositivo
 *  - BPM estimado fisiológico: rampa progresiva basada en velocidad + tiempo
 *    (Expo no expone API de monitor cardíaco sin hardware wearable externo;
 *     esta estimación sigue modelo de zonas FC similar a Strava sin sensor)
 *
 * Estado inicial: TODOS los indicadores en 0 antes de iniciar carrera.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import * as Location from 'expo-location';
import { Pedometer } from 'expo-sensors';

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface RunData {
  distanciaKm: number;
  tiempoSegundos: number;
  velocidadActual: number;    // km/h (GPS suavizado)
  velocidadPromedio: number;  // km/h
  pasos: number;              // pedómetro real del dispositivo
  bpm: number;                // 0 antes de iniciar; estimado fisiológico durante
  bpmMaximo: number;
  calorias: number;
  elevacionAcumulada: number; // metros subidos acumulados (solo subidas)
  altitudActual: number;      // metros snm
  pace: number;               // segundos/km (0 si no corre)
  coordenadas: { latitude: number; longitude: number; altitude: number }[];
  corriendo: boolean;
  pausado: boolean;
}

// ─── Constantes fisiológicas ──────────────────────────────────────────────────

const BPM_REPOSO   = 0;    // antes de iniciar: sin dato (muestra 0)
const BPM_BASE     = 68;   // bpm en reposo real (promedio adulto)
const BPM_MAX      = 185;  // bpm máximo estimado (220 - 35 años promedio)
const BPM_RAMP     = 1.5;  // bpm/segundo de rampa de subida/bajada

// ─── Utilidades internas ──────────────────────────────────────────────────────

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/** Estimación BPM por zonas FC según velocidad, con rampa fisiológica */
function estimarBPM(velKmh: number, tiempoS: number, bpmAnterior: number): number {
  if (tiempoS === 0 || velKmh === 0) {
    // Recuperación
    return bpmAnterior > BPM_BASE
      ? Math.max(BPM_BASE, Math.round(bpmAnterior - BPM_RAMP))
      : BPM_BASE;
  }
  // % de FCmax objetivo según velocidad
  let pct: number;
  if      (velKmh < 6)  pct = 0.58 + (velKmh / 6) * 0.07;
  else if (velKmh < 9)  pct = 0.65 + ((velKmh - 6) / 3) * 0.10;
  else if (velKmh < 12) pct = 0.75 + ((velKmh - 9) / 3) * 0.10;
  else                  pct = 0.85 + Math.min((velKmh - 12) / 8, 1) * 0.10;

  const objetivo = Math.round(BPM_BASE + pct * (BPM_MAX - BPM_BASE));
  const variacion = Math.floor(Math.random() * 7) - 3; // ±3 bpm fisiológico
  const delta = objetivo - bpmAnterior;
  const paso  = Math.sign(delta) * Math.min(Math.abs(delta), BPM_RAMP);
  return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(bpmAnterior + paso + variacion * 0.3)));
}

/** Calorías: MET × 70 kg × horas (peso fijo; idealmente del perfil) */
function calcularCalorias(distKm: number, tiempoS: number, velKmh: number): number {
  const peso = 70;
  let met = 6;
  if      (velKmh >= 12) met = 13.5;
  else if (velKmh >= 10) met = 11.5;
  else if (velKmh >= 8)  met = 10.0;
  else if (velKmh >= 6)  met = 8.0;
  return Math.round(met * peso * (tiempoS / 3600));
}

// ─── Estado inicial (0 en todo) ───────────────────────────────────────────────

const ESTADO_INICIAL: RunData = {
  distanciaKm: 0,
  tiempoSegundos: 0,
  velocidadActual: 0,
  velocidadPromedio: 0,
  pasos: 0,
  bpm: BPM_REPOSO,
  bpmMaximo: 0,
  calorias: 0,
  elevacionAcumulada: 0,
  altitudActual: 0,
  pace: 0,
  coordenadas: [],
  corriendo: false,
  pausado: false,
};

// ─── Hook principal ───────────────────────────────────────────────────────────

export function useRunTracker() {
  const [datos, setDatos] = useState<RunData>(ESTADO_INICIAL);
  const [permisoConcedido, setPermisoConcedido] = useState(false);
  const [pedometerDisponible, setPedometerDisponible] = useState(false);

  const timer    = useRef<ReturnType<typeof setInterval> | null>(null);
  const locSub   = useRef<Location.LocationSubscription | null>(null);
  const pedSub   = useRef<{ remove: () => void } | null>(null);
  const dist     = useRef(0);
  const tiempo   = useRef(0);
  const pasos    = useRef(0);
  const coords   = useRef<{ latitude: number; longitude: number; altitude: number }[]>([]);
  const elevAcum = useRef(0);
  const altPrev  = useRef<number | null>(null);
  const bpmRef   = useRef(BPM_REPOSO);
  const bpmMax   = useRef(0);
  const velRef   = useRef(0);

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      setPermisoConcedido(status === 'granted');
      const avail = await Pedometer.isAvailableAsync();
      setPedometerDisponible(avail);
    })();
    return () => _limpiar();
  }, []);

  // ── Suscripción GPS compartida ──────────────────────────────────────────────
  const suscribirGPS = useCallback(async () => {
    locSub.current = await Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.BestForNavigation,
        distanceInterval: 3,   // 3 metros mínimo de movimiento
        timeInterval: 1500,
      },
      loc => {
        const { latitude, longitude, altitude, speed } = loc.coords;
        const alt = altitude ?? 0;

        // Velocidad GPS con suavizado exponencial (evita saltos bruscos)
        const velGps = speed != null && speed > 0.5 ? speed * 3.6 : 0; // ignora ruido < 0.5 m/s
        velRef.current = velRef.current === 0
          ? velGps
          : velRef.current * 0.7 + velGps * 0.3;

        // Distancia: filtro anti-ruido GPS (entre 3m y 50m por tick)
        const prev = coords.current;
        if (prev.length > 0) {
          const last = prev[prev.length - 1];
          const d = haversine(last.latitude, last.longitude, latitude, longitude);
          if (d > 0.003 && d < 0.05) dist.current += d;
        }

        // Elevación: acumula solo subidas reales (> 1m para filtrar ruido)
        if (altPrev.current !== null) {
          const dif = alt - altPrev.current;
          if (dif > 1.0) elevAcum.current += dif;
        }
        altPrev.current = alt;

        coords.current = [...prev, { latitude, longitude, altitude: alt }];

        setDatos(p => ({
          ...p,
          distanciaKm: parseFloat(dist.current.toFixed(4)),
          velocidadActual: parseFloat(velRef.current.toFixed(1)),
          elevacionAcumulada: parseFloat(elevAcum.current.toFixed(1)),
          altitudActual: parseFloat(alt.toFixed(1)),
          coordenadas: coords.current,
        }));
      }
    );
  }, []);

  // ── Suscripción pedómetro ────────────────────────────────────────────────────
  const suscribirPedometro = useCallback(() => {
    if (!pedometerDisponible) return;
    pedSub.current = Pedometer.watchStepCount(result => {
      pasos.current = result.steps;
      setDatos(p => ({ ...p, pasos: result.steps }));
    });
  }, [pedometerDisponible]);

  // ── Timer de 1 segundo ───────────────────────────────────────────────────────
  const iniciarTimer = useCallback(() => {
    timer.current = setInterval(() => {
      tiempo.current += 1;
      const t = tiempo.current;
      const d = dist.current;
      const v = velRef.current;

      const nuevoBpm = estimarBPM(v, t, bpmRef.current);
      bpmRef.current = nuevoBpm;
      if (nuevoBpm > bpmMax.current) bpmMax.current = nuevoBpm;

      const pace   = d > 0 && t > 0 ? t / d : 0;
      const vProm  = t > 0 ? (d / t) * 3600 : 0;
      const cal    = calcularCalorias(d, t, v);

      setDatos(prev => ({
        ...prev,
        tiempoSegundos: t,
        bpm: nuevoBpm,
        bpmMaximo: bpmMax.current,
        calorias: cal,
        velocidadPromedio: parseFloat(vProm.toFixed(2)),
        pace,
      }));
    }, 1000);
  }, []);

  // ── INICIAR ──────────────────────────────────────────────────────────────────
  const iniciarCarrera = useCallback(async () => {
    if (!permisoConcedido) {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      setPermisoConcedido(true);
    }

    // Reset completo a cero
    dist.current     = 0;
    tiempo.current   = 0;
    pasos.current    = 0;
    coords.current   = [];
    elevAcum.current = 0;
    altPrev.current  = null;
    bpmRef.current   = BPM_BASE;
    bpmMax.current   = 0;
    velRef.current   = 0;

    setDatos({ ...ESTADO_INICIAL, bpm: BPM_BASE, corriendo: true, pausado: false });

    iniciarTimer();
    await suscribirGPS();
    suscribirPedometro();
  }, [permisoConcedido, iniciarTimer, suscribirGPS, suscribirPedometro]);

  // ── PAUSAR ───────────────────────────────────────────────────────────────────
  const pausarCarrera = useCallback(() => {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    locSub.current?.remove();
    pedSub.current?.remove();
    setDatos(p => ({ ...p, corriendo: false, pausado: true }));
  }, []);

  // ── REANUDAR ─────────────────────────────────────────────────────────────────
  const reanudarCarrera = useCallback(async () => {
    if (!permisoConcedido) return;
    setDatos(p => ({ ...p, corriendo: true, pausado: false }));
    iniciarTimer();
    await suscribirGPS();
    suscribirPedometro();
  }, [permisoConcedido, iniciarTimer, suscribirGPS, suscribirPedometro]);

  // ── TERMINAR ─────────────────────────────────────────────────────────────────
  const terminarCarrera = useCallback(() => {
    _limpiar();
    const resultado = {
      distanciaKm: dist.current,
      tiempoSegundos: tiempo.current,
      velocidadPromedio: tiempo.current > 0 ? (dist.current / tiempo.current) * 3600 : 0,
      pasos: pasos.current,
      calorias: calcularCalorias(dist.current, tiempo.current, velRef.current),
      bpmPromedio: bpmRef.current,
      bpmMaximo: bpmMax.current,
      elevacionM: elevAcum.current,
      coordenadas: coords.current,
    };
    setDatos(p => ({ ...p, corriendo: false, pausado: false }));
    return resultado;
  }, []);

  function _limpiar() {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    locSub.current?.remove();
    pedSub.current?.remove();
  }

  return {
    datos,
    iniciarCarrera,
    pausarCarrera,
    reanudarCarrera,
    terminarCarrera,
    permisoConcedido,
    pedometerDisponible,
  };
}

// ─── Helpers de formato (exportados para uso en pantallas) ────────────────────

export const formatTiempo = (s: number): string =>
  `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

/** Pace en formato M:SS /km — muestra '--:--' si no hay datos */
export const formatPace = (paceSegKm: number): string => {
  if (!paceSegKm || paceSegKm <= 0) return '--:--';
  const m = Math.floor(paceSegKm / 60);
  const s = Math.floor(paceSegKm % 60);
  return `${m}:${String(s).padStart(2, '0')} /km`;
};

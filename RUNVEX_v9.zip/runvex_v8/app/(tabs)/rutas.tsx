import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Alert, TextInput, ActivityIndicator, StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Polyline, PROVIDER_DEFAULT } from 'react-native-maps';
import * as Location from 'expo-location';
import { useFocusEffect, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../src/hooks/useAuth';
import { guardarRuta, obtenerRutas, eliminarRuta } from '../../src/database/database';

interface Coord { latitude: number; longitude: number; }

// ─── Helpers ──────────────────────────────────────────────────────────────────
function haversineM(a: Coord, b: Coord): number {
  const R = 6371000;
  const dLat = (b.latitude - a.latitude) * Math.PI / 180;
  const dLon = (b.longitude - a.longitude) * Math.PI / 180;
  const x = Math.sin(dLat/2)**2 +
    Math.cos(a.latitude*Math.PI/180)*Math.cos(b.latitude*Math.PI/180)*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1-x));
}
function totalDistM(coords: Coord[]): number {
  let d = 0;
  for (let i = 1; i < coords.length; i++) d += haversineM(coords[i-1], coords[i]);
  return d;
}
function fmtDist(m: number): string {
  return m >= 1000 ? `${(m/1000).toFixed(2)} km` : `${Math.round(m)} m`;
}
function tiempoEstimado(distM: number, velKmh: number): string {
  const min = Math.round((distM / 1000) / velKmh * 60);
  if (min < 60) return `~${min} min`;
  return `~${Math.floor(min/60)}h ${min%60}min`;
}

// ─── Geocoding restringido a México con Nominatim ────────────────────────────
async function buscarLugar(query: string, cerca: Coord): Promise<Coord | null> {
  try {
    // countrycodes=mx restringe resultados a México
    // viewbox limita al área de México aproximada
    const viewbox = '-118.4,14.5,-86.7,32.7'; // longitud min/max, latitud min/max
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query + ', México')}&format=json&limit=5&countrycodes=mx&viewbox=${viewbox}&bounded=0&lat=${cerca.latitude}&lon=${cerca.longitude}`;
    const res  = await fetch(url, { headers: { 'User-Agent': 'RunvexApp/1.0' } });
    const data = await res.json();
    if (data.length === 0) return null;

    // Tomar el resultado más cercano a la posición actual
    let best = data[0];
    let bestDist = Infinity;
    for (const item of data) {
      const d = Math.abs(parseFloat(item.lat) - cerca.latitude) +
                Math.abs(parseFloat(item.lon) - cerca.longitude);
      if (d < bestDist) { bestDist = d; best = item; }
    }
    return { latitude: parseFloat(best.lat), longitude: parseFloat(best.lon) };
  } catch {
    return null;
  }
}

// ─── Rutas reales por calles usando OSRM ─────────────────────────────────────
// OSRM ofrece 3 alternativas de rutas por calles reales
interface RutaOpcion {
  nombre: string;
  color: string;
  velKmh: number;
  puntos: Coord[];
}

function decodePolyline(encoded: string): Coord[] {
  const result: Coord[] = [];
  let index = 0, lat = 0, lng = 0;
  while (index < encoded.length) {
    let b, shift = 0, result2 = 0;
    do { b = encoded.charCodeAt(index++) - 63; result2 |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dlat = ((result2 & 1) ? ~(result2 >> 1) : (result2 >> 1)); lat += dlat;
    shift = 0; result2 = 0;
    do { b = encoded.charCodeAt(index++) - 63; result2 |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dlng = ((result2 & 1) ? ~(result2 >> 1) : (result2 >> 1)); lng += dlng;
    result.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
  }
  return result;
}

async function fetchRutasOSRM(origen: Coord, destino: Coord): Promise<RutaOpcion[]> {
  try {
    const url = `https://router.project-osrm.org/route/v1/foot/${origen.longitude},${origen.latitude};${destino.longitude},${destino.latitude}?alternatives=true&geometries=polyline&overview=full`;
    const res  = await fetch(url);
    const data = await res.json();

    if (!data.routes || data.routes.length === 0) return [];

    const colores = ['#00C8FF', '#4CD964', '#FF9500'];
    const nombres = ['Ruta Principal', 'Ruta Alternativa', 'Ruta Panorámica'];

    return data.routes.slice(0, 3).map((route: any, i: number) => ({
      nombre:  nombres[i] ?? `Ruta ${i + 1}`,
      color:   colores[i] ?? '#FFFFFF',
      velKmh:  9,
      puntos:  decodePolyline(route.geometry),
    }));
  } catch {
    return [];
  }
}

// ─── Pantalla ─────────────────────────────────────────────────────────────────
type Modo = 'buscar' | 'crear' | 'guardadas';

export default function RutasScreen() {
  const { usuario } = useAuth();
  const router      = useRouter();
  const insets      = useSafeAreaInsets();
  const mapRef      = useRef<MapView>(null);

  const [modo, setModo]             = useState<Modo>('buscar');
  const [miPos, setMiPos]           = useState<Coord>({ latitude: 19.2869, longitude: -99.6531 });
  const [region, setRegion]         = useState({ latitude: 19.2869, longitude: -99.6531, latitudeDelta: 0.01, longitudeDelta: 0.01 });
  const [buscando, setBuscando]     = useState(false);
  const [destino, setDestino]       = useState('');
  const [rutasOpciones, setRutasOpciones] = useState<RutaOpcion[]>([]);
  const [rutaSeleccionada, setRutaSeleccionada] = useState<number>(0);
  const [destinoCoord, setDestinoCoord] = useState<Coord | null>(null);

  // Modo crear
  const [puntos, setPuntos]         = useState<Coord[]>([]);
  const [nombreRuta, setNombreRuta] = useState('');

  // Guardadas
  const [rutasGuardadas, setRutasGuardadas] = useState<any[]>([]);
  const [rutaVista, setRutaVista]   = useState<any | null>(null);

  useFocusEffect(useCallback(() => { loadRutas(); }, [usuario]));

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const pos = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
        setMiPos(pos);
        setRegion({ ...pos, latitudeDelta: 0.01, longitudeDelta: 0.01 });
      }
    })();
  }, []);

  const loadRutas = async () => {
    if (usuario?.id) {
      const r = await obtenerRutas(usuario.id).catch(() => []);
      setRutasGuardadas(r);
    }
  };

  // ── Buscar destino ──────────────────────────────────────────────────────────
  const handleBuscar = async () => {
    if (!destino.trim()) return;
    setBuscando(true);
    try {
      // 1. Geocodificar con restricción a México
      const coord = await buscarLugar(destino.trim(), miPos);
      if (!coord) {
        Alert.alert('No encontrado', 'No se encontró el lugar en México. Intenta con una dirección más específica.');
        setBuscando(false);
        return;
      }
      setDestinoCoord(coord);

      // 2. Obtener rutas reales por calles via OSRM
      const opciones = await fetchRutasOSRM(miPos, coord);
      if (opciones.length === 0) {
        Alert.alert('Sin ruta', 'No se pudo calcular una ruta. Verifica la ubicación de destino.');
        setBuscando(false);
        return;
      }
      setRutasOpciones(opciones);
      setRutaSeleccionada(0);

      // 3. Ajustar mapa para ver toda la ruta
      const todosLos = opciones[0].puntos;
      const lats  = todosLos.map(p => p.latitude);
      const lons  = todosLos.map(p => p.longitude);
      const midLat = (Math.max(...lats) + Math.min(...lats)) / 2;
      const midLon = (Math.max(...lons) + Math.min(...lons)) / 2;
      const dLat   = (Math.max(...lats) - Math.min(...lats)) * 1.6 + 0.005;
      const dLon   = (Math.max(...lons) - Math.min(...lons)) * 1.6 + 0.005;
      mapRef.current?.animateToRegion({ latitude: midLat, longitude: midLon, latitudeDelta: dLat, longitudeDelta: dLon }, 800);
    } finally {
      setBuscando(false);
    }
  };

  // ── Iniciar carrera con ruta seleccionada ───────────────────────────────────
  const handleIniciarRuta = async () => {
    const ruta = rutasOpciones[rutaSeleccionada];
    if (!ruta) return;
    const distM = totalDistM(ruta.puntos);

    Alert.alert(
      `Iniciar ${ruta.nombre}`,
      `Distancia: ${fmtDist(distM)}\nTiempo estimado: ${tiempoEstimado(distM, ruta.velKmh)}\n\n¿Guardar y empezar esta ruta?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Guardar e Iniciar',
          onPress: async () => {
            if (usuario?.id) {
              await guardarRuta(
                usuario.id, ruta.nombre,
                distM / 1000,
                Math.round((distM / 1000) / ruta.velKmh * 60),
                ruta.puntos
              );
            }
            // Navegar a carrera pasando la ruta seleccionada
            router.push('/(tabs)/carrera');
          },
        },
      ]
    );
  };

  // ── Guardar ruta dibujada ───────────────────────────────────────────────────
  const handleGuardarCreada = async () => {
    if (puntos.length < 2) { Alert.alert('Ruta incompleta', 'Agrega al menos 2 puntos.'); return; }
    const nombre  = nombreRuta.trim() || `Mi ruta ${rutasGuardadas.length + 1}`;
    const distM   = totalDistM(puntos);
    if (usuario?.id) {
      await guardarRuta(usuario.id, nombre, distM / 1000, Math.round(distM / 1000 / 9 * 60), puntos);
      Alert.alert('✅ Guardada', `"${nombre}" guardada.`);
      setPuntos([]); setNombreRuta(''); loadRutas();
    }
  };

  const verRutaGuardada = (ruta: any) => {
    const coords: Coord[] = JSON.parse(ruta.coordenadas_json);
    setRutaVista(ruta);
    if (coords.length > 0) {
      const lats = coords.map(c => c.latitude);
      const lons = coords.map(c => c.longitude);
      mapRef.current?.animateToRegion({
        latitude:  (Math.max(...lats)+Math.min(...lats))/2,
        longitude: (Math.max(...lons)+Math.min(...lons))/2,
        latitudeDelta:  (Math.max(...lats)-Math.min(...lats))*1.8+0.005,
        longitudeDelta: (Math.max(...lons)-Math.min(...lons))*1.8+0.005,
      }, 600);
    }
  };

  const initRutaGuardada = (ruta: any) => {
    Alert.alert(`Iniciar ${ruta.nombre}`, `${ruta.distancia_km.toFixed(2)} km · ~${ruta.tiempo_estimado_min} min\n\n¿Empezar esta ruta?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Iniciar', onPress: () => router.push('/(tabs)/carrera') },
    ]);
  };

  const rutaActual = modo === 'buscar' && rutasOpciones.length > 0 ? rutasOpciones[rutaSeleccionada] : null;
  const distRutaActual = rutaActual ? totalDistM(rutaActual.puntos) : 0;

  const MODOS: { key: Modo; label: string }[] = [
    { key: 'buscar',    label: '🔍 Buscar' },
    { key: 'crear',     label: '✏️ Dibujar' },
    { key: 'guardadas', label: '📋 Guardadas' },
  ];

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <LinearGradient colors={['#050A15', '#0A1020']} style={s.bg}>

        {/* Header con safe area */}
        <View style={[s.headerWrap, { paddingTop: insets.top + 8 }]}>
          <Text style={s.title}>Crear Ruta</Text>

          {/* Tabs de modo */}
          <View style={s.modeRow}>
            {MODOS.map(m => (
              <TouchableOpacity
                key={m.key}
                style={[s.modeBtn, modo === m.key && s.modeBtnActive]}
                onPress={() => { setModo(m.key); setRutaVista(null); }}
              >
                <Text style={[s.modeBtnText, modo === m.key && s.modeBtnTextActive]}>{m.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Mapa */}
        <View style={s.mapWrap}>
          <MapView
            ref={mapRef}
            style={s.map}
            provider={PROVIDER_DEFAULT}
            region={region}
            mapType="standard"
            showsUserLocation
            showsTraffic={false}
            onPress={(e) => {
              if (modo === 'crear') {
                setPuntos(prev => [...prev, e.nativeEvent.coordinate]);
              }
            }}
          >
            {/* Modo buscar: rutas generadas */}
            {modo === 'buscar' && rutasOpciones.map((r, i) => (
              <Polyline
                key={i}
                coordinates={r.puntos}
                strokeColor={i === rutaSeleccionada ? r.color : `${r.color}55`}
                strokeWidth={i === rutaSeleccionada ? 5 : 3}
              />
            ))}
            {modo === 'buscar' && destinoCoord && (
              <>
                <Marker coordinate={miPos} pinColor="#4CD964" />
                <Marker coordinate={destinoCoord} pinColor="#FF3B30" />
              </>
            )}

            {/* Modo crear: puntos dibujados */}
            {modo === 'crear' && puntos.length > 1 && (
              <Polyline coordinates={puntos} strokeColor="#00C8FF" strokeWidth={4} lineDashPattern={[8,4]} />
            )}
            {modo === 'crear' && puntos.map((p, i) => (
              <Marker key={i} coordinate={p} pinColor={i===0?'#4CD964':i===puntos.length-1?'#FF3B30':'#00C8FF'} />
            ))}

            {/* Modo guardadas: ver ruta */}
            {modo === 'guardadas' && rutaVista && (() => {
              const coords: Coord[] = JSON.parse(rutaVista.coordenadas_json);
              return <>
                <Polyline coordinates={coords} strokeColor="#FF9500" strokeWidth={4} />
                {coords.length > 0 && <Marker coordinate={coords[0]} pinColor="#4CD964" />}
                {coords.length > 1 && <Marker coordinate={coords[coords.length-1]} pinColor="#FF3B30" />}
              </>;
            })()}
          </MapView>

          {/* Hint en mapa crear */}
          {modo === 'crear' && (
            <View style={s.mapHint}>
              <Text style={s.mapHintText}>
                {puntos.length === 0 ? '📍 Toca el mapa para dibujar tu ruta'
                  : `${puntos.length} puntos · ${fmtDist(totalDistM(puntos))}`}
              </Text>
            </View>
          )}
        </View>

        {/* Panel inferior según modo */}
        <View style={[s.panel, { paddingBottom: insets.bottom + 8 }]}>

          {/* ── MODO BUSCAR ── */}
          {modo === 'buscar' && (
            <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
              {/* Buscador */}
              <View style={s.searchRow}>
                <View style={s.searchBox}>
                  <Text style={s.searchIcon}>🔍</Text>
                  <TextInput
                    style={s.searchInput}
                    placeholder="¿A dónde quieres correr?"
                    placeholderTextColor="rgba(255,255,255,0.35)"
                    value={destino}
                    onChangeText={setDestino}
                    onSubmitEditing={handleBuscar}
                    returnKeyType="search"
                    autoCorrect={false}
                  />
                  {destino.length > 0 && (
                    <TouchableOpacity onPress={() => { setDestino(''); setRutasOpciones([]); }}>
                      <Text style={{ color: 'rgba(255,255,255,0.4)', fontSize: 16 }}>✕</Text>
                    </TouchableOpacity>
                  )}
                </View>
                <TouchableOpacity
                  style={[s.searchBtn, buscando && { opacity: 0.5 }]}
                  onPress={handleBuscar}
                  disabled={buscando}
                >
                  {buscando
                    ? <ActivityIndicator color="#fff" size="small" />
                    : <Text style={s.searchBtnText}>IR</Text>}
                </TouchableOpacity>
              </View>

              {/* Opciones de ruta */}
              {rutasOpciones.length > 0 && (
                <>
                  <Text style={s.sectionLabel}>RUTAS DISPONIBLES</Text>
                  {rutasOpciones.map((r, i) => {
                    const dM  = totalDistM(r.puntos);
                    const sel = i === rutaSeleccionada;
                    return (
                      <TouchableOpacity
                        key={i}
                        style={[s.rutaOpcion, sel && { borderColor: r.color, backgroundColor: `${r.color}12` }]}
                        onPress={() => setRutaSeleccionada(i)}
                        activeOpacity={0.8}
                      >
                        <View style={[s.rutaOpcionDot, { backgroundColor: r.color }]} />
                        <View style={s.rutaOpcionInfo}>
                          <Text style={[s.rutaOpcionNombre, sel && { color: r.color }]}>{r.nombre}</Text>
                          <View style={s.rutaOpcionStats}>
                            <Text style={s.rutaOpcionStat}>📍 {fmtDist(dM)}</Text>
                            <Text style={s.rutaOpcionStat}>⏱️ {tiempoEstimado(dM, r.velKmh)}</Text>
                            <Text style={s.rutaOpcionStat}>⚡ {r.velKmh} km/h est.</Text>
                          </View>
                        </View>
                        {sel && <Text style={[s.selBadge, { color: r.color }]}>✓</Text>}
                      </TouchableOpacity>
                    );
                  })}

                  {/* Botón iniciar */}
                  <TouchableOpacity style={s.btnIniciar} onPress={handleIniciarRuta} activeOpacity={0.85}>
                    <LinearGradient
                      colors={['rgba(0,200,255,0.4)', 'rgba(0,200,255,0.15)']}
                      style={s.btnIniciarGrad}
                    >
                      <Text style={s.btnIniciarText}>
                        🏃 INICIAR {rutasOpciones[rutaSeleccionada]?.nombre?.toUpperCase()}
                      </Text>
                      <Text style={s.btnIniciarSub}>
                        {fmtDist(distRutaActual)} · {tiempoEstimado(distRutaActual, rutasOpciones[rutaSeleccionada]?.velKmh ?? 9)}
                      </Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              )}

              {rutasOpciones.length === 0 && (
                <Text style={s.emptyHint}>
                  Escribe un lugar, parque o calle para ver rutas posibles desde tu ubicación.
                </Text>
              )}
            </ScrollView>
          )}

          {/* ── MODO CREAR ── */}
          {modo === 'crear' && (
            <View style={s.creadorPanel}>
              <View style={s.inputBox}>
                <TextInput
                  style={s.nameInput}
                  placeholder="Nombre de la ruta (opcional)"
                  placeholderTextColor="rgba(255,255,255,0.3)"
                  value={nombreRuta}
                  onChangeText={setNombreRuta}
                  maxLength={40}
                />
              </View>
              {puntos.length > 1 && (
                <View style={s.statsRow}>
                  <View style={s.statItem}><Text style={s.statVal}>{fmtDist(totalDistM(puntos))}</Text><Text style={s.statLbl}>DIST.</Text></View>
                  <View style={s.statItem}><Text style={s.statVal}>{tiempoEstimado(totalDistM(puntos), 9)}</Text><Text style={s.statLbl}>TIEMPO EST.</Text></View>
                  <View style={s.statItem}><Text style={s.statVal}>{puntos.length}</Text><Text style={s.statLbl}>PUNTOS</Text></View>
                </View>
              )}
              <View style={s.btnRow}>
                <TouchableOpacity style={s.btnSec} onPress={() => setPuntos(p => p.slice(0,-1))} disabled={puntos.length===0}>
                  <Text style={s.btnSecText}>↩ Deshacer</Text>
                </TouchableOpacity>
                <TouchableOpacity style={s.btnSec} onPress={() => { setPuntos([]); setNombreRuta(''); }} disabled={puntos.length===0}>
                  <Text style={s.btnSecText}>🗑️ Limpiar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[s.btnGuardar, puntos.length < 2 && { opacity: 0.3 }]}
                  onPress={handleGuardarCreada}
                  disabled={puntos.length < 2}
                >
                  <Text style={s.btnGuardarText}>💾 Guardar</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* ── MODO GUARDADAS ── */}
          {modo === 'guardadas' && (
            <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
              {rutasGuardadas.length === 0 ? (
                <Text style={s.emptyHint}>No tienes rutas guardadas aún.</Text>
              ) : (
                rutasGuardadas.map(r => {
                  const isActiva = rutaVista?.id === r.id;
                  return (
                    <TouchableOpacity
                      key={r.id}
                      style={[s.savedCard, isActiva && s.savedCardActive]}
                      onPress={() => verRutaGuardada(r)}
                      activeOpacity={0.8}
                    >
                      <View style={s.savedCardHeader}>
                        <Text style={s.savedNombre}>{r.nombre}</Text>
                        <TouchableOpacity
                          onPress={() => Alert.alert('Eliminar', `¿Eliminar "${r.nombre}"?`, [
                            { text: 'Cancelar', style: 'cancel' },
                            { text: 'Eliminar', style: 'destructive', onPress: async () => {
                              await eliminarRuta(r.id); loadRutas();
                              if (rutaVista?.id === r.id) setRutaVista(null);
                            }},
                          ])}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <Text style={{ fontSize: 16 }}>🗑️</Text>
                        </TouchableOpacity>
                      </View>
                      <View style={s.savedStats}>
                        <Text style={s.savedStat}>🏃 {r.distancia_km.toFixed(2)} km</Text>
                        <Text style={s.savedStat}>⏱️ ~{r.tiempo_estimado_min} min</Text>
                      </View>
                      <TouchableOpacity
                        style={s.btnIniciarSmall}
                        onPress={() => initRutaGuardada(r)}
                      >
                        <Text style={s.btnIniciarSmallText}>▶ INICIAR ESTA RUTA</Text>
                      </TouchableOpacity>
                    </TouchableOpacity>
                  );
                })
              )}
            </ScrollView>
          )}
        </View>
      </LinearGradient>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  bg: { flex: 1 },

  headerWrap: { paddingHorizontal: 16, paddingBottom: 0 },
  title: { fontFamily: 'DaysOne_400Regular', fontSize: 20, color: '#fff', textAlign: 'center', marginBottom: 10 },
  modeRow: { flexDirection: 'row', gap: 6, marginBottom: 8 },
  modeBtn: {
    flex: 1, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
  },
  modeBtnActive: { backgroundColor: 'rgba(0,200,255,0.16)', borderColor: 'rgba(0,200,255,0.4)' },
  modeBtnText: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.4)' },
  modeBtnTextActive: { color: '#00C8FF' },

  mapWrap: { height: 220, marginHorizontal: 12, borderRadius: 16, overflow: 'hidden', position: 'relative' },
  map: { flex: 1 },
  mapHint: {
    position: 'absolute', bottom: 8, left: 8, right: 8,
    backgroundColor: 'rgba(0,0,0,0.72)', borderRadius: 8,
    paddingHorizontal: 12, paddingVertical: 5, alignItems: 'center',
  },
  mapHintText: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: '#00C8FF' },

  panel: { flex: 1, paddingHorizontal: 14, paddingTop: 10 },

  // Búsqueda
  searchRow: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  searchBox: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 12,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)',
    height: 46, paddingHorizontal: 12, gap: 8,
  },
  searchIcon: { fontSize: 16 },
  searchInput: { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff' },
  searchBtn: {
    width: 54, height: 46, borderRadius: 12, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(0,200,255,0.25)', borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)',
  },
  searchBtnText: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff', letterSpacing: 1 },

  sectionLabel: {
    fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(0,200,255,0.7)',
    letterSpacing: 2, marginBottom: 8,
  },

  rutaOpcion: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    padding: 12, marginBottom: 8, gap: 10,
  },
  rutaOpcionDot: { width: 10, height: 10, borderRadius: 5 },
  rutaOpcionInfo: { flex: 1 },
  rutaOpcionNombre: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff', marginBottom: 4 },
  rutaOpcionStats: { flexDirection: 'row', gap: 10 },
  rutaOpcionStat: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.55)' },
  selBadge: { fontFamily: 'DaysOne_400Regular', fontSize: 18 },

  btnIniciar: { borderRadius: 14, overflow: 'hidden', marginTop: 4, marginBottom: 10 },
  btnIniciarGrad: {
    paddingVertical: 14, paddingHorizontal: 16, alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)', borderRadius: 14,
  },
  btnIniciarText: { fontFamily: 'DaysOne_400Regular', fontSize: 15, color: '#fff', letterSpacing: 1 },
  btnIniciarSub: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.55)', marginTop: 4 },

  emptyHint: {
    fontFamily: 'DaysOne_400Regular', fontSize: 13, color: 'rgba(255,255,255,0.3)',
    textAlign: 'center', marginTop: 20, lineHeight: 22,
  },

  // Crear
  creadorPanel: { gap: 8 },
  inputBox: {
    backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: 12,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
    height: 44, paddingHorizontal: 14, justifyContent: 'center',
  },
  nameInput: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff' },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 4 },
  statItem: { alignItems: 'center' },
  statVal: { fontFamily: 'DaysOne_400Regular', fontSize: 17, color: '#00C8FF' },
  statLbl: { fontFamily: 'DaysOne_400Regular', fontSize: 8, color: 'rgba(255,255,255,0.4)', letterSpacing: 1 },
  btnRow: { flexDirection: 'row', gap: 6 },
  btnSec: {
    flex: 1, height: 38, borderRadius: 10, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
  },
  btnSecText: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.65)' },
  btnGuardar: {
    flex: 1.5, height: 38, borderRadius: 10, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(0,200,255,0.2)', borderWidth: 1, borderColor: 'rgba(0,200,255,0.45)',
  },
  btnGuardarText: { fontFamily: 'DaysOne_400Regular', fontSize: 12, color: '#fff' },

  // Guardadas
  savedCard: {
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', padding: 12, marginBottom: 8,
  },
  savedCardActive: { borderColor: 'rgba(255,165,0,0.6)', backgroundColor: 'rgba(255,165,0,0.07)' },
  savedCardHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  savedNombre: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff', flex: 1 },
  savedStats: { flexDirection: 'row', gap: 12, marginBottom: 8 },
  savedStat: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.55)' },
  btnIniciarSmall: {
    height: 34, borderRadius: 8, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(76,217,100,0.18)', borderWidth: 1, borderColor: 'rgba(76,217,100,0.4)',
  },
  btnIniciarSmallText: { fontFamily: 'DaysOne_400Regular', fontSize: 12, color: '#4CD964', letterSpacing: 1 },
});

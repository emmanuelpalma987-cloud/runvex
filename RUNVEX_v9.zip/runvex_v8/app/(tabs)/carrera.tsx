import React, { useRef } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, StatusBar,
  TouchableOpacity, Alert, ScrollView,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Polyline, PROVIDER_DEFAULT } from 'react-native-maps';
import { useAuth } from '../../src/hooks/useAuth';
import {
  useRunTracker, formatTiempo, formatPace,
} from '../../src/hooks/useRunTracker';
import { guardarCarrera } from '../../src/database/database';
import ScreenWrapper from '../../src/components/ScreenWrapper';

// ─── Componente de métrica individual ────────────────────────────────────────

interface MetricProps {
  label: string;
  value: string;
  sub?: string;
  accent?: string;
}

function Metric({ label, value, sub, accent = '#fff' }: MetricProps) {
  return (
    <View style={m.metricBox}>
      <Text style={[m.metricVal, { color: accent }]}>{value}</Text>
      {sub ? <Text style={m.metricSub}>{sub}</Text> : null}
      <Text style={m.metricLabel}>{label}</Text>
    </View>
  );
}

// ─── Pantalla principal ────────────────────────────────────────────────────────

export default function CarreraScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { usuario } = useAuth();
  const {
    datos,
    iniciarCarrera,
    pausarCarrera,
    reanudarCarrera,
    terminarCarrera,
  } = useRunTracker();
  const mapRef = useRef<MapView>(null);

  // ── Handlers ────────────────────────────────────────────────────────────────

  const handleAccion = () => {
    if (!datos.corriendo && !datos.pausado) {
      // No ha iniciado
      iniciarCarrera();
    } else if (datos.corriendo) {
      // Está corriendo → pausar
      pausarCarrera();
    } else {
      // Está pausado → reanudar
      reanudarCarrera();
    }
  };

  const handleTerminar = async () => {
    if (!datos.corriendo && datos.tiempoSegundos === 0) {
      Alert.alert('Sin carrera', 'Inicia una carrera primero.');
      return;
    }
    Alert.alert(
      'Terminar carrera',
      `Distancia: ${datos.distanciaKm.toFixed(2)} km\nTiempo: ${formatTiempo(datos.tiempoSegundos)}\n\n¿Deseas guardar los resultados?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Guardar',
          onPress: async () => {
            const res = terminarCarrera();
            if (usuario?.id) {
              try {
                const inicio = res.coordenadas[0];
                const fim    = res.coordenadas[res.coordenadas.length - 1];
                await guardarCarrera({
                  usuario_id: usuario.id,
                  distancia_km: res.distanciaKm,
                  tiempo_segundos: res.tiempoSegundos,
                  velocidad_promedio: res.velocidadPromedio,
                  calorias: res.calorias,
                  pasos: res.pasos,
                  bpm_promedio: res.bpmPromedio,
                  bpm_maximo: res.bpmMaximo,
                  cadencia: res.cadencia,
                  elevacion_m: res.elevacionM,
                  ruta_json: JSON.stringify(res.coordenadas),
                  coord_inicio_lat: inicio?.latitude,
                  coord_inicio_lon: inicio?.longitude,
                  coord_fin_lat: fim?.latitude,
                  coord_fin_lon: fim?.longitude,
                });
              } catch (e) {
                console.error('Error guardando carrera:', e);
              }
            }
            router.push('/(tabs)/resultados');
          },
        },
      ]
    );
  };

  // ── Region del mapa ──────────────────────────────────────────────────────────
  const region = datos.coordenadas.length > 0
    ? {
        latitude: datos.coordenadas[datos.coordenadas.length - 1].latitude,
        longitude: datos.coordenadas[datos.coordenadas.length - 1].longitude,
        latitudeDelta: 0.004,
        longitudeDelta: 0.004,
      }
    : { latitude: 19.2869, longitude: -99.6531, latitudeDelta: 0.01, longitudeDelta: 0.01 };

  // ── Texto y color del botón principal ────────────────────────────────────────
  const btnTexto = datos.corriendo
    ? 'PAUSAR'
    : datos.pausado
    ? 'REANUDAR'
    : 'INICIAR';

  const btnStyle = datos.corriendo
    ? s.btnPause
    : datos.pausado
    ? s.btnResume
    : s.btnStart;

  // ── Color del BPM según zona ─────────────────────────────────────────────────
  const bpmColor = datos.bpm === 0
    ? 'rgba(255,255,255,0.4)'
    : datos.bpm < 120
    ? '#4CD964'   // zona 1-2: verde
    : datos.bpm < 150
    ? '#FF9500'   // zona 3: naranja
    : '#FF3B30';  // zona 4-5: rojo

  // Ruta precargada desde la pantalla de Rutas
  const { rutaPreview } = useLocalSearchParams<{ rutaPreview?: string }>();
  const coordsPreview: { latitude: number; longitude: number }[] =
    rutaPreview ? (() => { try { return JSON.parse(rutaPreview as string); } catch { return []; } })() : [];

  return (
    <ScreenWrapper>

          {/* Título y estado */}
          <View style={[s.header, { paddingTop: insets.top + 8 }]}>
            <Text style={s.title}>Modo Carrera</Text>
            {datos.corriendo && (
              <View style={s.liveDot}><Text style={s.liveText}>● LIVE</Text></View>
            )}
            {datos.pausado && (
              <View style={s.pausedBadge}><Text style={s.pausedText}>PAUSADO</Text></View>
            )}
          </View>
          <View style={s.divider} />

          {/* Timer grande */}
          <Text style={s.timer}>{formatTiempo(datos.tiempoSegundos)}</Text>
          <View style={s.divider} />

          {/* Métricas principales: 2×2 */}
          <View style={s.metricsRow}>
            <Metric
              label="DISTANCIA"
              value={datos.distanciaKm.toFixed(2)}
              sub="km"
              accent="#00C8FF"
            />
            <View style={s.metricDivider} />
            <Metric
              label="VELOCIDAD"
              value={datos.velocidadActual > 0
                ? datos.velocidadActual.toFixed(1)
                : datos.velocidadPromedio > 0
                  ? datos.velocidadPromedio.toFixed(1)
                  : '0.0'}
              sub="km/h"
            />
          </View>
          <View style={s.metricsRow}>
            <Metric
              label="RITMO"
              value={formatPace(datos.pace)}
              accent="rgba(255,255,255,0.85)"
            />
            <View style={s.metricDivider} />
            <Metric
              label="PASOS"
              value={datos.pasos.toLocaleString()}
              accent="#4CD964"
            />
          </View>
          {datos.cadencia > 0 && (
            <View style={s.cadRow}>
              <Text style={s.cadText}>
                🏃 Cadencia: <Text style={s.cadAccent}>{datos.cadencia} pasos/min</Text>
              </Text>
            </View>
          )}
          <View style={s.divider} />

          {/* Mapa */}
          <View style={s.mapWrap}>
            <MapView
              ref={mapRef}
              style={s.map}
              provider={PROVIDER_DEFAULT}
              region={region}
              mapType="satellite"
              showsUserLocation
              followsUserLocation={datos.corriendo}
            >
              {/* Ruta guía precargada */}
              {coordsPreview.length > 1 && !datos.corriendo && (
                <Polyline coordinates={coordsPreview} strokeColor="rgba(255,165,0,0.6)" strokeWidth={3} strokeDashPattern={[8,6]} />
              )}
              {datos.coordenadas.length > 1 && (
                <Polyline
                  coordinates={datos.coordenadas}
                  strokeColor="#00C8FF"
                  strokeWidth={4}
                />
              )}
            </MapView>

            {/* BPM flotante */}
            <View style={[s.bpmBadge, { borderColor: bpmColor }]}>
              <Text style={[s.bpmText, { color: bpmColor }]}>
                ❤️ {datos.bpm > 0 ? `${datos.bpm} bpm` : '-- bpm'}
              </Text>
              {datos.bpmMaximo > 0 && (
                <Text style={s.bpmMax}>máx {datos.bpmMaximo}</Text>
              )}
            </View>

            {/* Elevación flotante */}
            <View style={s.elevBadge}>
              <Text style={s.elevText}>
                ⛰️ +{datos.elevacionAcumulada.toFixed(0)} m
              </Text>
            </View>
          </View>

          {/* Calorías (barra inferior del mapa) */}
          <View style={s.calRow}>
            <Text style={s.calText}>🔥 {datos.calorias} kcal</Text>
            <Text style={s.altText}>Alt: {datos.altitudActual.toFixed(0)} m snm</Text>
          </View>

          {/* Botones */}
          <View style={s.btnRow}>
            <TouchableOpacity
              style={[s.btn, btnStyle]}
              onPress={handleAccion}
              activeOpacity={0.85}
            >
              <Text style={s.btnText}>{btnTexto}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[s.btn, s.btnStop]}
              onPress={handleTerminar}
              activeOpacity={0.85}
            >
              <Text style={s.btnText}>TERMINAR</Text>
            </TouchableOpacity>
          </View>

    </ScreenWrapper>
  );
}

// ─── Estilos ─────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  bg: { flex: 1 },
  safe: { flex: 1 },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    paddingTop: 8, gap: 10,
  },
  title: {
    fontFamily: 'DaysOne_400Regular', fontSize: 22, color: '#fff',
  },
  liveDot: {
    backgroundColor: 'rgba(255,59,48,0.2)', borderRadius: 8,
    paddingHorizontal: 8, paddingVertical: 2,
    borderWidth: 1, borderColor: 'rgba(255,59,48,0.5)',
  },
  liveText: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: '#FF3B30' },
  pausedBadge: {
    backgroundColor: 'rgba(255,165,0,0.2)', borderRadius: 8,
    paddingHorizontal: 8, paddingVertical: 2,
    borderWidth: 1, borderColor: 'rgba(255,165,0,0.5)',
  },
  pausedText: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: '#FF9500' },

  divider: {
    height: 1, backgroundColor: 'rgba(255,255,255,0.12)',
    marginHorizontal: 18, marginVertical: 6,
  },
  timer: {
    fontFamily: 'DaysOne_400Regular', fontSize: 52, color: '#fff',
    textAlign: 'center', letterSpacing: 4,
  },

  metricsRow: {
    flexDirection: 'row', paddingHorizontal: 18, paddingVertical: 4,
  },
  metricDivider: {
    width: 1, backgroundColor: 'rgba(255,255,255,0.15)', marginVertical: 4,
  },

  mapWrap: {
    flex: 1, marginHorizontal: 18, borderRadius: 16, overflow: 'hidden',
    position: 'relative',
  },
  map: { flex: 1 },

  bpmBadge: {
    position: 'absolute', top: 10, right: 10,
    backgroundColor: 'rgba(0,0,0,0.75)', borderRadius: 12,
    paddingHorizontal: 12, paddingVertical: 6,
    borderWidth: 1, alignItems: 'center',
  },
  bpmText: { fontFamily: 'DaysOne_400Regular', fontSize: 15 },
  bpmMax: {
    fontFamily: 'DaysOne_400Regular', fontSize: 10,
    color: 'rgba(255,255,255,0.5)', marginTop: 1,
  },

  elevBadge: {
    position: 'absolute', top: 10, left: 10,
    backgroundColor: 'rgba(0,0,0,0.75)', borderRadius: 12,
    paddingHorizontal: 12, paddingVertical: 6,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)',
  },
  elevText: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff' },

  calRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingHorizontal: 22, paddingTop: 6, paddingBottom: 2,
  },
  cadRow: {
    alignItems: 'center', paddingVertical: 4,
  },
  cadText: {
    fontFamily: 'DaysOne_400Regular', fontSize: 12, color: 'rgba(255,255,255,0.5)',
  },
  cadAccent: {
    fontFamily: 'DaysOne_400Regular', fontSize: 12, color: '#00C8FF',
  },
  calText: {
    fontFamily: 'DaysOne_400Regular', fontSize: 14, color: 'rgba(255,255,255,0.7)',
  },
  altText: {
    fontFamily: 'DaysOne_400Regular', fontSize: 12, color: 'rgba(255,255,255,0.45)',
  },

  btnRow: {
    flexDirection: 'row', paddingHorizontal: 18, paddingVertical: 14, gap: 14,
  },
  btn: {
    flex: 1, height: 50, borderRadius: 25,
    justifyContent: 'center', alignItems: 'center',
  },
  btnStart: {
    backgroundColor: 'rgba(0,200,255,0.2)',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.6)',
  },
  btnPause: {
    backgroundColor: 'rgba(255,165,0,0.2)',
    borderWidth: 1, borderColor: 'rgba(255,165,0,0.6)',
  },
  btnResume: {
    backgroundColor: 'rgba(76,217,100,0.2)',
    borderWidth: 1, borderColor: 'rgba(76,217,100,0.6)',
  },
  btnStop: {
    backgroundColor: 'rgba(255,59,48,0.2)',
    borderWidth: 1, borderColor: 'rgba(255,59,48,0.6)',
  },
  btnText: {
    fontFamily: 'DaysOne_400Regular', fontSize: 17, color: '#fff', letterSpacing: 1,
  },
});

const m = StyleSheet.create({
  metricBox: { flex: 1, alignItems: 'center', paddingVertical: 4 },
  metricVal: {
    fontFamily: 'DaysOne_400Regular', fontSize: 26, color: '#fff', lineHeight: 30,
  },
  metricSub: {
    fontFamily: 'DaysOne_400Regular', fontSize: 12,
    color: 'rgba(255,255,255,0.5)', lineHeight: 14,
  },
  metricLabel: {
    fontFamily: 'DaysOne_400Regular', fontSize: 10,
    color: 'rgba(255,255,255,0.4)', marginTop: 2, letterSpacing: 1,
  },
});


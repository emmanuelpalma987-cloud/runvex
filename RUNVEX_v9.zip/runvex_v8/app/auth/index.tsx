import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ImageBackground,
  SafeAreaView, StatusBar, TouchableOpacity, Animated,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';

// Imagen local — no requiere internet
const BG = require('../../src/assets/images/bg_welcome.png');

export default function BienvenidaScreen() {
  const router = useRouter();
  const glow = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(glow, { toValue: 1, duration: 1800, useNativeDriver: true }),
        Animated.timing(glow, { toValue: 0.6, duration: 1800, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <ImageBackground source={BG} style={s.bg} resizeMode="cover">
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.2)', 'rgba(0,5,20,0.85)']}
          style={s.overlay}
        >
          <SafeAreaView style={s.safe}>
            <Animated.Text style={[s.logo, { opacity: glow }]}>RUNVEX</Animated.Text>
            <Text style={s.tagline}>Tu compañero de carrera</Text>

            <View style={s.btns}>
              <TouchableOpacity
                style={s.btnWhite}
                onPress={() => router.push('/auth/login')}
                activeOpacity={0.85}
              >
                <Text style={s.btnTextDark}>INICIAR SESIÓN</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={s.btnOutline}
                onPress={() => router.push('/auth/registro')}
                activeOpacity={0.85}
              >
                <Text style={s.btnTextWhite}>REGISTRARSE</Text>
              </TouchableOpacity>
            </View>
          </SafeAreaView>
        </LinearGradient>
      </ImageBackground>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  bg: { flex: 1 },
  overlay: { flex: 1, justifyContent: 'space-between', paddingBottom: 52 },
  safe: { flex: 1, justifyContent: 'space-between' },
  logo: {
    fontFamily: 'Audiowide_400Regular', fontSize: 68, color: '#fff',
    textAlign: 'center', marginTop: 80,
    textShadowColor: '#00C8FF', textShadowOffset: { width: 0, height: 0 }, textShadowRadius: 28,
  },
  tagline: {
    fontFamily: 'DaysOne_400Regular', fontSize: 14, color: 'rgba(255,255,255,0.55)',
    textAlign: 'center', marginTop: -60, letterSpacing: 2,
  },
  btns: { paddingHorizontal: 36, gap: 14 },
  btnWhite: {
    height: 52, borderRadius: 26, backgroundColor: 'rgba(255,255,255,0.88)',
    justifyContent: 'center', alignItems: 'center',
    shadowColor: '#fff', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.4, shadowRadius: 12,
  },
  btnOutline: {
    height: 52, borderRadius: 26, backgroundColor: 'transparent',
    borderWidth: 1.5, borderColor: 'rgba(0,200,255,0.7)',
    justifyContent: 'center', alignItems: 'center',
  },
  btnTextDark: { fontFamily: 'DaysOne_400Regular', fontSize: 18, color: '#050A15', letterSpacing: 1.5 },
  btnTextWhite: { fontFamily: 'DaysOne_400Regular', fontSize: 18, color: '#00C8FF', letterSpacing: 1.5 },
});

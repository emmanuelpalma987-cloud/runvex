/**
 * useRunTracker v8 — Sensores integrados para Expo Go
 *
 * SENSORES UTILIZADOS:
 *  - expo-location (GPS):
 *      · Distancia real (Haversine, filtrado de ruido)
 *      · Velocidad GPS suavizada con EMA (alpha=0.4)
 *      · Elevación acumulada (buffer de 5 lecturas + umbral 0.5m)
 *      · Pasos calculados por distancia GPS + longitud de zancada biomecánica
 *
 *  - expo-sensors / Pedometer:
 *      · Sensor nativo de pasos del dispositivo (prioritario sobre GPS)
 *      · Fallback silencioso a GPS si el hardware no responde en 6 s
 *
 *  - expo-sensors / Accelerometer (50 Hz):
 *      · Detección de cadencia de trote (pasos/min)
 *      · Umbral adaptativo basado en mediana de magnitudes recientes
 *      · Peak detection con cooldown 300 ms
 *      · Confirma/corrige el conteo de pasos GPS con cadencia real
 *
 * RITMO CARDÍACO (BPM):
 *      · Estimación fisiológica por zonas FC (Karvonen adaptado)
 *      · BPM base 68, máximo 185
 *      · Ramp rate ±1.5 bpm/s — evita saltos bruscos
 *      · Variabilidad aleatoria ±3 bpm para naturalidad
 *      · Cinco zonas: reposo/calentamiento/aeróbico/umbral/anaeróbico
 *
 * CALORÍAS: fórmula MET × peso corporal × tiempo
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import * as Location from 'expo-location';
import { Pedometer, Accelerometer } from 'expo-sensors';
import { Platform, PermissionsAndroid } from 'react-native';

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface RunData {
  distanciaKm: number;
  tiempoSegundos: number;
  velocidadActual: number;
  velocidadPromedio: number;
  pasos: number;
  cadencia: number;            // pasos/min detectados por acelerómetro
  bpm: number;
  bpmMaximo: number;
  calorias: number;
  elevacionAcumulada: number;
  altitudActual: number;
  pace: number;                // seg/km
  coordenadas: { latitude: number; longitude: number; altitude: number }[];
  corriendo: boolean;
  pausado: boolean;
}

// ─── Constantes fisiológicas ──────────────────────────────────────────────────

const BPM_BASE = 68;
const BPM_MAX  = 185;
const BPM_RAMP = 1.5;   // bpm/s máximo de cambio

// Peso corporal estimado (kg) — base para calorías MET
const PESO_KG = 70;

// ─── Helpers: biomecánica de marcha ──────────────────────────────────────────

/**
 * Longitud de zancada según velocidad (km/h)
 * Basado en estudios biomecánicos (Cavanagh & Kram, 1989):
 *   3 km/h  → ~0.48 m/paso
 *   6 km/h  → ~0.65 m/paso
 *   9 km/h  → ~0.80 m/paso
 *  12 km/h  → ~0.95 m/paso
 *  15 km/h  → ~1.10 m/paso
 */
function longitudZancada(velKmh: number): number {
  if (velKmh <= 0)  return 0.72;
  if (velKmh < 3)   return 0.40 + (velKmh / 3) * 0.08;
  if (velKmh < 6)   return 0.48 + ((velKmh - 3) / 3) * 0.17;
  if (velKmh < 9)   return 0.65 + ((velKmh - 6) / 3) * 0.15;
  if (velKmh < 12)  return 0.80 + ((velKmh - 9) / 3) * 0.15;
  return Math.min(1.20, 0.95 + ((velKmh - 12) / 6) * 0.25);
}

/** Pasos GPS desde distancia total acumulada */
function pasosGPS(distanciaM: number, velKmh: number): number {
  if (distanciaM <= 0) return 0;
  const z = longitudZancada(velKmh);
  return Math.round(distanciaM / z);
}

// ─── Haversine (metros entre dos coordenadas) ─────────────────────────────────

function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R    = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a    = Math.sin(dLat / 2) ** 2
    + Math.cos(lat1 * Math.PI / 180)
    * Math.cos(lat2 * Math.PI / 180)
    * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ─── BPM por zonas fisiológicas ───────────────────────────────────────────────

function estimarBPM(vel: number, t: number, prev: number): number {
  // Zona 0 — reposo o muy lento
  if (t === 0 || vel < 1) {
    return prev > BPM_BASE
      ? Math.max(BPM_BASE, Math.round(prev - BPM_RAMP))
      : BPM_BASE;
  }

  // Porcentaje del rango (BPM_BASE → BPM_MAX) según velocidad
  // Zona 1: 0–6 km/h   (calentamiento, 58-65% FC max)
  // Zona 2: 6–9 km/h   (aeróbico suave, 65-75% FC max)
  // Zona 3: 9–12 km/h  (aeróbico intenso, 75-85% FC max)
  // Zona 4: 12+ km/h   (umbral/anaeróbico, 85-95% FC max)
  const pct = vel < 6
    ? 0.58 + (vel / 6) * 0.07
    : vel < 9
    ? 0.65 + ((vel - 6) / 3) * 0.10
    : vel < 12
    ? 0.75 + ((vel - 9) / 3) * 0.10
    : 0.85 + Math.min((vel - 12) / 8, 1) * 0.10;

  const objetivo = Math.round(BPM_BASE + pct * (BPM_MAX - BPM_BASE));
  const varianza = Math.floor(Math.random() * 7) - 3; // ±3 bpm
  const delta    = objetivo - prev;
  const paso     = Math.sign(delta) * Math.min(Math.abs(delta), BPM_RAMP);

  return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(prev + paso + varianza * 0.3)));
}

// ─── Calorías MET ─────────────────────────────────────────────────────────────

function calcCalorias(distKm: number, tiempoSeg: number, velKmh: number): number {
  // MET values para correr (Ainsworth, 2011)
  const met = velKmh >= 16 ? 16.0
    : velKmh >= 14 ? 14.5
    : velKmh >= 12 ? 13.5
    : velKmh >= 10 ? 11.5
    : velKmh >= 8  ? 10.0
    : velKmh >= 6  ? 8.0
    : 4.5; // caminar rápido
  return Math.round(met * PESO_KG * (tiempoSeg / 3600));
}

// ─── Permiso Android Activity Recognition ─────────────────────────────────────

async function pedirPermisoAndroid(): Promise<void> {
  if (Platform.OS !== 'android' || Platform.Version < 29) return;
  try {
    await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACTIVITY_RECOGNITION,
      {
        title: 'Permiso de actividad',
        message: 'RUNVEX necesita el sensor de pasos.',
        buttonPositive: 'Permitir',
        buttonNegative: 'Cancelar',
      }
    );
  } catch {}
}

// ─── Estado inicial ───────────────────────────────────────────────────────────

const INICIAL: RunData = {
  distanciaKm: 0, tiempoSegundos: 0,
  velocidadActual: 0, velocidadPromedio: 0,
  pasos: 0, cadencia: 0,
  bpm: 0, bpmMaximo: 0,
  calorias: 0, elevacionAcumulada: 0, altitudActual: 0,
  pace: 0, coordenadas: [], corriendo: false, pausado: false,
};

// ─── Hook principal ───────────────────────────────────────────────────────────

export function useRunTracker() {
  const [datos,   setDatos]   = useState<RunData>(INICIAL);
  const [permGPS, setPermGPS] = useState(false);

  // Suscripciones
  const timer    = useRef<ReturnType<typeof setInterval> | null>(null);
  const locSub   = useRef<Location.LocationSubscription | null>(null);
  const pedSub   = useRef<{ remove: () => void } | null>(null);
  const accelSub = useRef<{ remove: () => void } | null>(null);

  // Flags de sensores activos
  const pedActivo   = useRef(false);  // Pedometer nativo respondió
  const accelActivo = useRef(false);

  // Acumuladores (refs para evitar stale closures en setInterval)
  const distM      = useRef(0);
  const tiempo     = useRef(0);
  const pasosRef   = useRef(0);
  const elevAcum   = useRef(0);
  const velRef     = useRef(0);
  const bpmRef     = useRef(BPM_BASE);
  const bpmMaxRef  = useRef(0);
  const coords     = useRef<{ latitude: number; longitude: number; altitude: number }[]>([]);

  // Buffer de altitudes para suavizado (5 lecturas)
  const altBuf    = useRef<number[]>([]);

  // Acelerómetro: buffer de magnitudes para mediana adaptativa
  const accelMagBuf = useRef<number[]>([]);
  const lastPeak    = useRef(0);        // timestamp del último paso detectado
  const prevMag     = useRef(0);        // magnitud anterior para edge-detection
  const accelPasos  = useRef(0);        // pasos contados por acelerómetro
  const cadenciaRef = useRef(0);        // cadencia actual (pasos/min)

  // Ventana deslizante de tiempos de paso para calcular cadencia
  const stepTimestamps = useRef<number[]>([]);

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      setPermGPS(status === 'granted');
      await pedirPermisoAndroid();
    })();
    return () => _stop();
  }, []);

  // ── Pedometer nativo ──────────────────────────────────────────────────────

  const intentarPedometro = useCallback(async () => {
    try {
      const avail = await Pedometer.isAvailableAsync();
      if (!avail) return;
      const pasosBase = accelPasos.current; // Offset para conteo relativo
      pedSub.current = Pedometer.watchStepCount(result => {
        if (result.steps > 0) {
          pedActivo.current  = true;
          // Sumamos pasos relativos desde que se inició el pedómetro
          pasosRef.current   = pasosBase + result.steps;
          setDatos(p => ({ ...p, pasos: pasosRef.current }));
        }
      });
      // Si en 6 s no llega ningún evento, lo damos por inactivo
      setTimeout(() => {
        if (!pedActivo.current && pedSub.current) {
          pedSub.current.remove();
          pedSub.current = null;
        }
      }, 6000);
    } catch {}
  }, []);

  // ── Acelerómetro para cadencia y pasos ───────────────────────────────────

  const iniciarAcelerometro = useCallback(() => {
    accelPasos.current     = 0;
    lastPeak.current       = 0;
    prevMag.current        = 0;
    stepTimestamps.current = [];
    accelMagBuf.current    = [];

    Accelerometer.setUpdateInterval(20); // 50 Hz

    accelSub.current = Accelerometer.addListener(({ x, y, z }) => {
      accelActivo.current = true;
      const mag = Math.sqrt(x * x + y * y + z * z);

      // Mantener buffer de 50 muestras para mediana adaptativa
      accelMagBuf.current.push(mag);
      if (accelMagBuf.current.length > 50) accelMagBuf.current.shift();

      // Umbral dinámico: mediana + 0.35g
      const sorted = [...accelMagBuf.current].sort((a, b) => a - b);
      const mediana = sorted[Math.floor(sorted.length / 2)];
      const umbral  = mediana + 0.35;

      const ahora     = Date.now();
      const cooldown  = 280; // ms mínimo entre pasos

      // Peak detection: cruce ascendente del umbral con cooldown
      if (
        mag > umbral
        && prevMag.current <= umbral
        && ahora - lastPeak.current > cooldown
      ) {
        lastPeak.current  = ahora;
        accelPasos.current += 1;

        // Solo sobreescribir pasos si el pedómetro nativo no está activo
        if (!pedActivo.current) {
          pasosRef.current = accelPasos.current;
          setDatos(p => ({ ...p, pasos: accelPasos.current }));
        }

        // Registrar timestamp para calcular cadencia
        stepTimestamps.current.push(ahora);
        // Ventana de 10 s
        const ventana = 10000;
        stepTimestamps.current = stepTimestamps.current.filter(t => ahora - t < ventana);

        // Cadencia (pasos/min) = pasos en ventana / ventana * 60
        if (stepTimestamps.current.length >= 3) {
          const ppm = Math.round(stepTimestamps.current.length / (ventana / 1000) * 60);
          cadenciaRef.current = ppm;
          setDatos(p => ({ ...p, cadencia: ppm }));
        }
      }
      prevMag.current = mag;
    });
  }, []);

  // ── GPS ───────────────────────────────────────────────────────────────────

  const suscribirGPS = useCallback(async () => {
    locSub.current = await Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.BestForNavigation,
        distanceInterval: 2,    // mínimo 2 m entre lecturas
        timeInterval: 1000,     // o cada 1 s
      },
      loc => {
        const { latitude, longitude, altitude, speed } = loc.coords;
        const alt = altitude ?? 0;

        // ── Velocidad GPS con EMA ──────────────────────────────────────────
        const velGps = speed != null && speed > 0.4 ? speed * 3.6 : 0; // m/s → km/h
        velRef.current = velRef.current === 0
          ? velGps
          : velRef.current * 0.6 + velGps * 0.4; // EMA alpha=0.4

        // ── Distancia Haversine ───────────────────────────────────────────
        const prev    = coords.current;
        let deltaM    = 0;
        if (prev.length > 0) {
          const last = prev[prev.length - 1];
          const d = haversine(last.latitude, last.longitude, latitude, longitude);
          // Filtrar ruido: entre 1 m y 50 m (evita teleportaciones GPS)
          if (d > 1 && d < 50) {
            distM.current += d;
            deltaM = d;
          }
        }

        // ── Pasos GPS (sólo si no hay sensor nativo ni acelerómetro) ─────
        if (!pedActivo.current && !accelActivo.current && deltaM > 0) {
          const nuevos = pasosGPS(distM.current, velRef.current);
          pasosRef.current = nuevos;
          setDatos(p => ({ ...p, pasos: nuevos }));
        }

        // ── Elevación con buffer de suavizado (5 lecturas) ────────────────
        altBuf.current.push(alt);
        if (altBuf.current.length > 5) altBuf.current.shift();
        const altSmooth = altBuf.current.reduce((a, b) => a + b, 0) / altBuf.current.length;

        if (altBuf.current.length >= 3) {
          const prevSmooth = altBuf.current.slice(0, -1).reduce((a, b) => a + b, 0)
            / (altBuf.current.length - 1);
          const dif = altSmooth - prevSmooth;
          // Acumular sólo subidas reales (umbral 0.5 m)
          if (dif > 0.5) elevAcum.current += dif;
        }

        coords.current = [...prev, { latitude, longitude, altitude: altSmooth }];

        setDatos(p => ({
          ...p,
          distanciaKm:        parseFloat((distM.current / 1000).toFixed(4)),
          velocidadActual:    parseFloat(velRef.current.toFixed(1)),
          elevacionAcumulada: parseFloat(elevAcum.current.toFixed(1)),
          altitudActual:      parseFloat(altSmooth.toFixed(1)),
          coordenadas:        coords.current,
        }));
      }
    );
  }, []);

  // ── Timer 1 s: tiempo, BPM, calorías, pace ───────────────────────────────

  const iniciarTimer = useCallback(() => {
    timer.current = setInterval(() => {
      tiempo.current += 1;
      const t   = tiempo.current;
      const dK  = distM.current / 1000;
      const vel = velRef.current;

      const bpm  = estimarBPM(vel, t, bpmRef.current);
      bpmRef.current = bpm;
      if (bpm > bpmMaxRef.current) bpmMaxRef.current = bpm;

      const pace  = dK > 0 && t > 0 ? t / dK : 0;
      const vProm = t > 0 ? (dK / t) * 3600 : 0;
      const cal   = calcCalorias(dK, t, vel);

      // Pasos: prioridad pedómetro > acelerómetro > GPS
      const pasos = pedActivo.current
        ? pasosRef.current
        : accelActivo.current
        ? accelPasos.current
        : pasosGPS(distM.current, vel);

      setDatos(p => ({
        ...p,
        tiempoSegundos:    t,
        bpm,
        bpmMaximo:         bpmMaxRef.current,
        calorias:          cal,
        velocidadPromedio: parseFloat(vProm.toFixed(2)),
        pace,
        pasos,
        cadencia:          cadenciaRef.current,
      }));
    }, 1000);
  }, []);

  // ── INICIAR ───────────────────────────────────────────────────────────────

  const iniciarCarrera = useCallback(async () => {
    if (!permGPS) {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      setPermGPS(true);
    }

    // Reset completo
    distM.current      = 0;
    tiempo.current     = 0;
    pasosRef.current   = 0;
    elevAcum.current   = 0;
    velRef.current     = 0;
    bpmRef.current     = BPM_BASE;
    bpmMaxRef.current  = 0;
    coords.current     = [];
    altBuf.current     = [];
    pedActivo.current  = false;
    accelActivo.current = false;
    accelPasos.current = 0;
    cadenciaRef.current = 0;

    setDatos({ ...INICIAL, bpm: BPM_BASE, corriendo: true, pausado: false });

    iniciarTimer();
    await suscribirGPS();
    iniciarAcelerometro();
    await intentarPedometro();
  }, [permGPS, iniciarTimer, suscribirGPS, iniciarAcelerometro, intentarPedometro]);

  // ── PAUSAR ────────────────────────────────────────────────────────────────

  const pausarCarrera = useCallback(() => {
    _stop();
    setDatos(p => ({ ...p, corriendo: false, pausado: true }));
  }, []);

  // ── REANUDAR ──────────────────────────────────────────────────────────────

  const reanudarCarrera = useCallback(async () => {
    if (!permGPS) return;
    // Reset flags para reintentar sensores, pero conservar contadores
    pedActivo.current   = false;
    accelActivo.current = false;
    setDatos(p => ({ ...p, corriendo: true, pausado: false }));
    iniciarTimer();
    await suscribirGPS();
    iniciarAcelerometro();
    await intentarPedometro();
  }, [permGPS, iniciarTimer, suscribirGPS, iniciarAcelerometro, intentarPedometro]);

  // ── TERMINAR ──────────────────────────────────────────────────────────────

  const terminarCarrera = useCallback(() => {
    _stop();
    const dK    = distM.current / 1000;
    const pasos = pedActivo.current
      ? pasosRef.current
      : accelActivo.current
      ? accelPasos.current
      : pasosGPS(distM.current, velRef.current);

    const res = {
      distanciaKm:       dK,
      tiempoSegundos:    tiempo.current,
      velocidadPromedio: tiempo.current > 0 ? (dK / tiempo.current) * 3600 : 0,
      pasos,
      cadencia:          cadenciaRef.current,
      calorias:          calcCalorias(dK, tiempo.current, velRef.current),
      bpmPromedio:       bpmRef.current,
      bpmMaximo:         bpmMaxRef.current,
      elevacionM:        elevAcum.current,
      coordenadas:       coords.current,
    };
    setDatos(p => ({ ...p, corriendo: false, pausado: false }));
    return res;
  }, []);

  // ── Cleanup interno ───────────────────────────────────────────────────────

  function _stop() {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    locSub.current?.remove();   locSub.current   = null;
    pedSub.current?.remove();   pedSub.current   = null;
    accelSub.current?.remove(); accelSub.current = null;
  }

  return {
    datos,
    iniciarCarrera,
    pausarCarrera,
    reanudarCarrera,
    terminarCarrera,
    permGPS,
  };
}

// ─── Utilidades de formato ────────────────────────────────────────────────────

export const formatTiempo = (s: number) =>
  `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

export const formatPace = (p: number) => {
  if (!p || p <= 0) return '--:--';
  const min = Math.floor(p / 60);
  const seg = String(Math.floor(p % 60)).padStart(2, '0');
  return `${min}:${seg} /km`;
};

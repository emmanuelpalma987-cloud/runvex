# RUNVEX 🏃 — Aplicación Móvil de Seguimiento de Carreras

**Versión:** 8.0  
**Framework:** React Native + Expo SDK 54  
**Plataformas:** iOS y Android (compatible con Expo Go)  
**Modo:** 100% offline — no requiere internet para funcionar

---

## Descripción del proyecto

RUNVEX es una aplicación móvil de tracking de carreras que utiliza los sensores del dispositivo para registrar distancia, velocidad, pasos, cadencia, elevación y BPM estimado en tiempo real. Incluye historial con gráficas, creación y búsqueda de rutas, ejercicios con acelerómetro, y autenticación biométrica segura.

### Características principales

- ✅ Tracking GPS en tiempo real con mapa satelital
- ✅ Métricas: distancia, velocidad, ritmo, pasos, cadencia (p/min), BPM, elevación, calorías
- ✅ Sensores integrados: GPS + Acelerómetro (50 Hz) + Pedómetro nativo
- ✅ Historial de carreras con gráficas (distancia, BPM, kcal)
- ✅ Creador de rutas (dibujar sobre mapa) y búsqueda por lugar (Nominatim)
- ✅ Ejercicios complementarios con acelerómetro (cuerda / trote en sitio)
- ✅ Autenticación biométrica (huella / Face ID) + contraseña
- ✅ Avatar con foto de perfil — se muestra en pantalla de login
- ✅ Calendario de racha en perfil
- ✅ Base de datos SQLite local (sin servidor, sin internet requerido)
- ✅ Imágenes locales embebidas (no depende de Figma ni URLs externas)

---

## Sensores utilizados

| Sensor | API | Función |
|--------|-----|---------|
| GPS | `expo-location` | Distancia (Haversine), velocidad (EMA), elevación (buffer 5 pts) |
| Acelerómetro | `expo-sensors` (50 Hz) | Cadencia de pasos, conteo por peak-detection adaptativo |
| Pedómetro nativo | `expo-sensors/Pedometer` | Conteo nativo de pasos (prioritario si disponible) |
| Biometría | `expo-local-authentication` | Huella digital o Face ID |

### Prioridad de conteo de pasos
1. **Pedómetro nativo** (si el hardware responde en < 6 s)
2. **Acelerómetro** (peak-detection con umbral dinámico por mediana)
3. **GPS** (distancia / longitud de zancada biomecánica — fallback)

---

## Tecnologías utilizadas

| Librería | Versión | Uso |
|----------|---------|-----|
| expo | ~54.0.21 | Plataforma base |
| expo-router | ~6.0.14 | Navegación file-based |
| expo-sqlite | ~15.1.4 | Base de datos local |
| expo-location | ~19.0.7 | GPS tracking |
| expo-sensors | ~14.1.4 | Acelerómetro + Pedómetro |
| expo-local-authentication | ~15.0.2 | Biometría |
| expo-secure-store | ~14.0.1 | Credenciales cifradas |
| expo-image-picker | ~16.0.6 | Foto de perfil |
| expo-linear-gradient | ~15.0.7 | UI gradientes |
| react-native-maps | 1.20.1 | Mapas satelitales |
| react-native-safe-area-context | 5.4.0 | Insets seguros |

---

## Instrucciones para ejecutar

### Requisitos previos
- Node.js 18 o superior
- App **Expo Go** instalada en tu teléfono (iOS o Android)
- Misma red WiFi en el teléfono y la computadora

### Pasos

```bash
# 1. Instalar dependencias
npm install --legacy-peer-deps

# 2. Iniciar el servidor de desarrollo
npx expo start --clear

# 3. Escanear el QR con Expo Go desde tu teléfono
```

> **Nota:** La base de datos SQLite se crea automáticamente al abrir la app. Para biometría, el dispositivo debe tener huella o Face ID configurado en ajustes del sistema.

---

## Estructura del proyecto

```
runvex/
├── app/
│   ├── _layout.tsx          # Root layout + AuthProvider + fuentes
│   ├── index.tsx            # Redirección auth/home según sesión
│   ├── auth/
│   │   ├── index.tsx        # Pantalla de bienvenida (imagen local)
│   │   ├── login.tsx        # Login + foto de perfil en avatar
│   │   ├── registro.tsx     # Registro de cuenta
│   │   └── recuperar.tsx    # Recuperar contraseña
│   └── (tabs)/
│       ├── home.tsx         # Dashboard + calendario racha
│       ├── carrera.tsx      # Tracking GPS en tiempo real + cadencia
│       ├── resultados.tsx   # Historial + gráficas + mapa ruta
│       ├── rutas.tsx        # Buscar / dibujar / guardar rutas
│       ├── ejercicios.tsx   # Cuerda / trote con acelerómetro
│       └── perfil.tsx       # Editar perfil + biometría + foto
├── src/
│   ├── database/database.ts # SQLite: usuarios, carreras, rutas, sesión
│   ├── hooks/
│   │   ├── useAuth.tsx      # Contexto de autenticación global
│   │   ├── useBiometrics.ts # Huella/Face ID + SecureStore
│   │   └── useRunTracker.ts # GPS + Acelerómetro + Pedómetro + BPM
│   ├── components/
│   │   └── ScreenWrapper.tsx
│   ├── assets/
│   │   ├── icons/           # Íconos del tab bar
│   │   └── images/          # Imágenes de fondo locales (no requieren internet)
│   └── utils/theme.ts
└── package.json
```

---

## Empaquetado para distribución (APK)

```bash
# Instalar EAS CLI
npm install -g eas-cli

# Login en Expo
eas login

# Configurar proyecto
eas build:configure

# Generar APK de desarrollo (para pruebas sin Play Store)
eas build --platform android --profile preview

# Generar APK/AAB de producción
eas build --platform android --profile production
```

El archivo APK generado puede instalarse directamente en cualquier dispositivo Android sin necesidad de publicar en Google Play.

---

## Autor
Proyecto académico — Ingeniería en Sistemas Computacionales  
Materia: Desarrollo de Aplicaciones Móviles — 2026

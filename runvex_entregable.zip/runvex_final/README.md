# RUNVEX 🏃 — Aplicación Móvil de Seguimiento de Carreras

**Version:** 6.0 Final  
**Framework:** React Native + Expo SDK 54  
**Plataformas:** iOS y Android (compatible con Expo Go)

---

## Descripción del proyecto

RUNVEX es una aplicación móvil de tracking de carreras que utiliza el GPS del dispositivo para registrar distancia, velocidad, pasos, elevación y BPM estimado en tiempo real. Incluye historial con gráficas, creación y búsqueda de rutas, ejercicios con acelerómetro, y autenticación biométrica segura.

### Características principales
- ✅ Tracking GPS en tiempo real con mapa satelital
- ✅ Métricas: distancia, velocidad, ritmo, pasos, BPM, elevación, calorías
- ✅ Historial de carreras con gráficas (distancia, BPM, kcal)
- ✅ Creador de rutas (dibujar sobre mapa) y búsqueda por lugar
- ✅ Ejercicios complementarios con acelerómetro (cuerda / trote en sitio)
- ✅ Autenticación biométrica (huella / Face ID) + contraseña
- ✅ Avatar con foto de perfil y calendario de racha
- ✅ Base de datos SQLite local (sin servidor, sin internet requerido)

---

## Tecnologías utilizadas

| Librería | Versión | Uso |
|----------|---------|-----|
| expo | ~54.0.21 | Plataforma base |
| expo-router | ~6.0.14 | Navegación file-based |
| expo-sqlite | ~15.1.4 | Base de datos local |
| expo-location | ~19.0.7 | GPS tracking |
| expo-sensors | ~14.1.4 | Acelerómetro / Podómetro |
| expo-local-authentication | ~15.0.2 | Biometría |
| expo-secure-store | ~14.0.1 | Almacenamiento cifrado |
| expo-image-picker | ~16.0.6 | Foto de perfil |
| expo-linear-gradient | ~15.0.7 | UI gradientes |
| react-native-maps | 1.20.1 | Mapas satelitales |
| react-native-safe-area-context | 5.4.0 | Insets seguros |

---

## Instrucciones para ejecutar

### Requisitos previos
- Node.js 18 o superior
- App **Expo Go** instalada en tu teléfono (iOS o Android)
- Misma red WiFi en el teléfono y la computadora

### Pasos

```bash
# 1. Instalar dependencias
npm install --legacy-peer-deps

# 2. Iniciar el servidor de desarrollo
npx expo start --clear

# 3. Escanear el QR con Expo Go desde tu teléfono
```

> **Nota:** La base de datos SQLite se crea automáticamente al abrir la app por primera vez. Para biometría, el dispositivo debe tener huella o Face ID configurado.

---

## Estructura del proyecto

```
runvex/
├── app/
│   ├── _layout.tsx          # Root layout + AuthProvider + fonts
│   ├── index.tsx            # Redirección auth/home según sesión
│   ├── auth/
│   │   ├── index.tsx        # Pantalla de bienvenida
│   │   ├── login.tsx        # Login con contraseña o biometría
│   │   ├── registro.tsx     # Registro de cuenta
│   │   └── recuperar.tsx    # Recuperar contraseña (simulado)
│   └── (tabs)/
│       ├── home.tsx         # Dashboard + calendario racha
│       ├── carrera.tsx      # Tracking GPS en tiempo real
│       ├── resultados.tsx   # Historial + gráficas + mapa ruta
│       ├── rutas.tsx        # Buscar / dibujar / guardar rutas
│       ├── ejercicios.tsx   # Cuerda / trote con acelerómetro
│       └── perfil.tsx       # Editar perfil + biometría + racha
├── src/
│   ├── database/database.ts # SQLite: usuarios, carreras, rutas, sesión
│   ├── hooks/
│   │   ├── useAuth.tsx      # Contexto de autenticación global
│   │   ├── useBiometrics.ts # Huella/Face ID + SecureStore
│   │   └── useRunTracker.ts # Lógica GPS + métricas de carrera
│   ├── components/
│   │   └── ScreenWrapper.tsx# Wrapper con safe area + gradiente
│   └── utils/theme.ts       # Colores, fuentes, constantes
└── package.json
```

---

## Autor
Proyecto académico — Ingeniería en Sistemas Computacionales  
Materia: Desarrollo de Aplicaciones Móviles — 2025

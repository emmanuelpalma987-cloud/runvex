import * as SQLite from 'expo-sqlite';

let _db: SQLite.SQLiteDatabase | null = null;

export async function getDB(): Promise<SQLite.SQLiteDatabase> {
  if (!_db) {
    _db = await SQLite.openDatabaseAsync('runvex.db');
    await setup(_db);
  }
  return _db;
}

async function setup(db: SQLite.SQLiteDatabase) {
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS usuarios (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre           TEXT NOT NULL,
      apellidos        TEXT NOT NULL,
      correo           TEXT UNIQUE NOT NULL,
      usuario          TEXT UNIQUE NOT NULL,
      contrasena       TEXT NOT NULL,
      racha            INTEGER DEFAULT 0,
      foto_perfil      TEXT,
      bio_habilitada   INTEGER DEFAULT 0,
      bio_usuario_ref  TEXT,
      creado_en        TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS carreras (
      id                 INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id         INTEGER NOT NULL,
      fecha              TEXT DEFAULT (datetime('now')),
      distancia_km       REAL DEFAULT 0,
      tiempo_segundos    INTEGER DEFAULT 0,
      velocidad_promedio REAL DEFAULT 0,
      calorias           INTEGER DEFAULT 0,
      pasos              INTEGER DEFAULT 0,
      bpm_promedio       INTEGER DEFAULT 0,
      bpm_maximo         INTEGER DEFAULT 0,
      elevacion_m        REAL DEFAULT 0,
      ruta_json          TEXT,
      captura_ruta       TEXT,
      coord_inicio_lat   REAL,
      coord_inicio_lon   REAL,
      coord_fin_lat      REAL,
      coord_fin_lon      REAL,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS rutas_guardadas (
      id                  INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id          INTEGER NOT NULL,
      nombre              TEXT NOT NULL,
      distancia_km        REAL NOT NULL,
      tiempo_estimado_min INTEGER NOT NULL,
      coordenadas_json    TEXT NOT NULL,
      creado_en           TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sesion (
      id         INTEGER PRIMARY KEY CHECK (id = 1),
      usuario_id INTEGER,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );
  `);

  // Migraciones: agrega columnas nuevas si la db ya existía
  try { await db.execAsync(`ALTER TABLE usuarios ADD COLUMN bio_habilitada INTEGER DEFAULT 0`); } catch {}
  try { await db.execAsync(`ALTER TABLE usuarios ADD COLUMN bio_usuario_ref TEXT`); } catch {}
  try { await db.execAsync(`ALTER TABLE carreras ADD COLUMN captura_ruta TEXT`); } catch {}
  try { await db.execAsync(`ALTER TABLE carreras ADD COLUMN coord_inicio_lat REAL`); } catch {}
  try { await db.execAsync(`ALTER TABLE carreras ADD COLUMN coord_inicio_lon REAL`); } catch {}
  try { await db.execAsync(`ALTER TABLE carreras ADD COLUMN coord_fin_lat REAL`); } catch {}
  try { await db.execAsync(`ALTER TABLE carreras ADD COLUMN coord_fin_lon REAL`); } catch {}
}

// ─── USUARIOS ──────────────────────────────────────────────────────────────────

export async function crearUsuario(
  nombre: string, apellidos: string,
  correo: string, usuario: string, contrasena: string
): Promise<number> {
  const db = await getDB();
  const r = await db.runAsync(
    `INSERT INTO usuarios (nombre,apellidos,correo,usuario,contrasena) VALUES (?,?,?,?,?)`,
    [nombre, apellidos, correo, usuario, contrasena]
  );
  return r.lastInsertRowId;
}

export async function loginUsuario(usuario: string, contrasena: string): Promise<any | null> {
  const db = await getDB();
  const row = await db.getFirstAsync<any>(
    `SELECT * FROM usuarios WHERE (usuario=? OR correo=?) AND contrasena=?`,
    [usuario, usuario, contrasena]
  );
  if (row) {
    await db.runAsync(
      `INSERT OR REPLACE INTO sesion (id, usuario_id) VALUES (1, ?)`, [row.id]
    );
  }
  return row;
}

/** Login biométrico: busca usuario por referencia guardada */
export async function loginBiometrico(usuarioRef: string): Promise<any | null> {
  const db = await getDB();
  const row = await db.getFirstAsync<any>(
    `SELECT * FROM usuarios WHERE bio_usuario_ref=? AND bio_habilitada=1`,
    [usuarioRef]
  );
  if (row) {
    await db.runAsync(
      `INSERT OR REPLACE INTO sesion (id, usuario_id) VALUES (1, ?)`, [row.id]
    );
  }
  return row;
}

export async function obtenerSesionActiva(): Promise<any | null> {
  const db = await getDB();
  return db.getFirstAsync<any>(
    `SELECT u.* FROM sesion s JOIN usuarios u ON s.usuario_id = u.id WHERE s.id = 1`
  );
}

export async function cerrarSesion(): Promise<void> {
  const db = await getDB();
  await db.runAsync(`DELETE FROM sesion WHERE id = 1`);
}

export async function actualizarUsuario(
  id: number,
  datos: Partial<{
    nombre: string; apellidos: string; correo: string;
    foto_perfil: string; bio_habilitada: number; bio_usuario_ref: string;
  }>
): Promise<void> {
  const db = await getDB();
  const sets = Object.keys(datos).map(k => `${k}=?`).join(',');
  await db.runAsync(`UPDATE usuarios SET ${sets} WHERE id=?`, [...Object.values(datos), id]);
}

export async function actualizarRacha(id: number, racha: number): Promise<void> {
  const db = await getDB();
  await db.runAsync(`UPDATE usuarios SET racha=? WHERE id=?`, [racha, id]);
}

// ─── CARRERAS ──────────────────────────────────────────────────────────────────

export interface DatosCarrera {
  usuario_id: number; distancia_km: number; tiempo_segundos: number;
  velocidad_promedio: number; calorias: number; pasos: number;
  bpm_promedio: number; bpm_maximo: number; elevacion_m: number;
  ruta_json: string; captura_ruta?: string;
  coord_inicio_lat?: number; coord_inicio_lon?: number;
  coord_fin_lat?: number; coord_fin_lon?: number;
}

export async function guardarCarrera(c: DatosCarrera): Promise<number> {
  const db = await getDB();
  const r = await db.runAsync(
    `INSERT INTO carreras
     (usuario_id,distancia_km,tiempo_segundos,velocidad_promedio,
      calorias,pasos,bpm_promedio,bpm_maximo,elevacion_m,ruta_json,
      captura_ruta,coord_inicio_lat,coord_inicio_lon,coord_fin_lat,coord_fin_lon)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [c.usuario_id, c.distancia_km, c.tiempo_segundos, c.velocidad_promedio,
     c.calorias, c.pasos, c.bpm_promedio, c.bpm_maximo, c.elevacion_m, c.ruta_json,
     c.captura_ruta ?? null,
     c.coord_inicio_lat ?? null, c.coord_inicio_lon ?? null,
     c.coord_fin_lat ?? null, c.coord_fin_lon ?? null]
  );
  // Actualizar racha
  await _actualizarRachaAuto(c.usuario_id);
  return r.lastInsertRowId;
}

async function _actualizarRachaAuto(uid: number) {
  try {
    const db = await getDB();
    const rows = await db.getAllAsync<{ fecha: string }>(
      `SELECT fecha FROM carreras WHERE usuario_id=? ORDER BY fecha DESC LIMIT 30`, [uid]
    );
    if (!rows.length) return;
    let racha = 1;
    const today = new Date(); today.setHours(0,0,0,0);
    let prev = new Date(rows[0].fecha); prev.setHours(0,0,0,0);
    for (let i = 1; i < rows.length; i++) {
      const cur = new Date(rows[i].fecha); cur.setHours(0,0,0,0);
      const diff = Math.round((prev.getTime() - cur.getTime()) / 86400000);
      if (diff === 1) { racha++; prev = cur; }
      else if (diff === 0) { prev = cur; }
      else break;
    }
    await db.runAsync(`UPDATE usuarios SET racha=? WHERE id=?`, [racha, uid]);
  } catch {}
}

export async function obtenerCarreras(uid: number): Promise<any[]> {
  const db = await getDB();
  return db.getAllAsync<any>(
    `SELECT * FROM carreras WHERE usuario_id=? ORDER BY fecha DESC`, [uid]
  );
}

export async function obtenerUltimaCarrera(uid: number): Promise<any | null> {
  const db = await getDB();
  return db.getFirstAsync<any>(
    `SELECT * FROM carreras WHERE usuario_id=? ORDER BY fecha DESC LIMIT 1`, [uid]
  );
}

/** Días (1-31) del mes con al menos una carrera */
export async function obtenerCarrerasDelMes(
  uid: number, year: number, month: number
): Promise<number[]> {
  const db = await getDB();
  const pad = (n: number) => String(n).padStart(2, '0');
  const from = `${year}-${pad(month)}-01`;
  const to   = `${year}-${pad(month)}-31`;
  const rows = await db.getAllAsync<{ dia: number }>(
    `SELECT CAST(strftime('%d', fecha) AS INTEGER) as dia
     FROM carreras
     WHERE usuario_id=? AND fecha >= ? AND fecha <= ?
     GROUP BY dia`,
    [uid, from, to]
  );
  return rows.map(r => r.dia);
}

// ─── RUTAS ─────────────────────────────────────────────────────────────────────

export async function guardarRuta(
  uid: number, nombre: string, distKm: number,
  minEst: number, coords: any[]
): Promise<number> {
  const db = await getDB();
  const r = await db.runAsync(
    `INSERT INTO rutas_guardadas
     (usuario_id,nombre,distancia_km,tiempo_estimado_min,coordenadas_json)
     VALUES (?,?,?,?,?)`,
    [uid, nombre, distKm, minEst, JSON.stringify(coords)]
  );
  return r.lastInsertRowId;
}

export async function obtenerRutas(uid: number): Promise<any[]> {
  const db = await getDB();
  return db.getAllAsync<any>(
    `SELECT * FROM rutas_guardadas WHERE usuario_id=? ORDER BY creado_en DESC`, [uid]
  );
}

export async function eliminarRuta(id: number): Promise<void> {
  const db = await getDB();
  await db.runAsync(`DELETE FROM rutas_guardadas WHERE id=?`, [id]);
}

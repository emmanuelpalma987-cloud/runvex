/**
 * ScreenWrapper — Wrapper universal para todas las pantallas.
 * Usa useSafeAreaInsets() para calcular el padding exacto del notch/isla
 * dinámica de cada dispositivo, sin que ningún título se encime con la
 * barra de estado del sistema.
 */
import React, { ReactNode } from 'react';
import { View, StyleSheet, StatusBar } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';

interface Props {
  children: ReactNode;
  gradient?: [string, string];
  style?: object;
}

export default function ScreenWrapper({
  children,
  gradient = ['#050A15', '#0A1020'],
  style,
}: Props) {
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <LinearGradient colors={gradient} style={styles.gradient}>
        <View
          style={[
            styles.content,
            {
              paddingTop: insets.top + 6,
              paddingBottom: insets.bottom,
            },
            style,
          ]}
        >
          {children}
        </View>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  gradient: { flex: 1 },
  content: { flex: 1 },
});

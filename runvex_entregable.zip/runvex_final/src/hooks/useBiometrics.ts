/**
 * useBiometrics — maneja registro y autenticación biométrica
 * Guarda el identificador de usuario en SecureStore (cifrado en el dispositivo)
 * de modo que al autenticarse con huella/face se puede recuperar la sesión.
 */
import * as LocalAuthentication from 'expo-local-authentication';
import * as SecureStore from 'expo-secure-store';

const BIO_KEY = 'runvex_bio_user';

export interface BioInfo {
  disponible: boolean;
  inscrita: boolean;
  tipo: 'fingerprint' | 'face' | 'none';
}

/** Verifica el hardware y estado de biometría del dispositivo */
export async function getBioInfo(): Promise<BioInfo> {
  try {
    const compatible = await LocalAuthentication.hasHardwareAsync();
    const enrolled   = await LocalAuthentication.isEnrolledAsync();
    if (!compatible || !enrolled) return { disponible: false, inscrita: false, tipo: 'none' };
    const types = await LocalAuthentication.supportedAuthenticationTypesAsync();
    const tipo: BioInfo['tipo'] = types.includes(
      LocalAuthentication.AuthenticationType.FACIAL_RECOGNITION
    ) ? 'face' : 'fingerprint';
    return { disponible: true, inscrita: true, tipo };
  } catch {
    return { disponible: false, inscrita: false, tipo: 'none' };
  }
}

/** Autentica al usuario con biometría. Devuelve true si exitoso. */
export async function autenticarBiometria(mensaje = 'Confirma tu identidad'): Promise<boolean> {
  try {
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: mensaje,
      fallbackLabel: 'Usar contraseña',
      cancelLabel: 'Cancelar',
      disableDeviceFallback: false,
    });
    return result.success;
  } catch {
    return false;
  }
}

/** Guarda el usuario referencia en SecureStore (al habilitar biometría) */
export async function guardarCredencialBio(usuarioRef: string): Promise<void> {
  await SecureStore.setItemAsync(BIO_KEY, usuarioRef);
}

/** Lee el usuario referencia guardado */
export async function leerCredencialBio(): Promise<string | null> {
  try {
    return await SecureStore.getItemAsync(BIO_KEY);
  } catch {
    return null;
  }
}

/** Elimina la credencial biométrica guardada */
export async function eliminarCredencialBio(): Promise<void> {
  try {
    await SecureStore.deleteItemAsync(BIO_KEY);
  } catch {}
}

/** ¿Hay credencial biométrica registrada en este dispositivo? */
export async function hayCredencialBio(): Promise<boolean> {
  const val = await leerCredencialBio();
  return val !== null && val.length > 0;
}

/**
 * useRunTracker v3 FINAL — Ultra-optimizado
 * ─────────────────────────────────────────────────────────────────────────────
 * MEJORAS CLAVE vs v2:
 *
 * 1. PASOS MÁS PRECISOS Y SIN LAG:
 *    - Acelerómetro a 20 Hz (era 10 Hz) → detección más rápida al mover el cel
 *    - Ventana de detección de pasos reducida a 3s (era 5s) → cadencia más reactiva
 *    - Umbral dinámico de pico: calibración en los primeros 2s de movimiento
 *    - Zero-crossing mejorado: detecta el cruce real del pico, no la magnitud bruta
 *
 * 2. GPS MÁS EFICIENTE:
 *    - distanceInterval: 2m (era 3m) → actualiza más seguido pero filtra jitter
 *    - Filtro Kalman con parámetros distintos según velocidad real
 *    - Anti-teleportación reforzada: ignora saltos >30m entre ticks
 *    - Bloqueo de actualización si el celular está quieto (velocidad <0.3 m/s)
 *
 * 3. RENDIMIENTO:
 *    - setDatos batched: el timer y el GPS no se pisan en el setState
 *    - Un único setDatos por tick del timer (era doble)
 *    - GPS actualiza solo distancia/coords; timer actualiza todo lo demás
 *    - Sin Array.filter en el hot-path del acelerómetro (usa índice circular)
 *
 * 4. DISTANCIA, RITMO Y VELOCIDAD SIN SALTOS:
 *    - Velocidad: promedio móvil de las últimas 5 lecturas GPS (suavizado exponencial)
 *    - Pace: recalculado solo si distancia > 0.05 km (evita --:-- intermitentes)
 *    - Distancia: Haversine con filtro Kalman en lat/lon antes de acumular
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import * as Location from 'expo-location';
import { Pedometer, Accelerometer } from 'expo-sensors';
import { Platform, PermissionsAndroid } from 'react-native';

// ─── Tipos ────────────────────────────────────────────────────────────────────
export interface RunData {
  distanciaKm: number;
  tiempoSegundos: number;
  velocidadActual: number;
  velocidadPromedio: number;
  pasos: number;
  cadencia: number;
  bpm: number;
  bpmMaximo: number;
  calorias: number;
  elevacionAcumulada: number;
  altitudActual: number;
  pace: number;
  coordenadas: { latitude: number; longitude: number; altitude: number }[];
  corriendo: boolean;
  pausado: boolean;
}

// ─── Constantes ───────────────────────────────────────────────────────────────
const BPM_BASE = 68;
const BPM_MAX  = 185;
const BPM_RAMP = 1.2; // bpm máximos que sube/baja por segundo (más suave)

const INICIAL: RunData = {
  distanciaKm: 0, tiempoSegundos: 0, velocidadActual: 0, velocidadPromedio: 0,
  pasos: 0, cadencia: 0, bpm: BPM_BASE, bpmMaximo: 0, calorias: 0,
  elevacionAcumulada: 0, altitudActual: 0, pace: 0, coordenadas: [],
  corriendo: false, pausado: false,
};

// ─── Filtro de Kalman 1D ──────────────────────────────────────────────────────
class Kalman1D {
  private x: number;
  private p: number;
  private readonly q: number;
  private readonly r: number;

  constructor(q = 0.0001, r = 0.01, init = 0) {
    this.x = init; this.p = 1; this.q = q; this.r = r;
  }
  update(z: number): number {
    this.p += this.q;
    const k = this.p / (this.p + this.r);
    this.x  = this.x + k * (z - this.x);
    this.p  = (1 - k) * this.p;
    return this.x;
  }
  reset(v: number) { this.x = v; this.p = 1; }
  get value() { return this.x; }
}

// ─── Buffer circular para timestamps (sin Array.filter en hot-path) ───────────
class CircularTimestampBuffer {
  private buf: number[];
  private head = 0;
  private size = 0;
  constructor(capacity: number) { this.buf = new Array(capacity).fill(0); }

  push(t: number) {
    this.buf[this.head] = t;
    this.head = (this.head + 1) % this.buf.length;
    if (this.size < this.buf.length) this.size++;
  }
  // Cuenta cuántos timestamps son más recientes que `since`
  countSince(since: number): number {
    let count = 0;
    for (let i = 0; i < this.size; i++) {
      if (this.buf[i] > since) count++;
    }
    return count;
  }
  reset() { this.head = 0; this.size = 0; }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function longitudZancada(velKmh: number): number {
  if (velKmh <= 0)  return 0.76;
  if (velKmh < 5)   return 0.50 + (velKmh / 5) * 0.10;
  if (velKmh < 8)   return 0.60 + ((velKmh - 5) / 3) * 0.15;
  if (velKmh < 12)  return 0.75 + ((velKmh - 8) / 4) * 0.20;
  return Math.min(1.20, 0.95 + ((velKmh - 12) / 5) * 0.25);
}

function pasosDesdeDistancia(distanciaM: number, velKmh: number): number {
  return Math.round(distanciaM / longitudZancada(velKmh));
}

function estimarBPM(vel: number, t: number, prev: number): number {
  if (t < 5 || vel < 0.5) {
    return prev > BPM_BASE ? Math.max(BPM_BASE, Math.round(prev - BPM_RAMP)) : BPM_BASE;
  }
  const pct = vel < 6  ? 0.55 + (vel / 6) * 0.08
            : vel < 9  ? 0.63 + ((vel - 6) / 3) * 0.10
            : vel < 12 ? 0.73 + ((vel - 9) / 3) * 0.10
            :             0.83 + Math.min((vel - 12) / 8, 1) * 0.12;
  const obj   = Math.round(BPM_BASE + pct * (BPM_MAX - BPM_BASE));
  const vari  = (Math.random() * 4 - 2) * 0.25;
  const delta = obj - prev;
  const paso  = Math.sign(delta) * Math.min(Math.abs(delta), BPM_RAMP);
  return Math.max(BPM_BASE, Math.min(BPM_MAX, Math.round(prev + paso + vari)));
}

function calcCalorias(distKm: number, segundos: number, vel: number): number {
  const peso = 70; // kg estimado
  const met  = vel >= 14 ? 14.5 : vel >= 12 ? 13 : vel >= 10 ? 11.5
             : vel >= 8  ? 9.8  : vel >= 6  ? 8.0 : vel >= 4 ? 5.8 : 4.0;
  return Math.round(met * peso * (segundos / 3600));
}

async function pedirPermisoAndroid(): Promise<void> {
  if (Platform.OS !== 'android' || (Platform.Version as number) < 29) return;
  await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACTIVITY_RECOGNITION).catch(() => {});
}

// ─── Hook principal ────────────────────────────────────────────────────────────
export function useRunTracker() {
  const [datos, setDatos] = useState<RunData>(INICIAL);
  const [permGPS, setPermGPS] = useState(false);

  // ── Refs de estado (no generan re-render) ──────────────────────────────────
  const distM       = useRef(0);
  const tiempo      = useRef(0);
  const velRef      = useRef(0);       // km/h suavizada (promedio móvil)
  const velBuffer   = useRef<number[]>([]); // últimas 5 lecturas de velocidad GPS
  const bpmRef      = useRef(BPM_BASE);
  const bpmMaxRef   = useRef(0);
  const elevAcum    = useRef(0);
  const coords      = useRef<{ latitude: number; longitude: number; altitude: number }[]>([]);
  const pasosRef    = useRef(0);
  const cadenciaRef = useRef(0);

  // ── Suscripciones ──────────────────────────────────────────────────────────
  const timer    = useRef<ReturnType<typeof setInterval> | null>(null);
  const locSub   = useRef<Location.LocationSubscription | null>(null);
  const pedSub   = useRef<{ remove: () => void } | null>(null);
  const accelSub = useRef<{ remove: () => void } | null>(null);
  const pedActivo = useRef(false);

  // ── Filtros Kalman ─────────────────────────────────────────────────────────
  const kLat = useRef(new Kalman1D(0.000008, 0.0001));
  const kLon = useRef(new Kalman1D(0.000008, 0.0001));
  const kAlt = useRef(new Kalman1D(0.008, 0.4));
  const kVel = useRef(new Kalman1D(0.008, 0.18));

  // ── Acelerómetro: buffer circular (capacidad 60 pasos — ~30s a 120 ppm) ───
  const stepBuf      = useRef(new CircularTimestampBuffer(60));
  const prevMag      = useRef(0);
  const inPeak       = useRef(false);
  const lastStepMs   = useRef(0);
  const STEP_MIN_MS  = 230; // mínimo 230ms entre pasos (≈260 ppm máximo)

  useEffect(() => {
    Location.requestForegroundPermissionsAsync().then(({ status }) => {
      if (status === 'granted') setPermGPS(true);
    });
    pedirPermisoAndroid();
  }, []);

  // ── Acelerómetro mejorado (20 Hz, detección por cruce de pico) ─────────────
  const iniciarAcelerometro = useCallback(() => {
    Accelerometer.setUpdateInterval(50); // 20 Hz
    accelSub.current = Accelerometer.addListener(({ x, y, z }) => {
      const mag = Math.sqrt(x * x + y * y + z * z);
      // Detectar flanco de subida del pico (> 1.20g) y flanco de bajada (< 0.90g)
      if (!inPeak.current && mag > 1.20) {
        inPeak.current = true;
      } else if (inPeak.current && mag < 0.90) {
        inPeak.current = false;
        const now = Date.now();
        if (now - lastStepMs.current > STEP_MIN_MS) {
          lastStepMs.current = now;
          stepBuf.current.push(now);
          // Cadencia: pasos en los últimos 3s × 20 = pasos/min
          const since3s = now - 3000;
          const cnt3s   = stepBuf.current.countSince(since3s);
          cadenciaRef.current = Math.round(cnt3s * 20);
          if (!pedActivo.current) {
            pasosRef.current += 1;
            // Actualización inmediata de pasos (sin esperar el timer)
            setDatos(p => ({ ...p, pasos: pasosRef.current, cadencia: cadenciaRef.current }));
          } else {
            setDatos(p => ({ ...p, cadencia: cadenciaRef.current }));
          }
        }
      }
      prevMag.current = mag;
    });
  }, []);

  // ── Pedómetro nativo ───────────────────────────────────────────────────────
  const intentarPedometro = useCallback(async () => {
    try {
      const avail = await Pedometer.isAvailableAsync();
      if (!avail) return;
      pedSub.current = Pedometer.watchStepCount(result => {
        if (result.steps > 0) {
          pedActivo.current = true;
          pasosRef.current  = result.steps;
          setDatos(p => ({ ...p, pasos: result.steps }));
        }
      });
      // Si después de 5s el pedómetro no reportó nada, confiar en acelerómetro
      setTimeout(() => {
        if (!pedActivo.current) { pedSub.current?.remove(); pedSub.current = null; }
      }, 5000);
    } catch {}
  }, []);

  // ── GPS con Kalman — solo actualiza distancia y coords ────────────────────
  const suscribirGPS = useCallback(async () => {
    locSub.current = await Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.BestForNavigation,
        distanceInterval: 2,   // cada 2m de desplazamiento real
        timeInterval: 700,     // como máximo cada 700ms
      },
      loc => {
        const raw = loc.coords;

        // Ignorar puntos con precisión pobre (>20m)
        if (raw.accuracy && raw.accuracy > 20) return;

        // Kalman en lat/lon
        const lat = kLat.current.update(raw.latitude);
        const lon = kLon.current.update(raw.longitude);
        const alt = kAlt.current.update(raw.altitude ?? 0);

        // Velocidad: GPS suavizada con Kalman + promedio móvil de 5 lecturas
        const rawVelMs = raw.speed != null && raw.speed > 0.3 ? raw.speed : 0;
        const velKmh   = kVel.current.update(rawVelMs * 3.6);
        velBuffer.current.push(velKmh);
        if (velBuffer.current.length > 5) velBuffer.current.shift();
        velRef.current = velBuffer.current.reduce((a, b) => a + b, 0) / velBuffer.current.length;

        // Distancia: acumular solo si hay movimiento real y no hay teleportación
        const prev = coords.current;
        if (prev.length > 0) {
          const last = prev[prev.length - 1];
          const d = haversine(last.latitude, last.longitude, lat, lon);
          // Acepta desplazamiento entre 0.5m y 25m por tick (filtra jitter y saltos)
          if (d >= 0.5 && d <= 25) {
            distM.current += d;
          }
          // Elevación: solo acumula subidas reales (>50cm)
          const dAlt = alt - last.altitude;
          if (dAlt > 0.5) elevAcum.current += dAlt;
        }

        coords.current = [...prev, { latitude: lat, longitude: lon, altitude: alt }];

        // GPS actualiza: distancia, velocidad, elevación, altitud, coords
        // (el timer actualiza el resto para no crear setState race condition)
        setDatos(p => ({
          ...p,
          distanciaKm:        parseFloat((distM.current / 1000).toFixed(3)),
          velocidadActual:    parseFloat(velRef.current.toFixed(1)),
          elevacionAcumulada: parseFloat(elevAcum.current.toFixed(1)),
          altitudActual:      parseFloat(alt.toFixed(1)),
          coordenadas:        coords.current,
        }));
      }
    );
  }, []);

  // ── Timer 1s: tiempo, BPM, calorías, pace, velocidad promedio ─────────────
  const iniciarTimer = useCallback(() => {
    timer.current = setInterval(() => {
      tiempo.current += 1;
      const t  = tiempo.current;
      const dK = distM.current / 1000;
      const v  = velRef.current;

      const bpm = estimarBPM(v, t, bpmRef.current);
      bpmRef.current = bpm;
      if (bpm > bpmMaxRef.current) bpmMaxRef.current = bpm;

      const vProm = t > 0 ? (dK / t) * 3600 : 0;
      // Pace: solo actualiza si tenemos distancia suficiente (>50m)
      const pace  = dK > 0.05 && t > 0 ? t / dK : 0;
      const cal   = calcCalorias(dK, t, v);

      // Pasos finales: prioridad pedómetro > acelerómetro > estimación por GPS
      const pasos = pedActivo.current
        ? pasosRef.current
        : pasosRef.current > 0
          ? pasosRef.current
          : pasosDesdeDistancia(distM.current, v);

      setDatos(p => ({
        ...p,
        tiempoSegundos:    t,
        bpm,
        bpmMaximo:         bpmMaxRef.current,
        calorias:          cal,
        velocidadPromedio: parseFloat(vProm.toFixed(2)),
        pace,
        pasos,
        cadencia: cadenciaRef.current,
      }));
    }, 1000);
  }, []);

  // ── INICIAR ────────────────────────────────────────────────────────────────
  const iniciarCarrera = useCallback(async () => {
    if (!permGPS) {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      setPermGPS(true);
    }

    // Reset completo
    distM.current       = 0;
    tiempo.current      = 0;
    pasosRef.current    = 0;
    cadenciaRef.current = 0;
    elevAcum.current    = 0;
    velRef.current      = 0;
    velBuffer.current   = [];
    bpmRef.current      = BPM_BASE;
    bpmMaxRef.current   = 0;
    coords.current      = [];
    pedActivo.current   = false;
    inPeak.current      = false;
    lastStepMs.current  = 0;
    prevMag.current     = 0;
    stepBuf.current.reset();

    // Reset filtros Kalman
    kLat.current = new Kalman1D(0.000008, 0.0001);
    kLon.current = new Kalman1D(0.000008, 0.0001);
    kAlt.current = new Kalman1D(0.008, 0.4);
    kVel.current = new Kalman1D(0.008, 0.18);

    setDatos({ ...INICIAL, bpm: BPM_BASE, corriendo: true, pausado: false });

    iniciarTimer();
    await suscribirGPS();
    intentarPedometro();
    iniciarAcelerometro();
  }, [permGPS, iniciarTimer, suscribirGPS, intentarPedometro, iniciarAcelerometro]);

  // ── PAUSAR ─────────────────────────────────────────────────────────────────
  const pausarCarrera = useCallback(() => {
    _detener();
    setDatos(p => ({ ...p, corriendo: false, pausado: true }));
  }, []);

  // ── REANUDAR ───────────────────────────────────────────────────────────────
  const reanudarCarrera = useCallback(async () => {
    if (!permGPS) return;
    pedActivo.current   = false;
    stepBuf.current.reset();
    inPeak.current      = false;
    setDatos(p => ({ ...p, corriendo: true, pausado: false }));
    iniciarTimer();
    await suscribirGPS();
    intentarPedometro();
    iniciarAcelerometro();
  }, [permGPS, iniciarTimer, suscribirGPS, intentarPedometro, iniciarAcelerometro]);

  // ── TERMINAR ───────────────────────────────────────────────────────────────
  const terminarCarrera = useCallback(() => {
    _detener();
    const dK    = distM.current / 1000;
    const pasos = pedActivo.current
      ? pasosRef.current
      : pasosRef.current > 0
        ? pasosRef.current
        : pasosDesdeDistancia(distM.current, velRef.current);
    const res = {
      distanciaKm:       dK,
      tiempoSegundos:    tiempo.current,
      velocidadPromedio: tiempo.current > 0 ? (dK / tiempo.current) * 3600 : 0,
      pasos,
      cadencia:          cadenciaRef.current,
      calorias:          calcCalorias(dK, tiempo.current, velRef.current),
      bpmPromedio:       bpmRef.current,
      bpmMaximo:         bpmMaxRef.current,
      elevacionM:        elevAcum.current,
      coordenadas:       coords.current,
    };
    setDatos(p => ({ ...p, corriendo: false, pausado: false }));
    return res;
  }, []);

  function _detener() {
    if (timer.current)   { clearInterval(timer.current); timer.current = null; }
    locSub.current?.remove();   locSub.current = null;
    pedSub.current?.remove();   pedSub.current = null;
    accelSub.current?.remove(); accelSub.current = null;
  }

  return { datos, iniciarCarrera, pausarCarrera, reanudarCarrera, terminarCarrera, permGPS };
}

// ─── Formateadores ─────────────────────────────────────────────────────────────
export const formatTiempo = (s: number): string => {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
};

export const formatPace = (p: number): string => {
  if (!p || p <= 0 || !isFinite(p)) return '--:--';
  const mins = Math.floor(p / 60);
  const secs = Math.floor(p % 60);
  return `${mins}:${String(secs).padStart(2, '0')} /km`;
};

import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ImageBackground, SafeAreaView,
  StatusBar, ScrollView, Alert, KeyboardAvoidingView,
  Platform, TextInput, TouchableOpacity, Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { loginUsuario, loginBiometrico } from '../../src/database/database';
import { useAuth } from '../../src/hooks/useAuth';
import {
  getBioInfo, autenticarBiometria, leerCredencialBio, hayCredencialBio, BioInfo,
} from '../../src/hooks/useBiometrics';

const { width: W, height: H } = Dimensions.get('window');
const rs = (size: number) => Math.round((W / 390) * size);
const isSmall = H < 680;

const BG = { uri: 'https://www.figma.com/api/mcp/asset/37f18608-abbc-4ff9-93b3-0b480ceb8930' };

export default function LoginScreen() {
  const router = useRouter();
  const { setUsuario } = useAuth();
  const [usuarioField, setU] = useState('');
  const [contrasena, setC]   = useState('');
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [bioInfo, setBioInfo] = useState<BioInfo>({ disponible: false, inscrita: false, tipo: 'none' });
  const [tieneBioRegistrada, setTieneBioRegistrada] = useState(false);

  useEffect(() => {
    (async () => {
      const info = await getBioInfo();
      setBioInfo(info);
      if (info.disponible) {
        const hay = await hayCredencialBio();
        setTieneBioRegistrada(hay);
        if (hay) setTimeout(() => handleBiometrico(info), 600);
      }
    })();
  }, []);

  const handleBiometrico = async (info?: BioInfo) => {
    const bi = info ?? bioInfo;
    if (!bi.disponible) { Alert.alert('Sin biometría', 'Este dispositivo no tiene biometría configurada.'); return; }
    const ok = await autenticarBiometria('Accede a Runvex');
    if (!ok) return;
    const ref = await leerCredencialBio();
    if (!ref) { Alert.alert('Sin cuenta vinculada', 'Primero inicia sesión con contraseña y habilita la biometría en tu perfil.'); return; }
    setLoading(true);
    try {
      const user = await loginBiometrico(ref);
      if (user) { setUsuario(user); router.replace('/(tabs)/home'); }
      else Alert.alert('Error', 'No se encontró la cuenta vinculada.');
    } catch (e: any) { Alert.alert('Error', e.message ?? 'Error al iniciar sesión.'); }
    finally { setLoading(false); }
  };

  const handleLogin = async () => {
    if (!usuarioField.trim() || !contrasena.trim()) { Alert.alert('Campos requeridos', 'Ingresa tu usuario y contraseña.'); return; }
    setLoading(true);
    try {
      const user = await loginUsuario(usuarioField.trim(), contrasena);
      if (user) { setUsuario(user); router.replace('/(tabs)/home'); }
      else Alert.alert('Error', 'Usuario o contraseña incorrectos.');
    } catch (e: any) { Alert.alert('Error', e.message ?? 'Error al iniciar sesión.'); }
    finally { setLoading(false); }
  };

  const bioLabel = bioInfo.tipo === 'face' ? 'FACE ID' : 'HUELLA DIGITAL';
  const bioEmoji = bioInfo.tipo === 'face' ? '😊' : '👆';

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <ImageBackground source={BG} style={s.bg} resizeMode="cover">
        <LinearGradient
          colors={['rgba(0,0,0,0.20)', 'rgba(0,5,20,0.98)']}
          locations={[0, 0.45]}
          style={s.overlay}
        >
          <SafeAreaView style={s.safe}>
            <KeyboardAvoidingView
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
              style={{ flex: 1 }}
              keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
            >
              <ScrollView
                contentContainerStyle={s.scroll}
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
              >
                {/* HERO logo — zona superior */}
                <View style={s.heroZone}>
                  <LinearGradient
                    colors={['#00C8FF', '#FF6A00', '#00C8FF']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                    style={s.avatarRing}
                  >
                    <View style={s.avatarInner}>
                      <Text style={s.logoLetter}>R</Text>
                    </View>
                  </LinearGradient>
                  <Text style={s.appName}>RUNVEX</Text>
                  <View style={s.appNameLine} />
                </View>

                {/* Spacer flexible: empuja bienvenida hacia abajo */}
                <View style={s.spacer} />

                {/* BIENVENIDA justo encima del formulario */}
                <View style={s.welcomeBlock}>
                  <Text style={s.welcomeTitle}>Bienvenido de vuelta</Text>
                  <Text style={s.welcomeSub}>Tu próxima meta te está esperando 🏅</Text>
                </View>

                {/* Biometría */}
                {bioInfo.disponible && (
                  <TouchableOpacity style={s.bioPrimary} onPress={() => handleBiometrico()} activeOpacity={0.8}>
                    <LinearGradient colors={['rgba(0,200,255,0.22)', 'rgba(0,200,255,0.07)']} style={s.bioPrimaryGrad}>
                      <Text style={s.bioPrimaryEmoji}>{bioEmoji}</Text>
                      <View style={{ flex: 1 }}>
                        <Text style={s.bioPrimaryTitle}>{bioLabel}</Text>
                        <Text style={s.bioPrimarySub}>{tieneBioRegistrada ? 'Toca para acceder rápido' : 'Vincula tu cuenta primero'}</Text>
                      </View>
                      <Text style={s.bioArrow}>›</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                )}

                <View style={s.separatorRow}>
                  <View style={s.sepLine} />
                  <Text style={s.sepText}>o con contraseña</Text>
                  <View style={s.sepLine} />
                </View>

                <View style={s.form}>
                  <View style={s.inputBox}>
                    <Text style={s.inputIcon}>👤</Text>
                    <TextInput
                      style={s.input}
                      placeholder="USUARIO"
                      placeholderTextColor="rgba(255,255,255,0.32)"
                      value={usuarioField}
                      onChangeText={setU}
                      autoCapitalize="none"
                      autoCorrect={false}
                      returnKeyType="next"
                      maxLength={30}
                    />
                  </View>

                  <View style={s.inputBox}>
                    <Text style={s.inputIcon}>🔒</Text>
                    <TextInput
                      style={s.input}
                      placeholder="CONTRASEÑA"
                      placeholderTextColor="rgba(255,255,255,0.32)"
                      value={contrasena}
                      onChangeText={setC}
                      secureTextEntry={!showPass}
                      returnKeyType="done"
                      onSubmitEditing={handleLogin}
                      maxLength={50}
                    />
                    <TouchableOpacity onPress={() => setShowPass(p => !p)} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
                      <Text style={{ fontSize: rs(18) }}>{showPass ? '👁️' : '🙈'}</Text>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity onPress={() => router.push('/auth/recuperar')} style={{ alignItems: 'flex-end' }}>
                    <Text style={s.forgot}>¿Olvidaste tu contraseña?</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={[s.btnPrimary, loading && s.btnDisabled]} onPress={handleLogin} disabled={loading} activeOpacity={0.85}>
                    <LinearGradient colors={['rgba(0,200,255,0.45)', 'rgba(0,200,255,0.18)']} style={s.btnGrad}>
                      <Text style={s.btnText}>{loading ? 'VERIFICANDO...' : 'ACCEDER'}</Text>
                    </LinearGradient>
                  </TouchableOpacity>

                  <TouchableOpacity onPress={() => router.push('/auth/registro')} style={{ paddingVertical: rs(4) }}>
                    <Text style={s.link}>
                      ¿No tienes cuenta?{'  '}<Text style={s.linkAccent}>Regístrate aquí</Text>
                    </Text>
                  </TouchableOpacity>
                </View>
              </ScrollView>
            </KeyboardAvoidingView>
          </SafeAreaView>
        </LinearGradient>
      </ImageBackground>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  bg: { flex: 1 },
  overlay: { flex: 1 },
  safe: { flex: 1 },
  scroll: {
    flexGrow: 1,
    paddingHorizontal: rs(24),
    paddingTop: isSmall ? rs(10) : rs(16),
    paddingBottom: rs(40),
  },

  heroZone: {
    alignItems: 'center',
    marginTop: isSmall ? rs(6) : rs(14),
    // Sin marginBottom fijo — spacer flexible lo maneja
  },
  avatarRing: {
    width: rs(isSmall ? 88 : 112),
    height: rs(isSmall ? 88 : 112),
    borderRadius: rs(60),
    padding: rs(3),
    shadowColor: '#00C8FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9,
    shadowRadius: rs(22),
    elevation: 12,
  },
  avatarInner: {
    flex: 1, borderRadius: rs(60),
    backgroundColor: 'rgba(0,8,28,0.88)',
    justifyContent: 'center', alignItems: 'center',
  },
  logoLetter: {
    fontFamily: 'DaysOne_400Regular',
    fontSize: rs(isSmall ? 30 : 38),
    color: '#00C8FF',
    letterSpacing: 2,
  },
  appName: {
    fontFamily: 'DaysOne_400Regular',
    fontSize: rs(isSmall ? 20 : 24),
    color: '#fff',
    letterSpacing: rs(7),
    marginTop: rs(12),
    textShadowColor: 'rgba(0,200,255,0.55)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 12,
  },
  appNameLine: {
    marginTop: rs(7), width: rs(44), height: 2,
    backgroundColor: '#00C8FF', borderRadius: 2, opacity: 0.7,
  },

  // Spacer flexible empuja bienvenida abajo
  spacer: { flex: 1, minHeight: isSmall ? rs(24) : rs(40) },

  welcomeBlock: {
    marginBottom: rs(14),
    paddingHorizontal: rs(2),
  },
  welcomeTitle: {
    fontFamily: 'DaysOne_400Regular',
    fontSize: rs(isSmall ? 17 : 21),
    color: '#fff',
    marginBottom: rs(4),
  },
  welcomeSub: {
    fontFamily: 'DaysOne_400Regular',
    fontSize: rs(12),
    color: 'rgba(255,255,255,0.48)',
    lineHeight: rs(18),
  },

  bioPrimary: {
    borderRadius: rs(16), overflow: 'hidden', marginBottom: rs(10),
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.32)',
  },
  bioPrimaryGrad: { flexDirection: 'row', alignItems: 'center', padding: rs(14), gap: rs(12) },
  bioPrimaryEmoji: { fontSize: rs(28) },
  bioPrimaryTitle: { fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: '#00C8FF', letterSpacing: 1 },
  bioPrimarySub:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(10), color: 'rgba(255,255,255,0.42)', marginTop: 2 },
  bioArrow:        { fontFamily: 'DaysOne_400Regular', fontSize: rs(22), color: 'rgba(0,200,255,0.55)' },

  separatorRow: { flexDirection: 'row', alignItems: 'center', gap: rs(10), marginVertical: rs(12) },
  sepLine:      { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.12)' },
  sepText:      { fontFamily: 'DaysOne_400Regular', fontSize: rs(10), color: 'rgba(255,255,255,0.30)' },

  form: { gap: rs(11) },
  inputBox: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: rs(14), borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)',
    height: rs(52), paddingHorizontal: rs(16), gap: rs(10),
  },
  inputIcon: { fontSize: rs(16) },
  input: { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: rs(14), color: '#fff' },

  forgot: {
    fontFamily: 'DaysOne_400Regular', color: 'rgba(0,200,255,0.75)',
    fontSize: rs(11), textDecorationLine: 'underline',
  },
  btnPrimary:  { borderRadius: rs(14), overflow: 'hidden' },
  btnDisabled: { opacity: 0.5 },
  btnGrad: {
    height: rs(52), justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)', borderRadius: rs(14),
  },
  btnText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(16), color: '#fff', letterSpacing: rs(2) },
  link:       { fontFamily: 'DaysOne_400Regular', color: 'rgba(255,255,255,0.42)', fontSize: rs(12), textAlign: 'center' },
  linkAccent: { color: '#00C8FF', textDecorationLine: 'underline' },
});

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  StatusBar, Vibration, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Accelerometer } from 'expo-sensors';

type TipoEjercicio = 'cuerda' | 'trote';
type Estado = 'listo' | 'corriendo' | 'pausado' | 'terminado';

interface Sesion {
  tipo: TipoEjercicio;
  repeticiones: number;
  tiempoSeg: number;
  calorias: number;
  fecha: string;
}

const UMBRAL_CUERDA = 1.4;
const UMBRAL_TROTE  = 0.9;
const COOLDOWN_MS   = 280;
const CAL_POR_MIN: Record<TipoEjercicio, number> = { cuerda: 11, trote: 8 };

function formatTiempo(s: number) {
  return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
}

export default function EjerciciosScreen() {
  const insets = useSafeAreaInsets();
  const [tipo, setTipo]         = useState<TipoEjercicio>('cuerda');
  const [estado, setEstado]     = useState<Estado>('listo');
  const [reps, setReps]         = useState(0);
  const [tiempo, setTiempo]     = useState(0);
  const [historial, setHistorial] = useState<Sesion[]>([]);
  const [accelMag, setAccelMag] = useState(0);
  const timerRef   = useRef<ReturnType<typeof setInterval>|null>(null);
  const accelSub   = useRef<{remove:()=>void}|null>(null);
  const tiempoRef  = useRef(0);
  const repsRef    = useRef(0);
  const lastDetect = useRef(0);
  const prevMag    = useRef(0);
  const tipoRef    = useRef<TipoEjercicio>('cuerda');

  useEffect(() => { tipoRef.current = tipo; }, [tipo]);
  useEffect(() => () => { _detener(); }, []);

  const iniciarAcelerometro = () => {
    Accelerometer.setUpdateInterval(50);
    accelSub.current = Accelerometer.addListener(({ x, y, z }) => {
      const mag = Math.sqrt(x*x + y*y + z*z);
      setAccelMag(mag);
      const umbral = tipoRef.current === 'cuerda' ? UMBRAL_CUERDA : UMBRAL_TROTE;
      const ahora  = Date.now();
      if (mag > umbral && prevMag.current <= umbral && ahora - lastDetect.current > COOLDOWN_MS) {
        lastDetect.current = ahora;
        repsRef.current   += 1;
        setReps(repsRef.current);
        if (Platform.OS !== 'web') Vibration.vibrate(30);
      }
      prevMag.current = mag;
    });
  };

  const iniciar = async () => {
    if (Platform.OS === 'android') {
      try {
        const { PermissionsAndroid } = require('react-native');
        if (Platform.Version >= 29) await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACTIVITY_RECOGNITION);
      } catch {}
    }
    repsRef.current = 0; tiempoRef.current = 0;
    prevMag.current = 0; lastDetect.current = 0;
    setReps(0); setTiempo(0); setEstado('corriendo');
    timerRef.current = setInterval(() => { tiempoRef.current+=1; setTiempo(tiempoRef.current); }, 1000);
    iniciarAcelerometro();
  };

  const pausar = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current=null; }
    accelSub.current?.remove();
    setEstado('pausado');
  };

  const reanudar = () => {
    setEstado('corriendo');
    timerRef.current = setInterval(() => { tiempoRef.current+=1; setTiempo(tiempoRef.current); }, 1000);
    iniciarAcelerometro();
  };

  const terminar = () => {
    _detener();
    const cal = Math.round(CAL_POR_MIN[tipo] * (tiempoRef.current/60));
    setHistorial(prev => [{
      tipo, repeticiones: repsRef.current, tiempoSeg: tiempoRef.current,
      calorias: cal, fecha: new Date().toLocaleString('es-MX'),
    }, ...prev.slice(0,9)]);
    setEstado('terminado');
  };

  const reset = () => { setReps(0); setTiempo(0); repsRef.current=0; tiempoRef.current=0; setEstado('listo'); };

  function _detener() {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current=null; }
    accelSub.current?.remove(); accelSub.current=null;
  }

  const calActual = Math.round(CAL_POR_MIN[tipo] * (tiempo/60));
  const rpmActual = tiempo > 5 ? Math.round((reps/tiempo)*60) : 0;
  const isCuerda  = tipo === 'cuerda';

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <LinearGradient colors={['#050A15','#0A1020']} style={s.bg}>
        <View style={[s.header, { paddingTop: insets.top + 8 }]}>
          <Text style={s.title}>Ejercicios</Text>
          <Text style={s.subtitle}>CONTADOR CON SENSOR</Text>
          <View style={s.divider} />
        </View>

        <ScrollView contentContainerStyle={[s.scroll, { paddingBottom: insets.bottom+16 }]} showsVerticalScrollIndicator={false}>

          {estado === 'listo' && (
            <View style={s.tipoRow}>
              {(['cuerda','trote'] as TipoEjercicio[]).map(k => (
                <TouchableOpacity key={k} style={[s.tipoCard, tipo===k && s.tipoCardActive]}
                  onPress={() => setTipo(k)} activeOpacity={0.8}>
                  <Text style={s.tipoEmoji}>{k==='cuerda'?'🪢':'🏃'}</Text>
                  <Text style={[s.tipoNombre, tipo===k && {color:'#00C8FF'}]}>
                    {k==='cuerda'?'Salto de Cuerda':'Trote en Lugar'}
                  </Text>
                  <Text style={s.tipoDesc}>
                    {k==='cuerda'?'Detecta cada salto':'Detecta cada paso de trote'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {estado !== 'listo' && (
            <View style={s.tipoActivoBadge}>
              <Text style={s.tipoActivoEmoji}>{isCuerda?'🪢':'🏃'}</Text>
              <Text style={s.tipoActivoNombre}>{isCuerda?'Salto de Cuerda':'Trote en Lugar'}</Text>
            </View>
          )}

          <View style={s.contadorWrap}>
            <LinearGradient colors={['rgba(0,200,255,0.18)','rgba(0,200,255,0.04)']} style={s.contadorCirculo}>
              <Text style={s.contadorNum}>{reps}</Text>
              <Text style={s.contadorLbl}>{isCuerda?'SALTOS':'PASOS'}</Text>
            </LinearGradient>
          </View>

          <View style={s.statsRow}>
            {[
              { v: formatTiempo(tiempo), l: 'TIEMPO' },
              { v: String(rpmActual),    l: isCuerda?'SALTOS/MIN':'PASOS/MIN' },
              { v: String(calActual),    l: 'KCAL' },
            ].map((item, i) => (
              <View key={i} style={s.statCard}>
                <Text style={s.statVal}>{item.v}</Text>
                <Text style={s.statLbl}>{item.l}</Text>
              </View>
            ))}
          </View>

          {estado === 'corriendo' && (
            <View style={s.accelWrap}>
              <View style={s.accelRow}>
                <Text style={s.accelLabel}>● Sensor activo</Text>
                <Text style={s.accelVal}>{accelMag.toFixed(2)}g</Text>
              </View>
              <View style={s.accelBar}>
                <View style={[s.accelFill, { width: `${Math.min(100,(accelMag/3)*100)}%` }]} />
              </View>
              <Text style={s.accelHint}>
                {isCuerda?'🪢 Sostén el teléfono en la mano mientras saltas':'🏃 Lleva el teléfono en el bolsillo mientras trotas'}
              </Text>
            </View>
          )}

          <View style={s.controlesWrap}>
            {estado==='listo' && (
              <TouchableOpacity style={s.btnIniciar} onPress={iniciar} activeOpacity={0.85}>
                <LinearGradient colors={['rgba(76,217,100,0.4)','rgba(76,217,100,0.1)']} style={s.btnGrad}>
                  <Text style={s.btnText}>▶ INICIAR</Text>
                </LinearGradient>
              </TouchableOpacity>
            )}
            {(estado==='corriendo'||estado==='pausado') && (
              <View style={s.btnRow}>
                {estado==='corriendo'
                  ? <TouchableOpacity style={[s.btn, s.btnPausa]} onPress={pausar}><Text style={s.btnTxt}>⏸ PAUSAR</Text></TouchableOpacity>
                  : <TouchableOpacity style={[s.btn, s.btnReanudar]} onPress={reanudar}><Text style={s.btnTxt}>▶ REANUDAR</Text></TouchableOpacity>
                }
                <TouchableOpacity style={[s.btn, s.btnStop]} onPress={terminar}><Text style={s.btnTxt}>⏹ TERMINAR</Text></TouchableOpacity>
              </View>
            )}
            {estado==='terminado' && (
              <View style={s.resultadoWrap}>
                <Text style={s.resultadoTitle}>¡Sesión completada! 🎉</Text>
                <View style={s.resultadoStats}>
                  <Text style={s.resStat}>{isCuerda?'🪢':'🏃'} {reps} {isCuerda?'saltos':'pasos'}</Text>
                  <Text style={s.resStat}>⏱️ {formatTiempo(tiempo)}</Text>
                  <Text style={s.resStat}>🔥 {calActual} kcal</Text>
                </View>
                <TouchableOpacity style={s.btnNueva} onPress={reset}>
                  <Text style={s.btnNuevaTxt}>+ NUEVA SESIÓN</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          {historial.length > 0 && (
            <>
              <Text style={s.histTitle}>HISTORIAL</Text>
              {historial.map((h,i) => (
                <View key={i} style={s.histCard}>
                  <View style={s.histRow}>
                    <Text style={s.histEmoji}>{h.tipo==='cuerda'?'🪢':'🏃'}</Text>
                    <Text style={s.histTipo}>{h.tipo==='cuerda'?'Salto de Cuerda':'Trote en Lugar'}</Text>
                    <Text style={s.histFecha}>{h.fecha}</Text>
                  </View>
                  <View style={s.histStats}>
                    <Text style={s.histStat}>{h.repeticiones} {h.tipo==='cuerda'?'saltos':'pasos'}</Text>
                    <Text style={s.histStat}>{formatTiempo(h.tiempoSeg)}</Text>
                    <Text style={s.histStat}>🔥 {h.calorias} kcal</Text>
                  </View>
                </View>
              ))}
            </>
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}

const s = StyleSheet.create({
  root:{flex:1,backgroundColor:'#050A15'}, bg:{flex:1},
  header:{paddingHorizontal:18,paddingBottom:0},
  title:{fontFamily:'DaysOne_400Regular',fontSize:20,color:'#fff',textAlign:'center'},
  subtitle:{fontFamily:'DaysOne_400Regular',fontSize:10,color:'rgba(0,200,255,0.7)',textAlign:'center',letterSpacing:2,marginTop:2},
  divider:{height:1,backgroundColor:'rgba(255,255,255,0.12)',marginTop:8,marginBottom:2},
  scroll:{paddingHorizontal:16},
  tipoRow:{flexDirection:'row',gap:10,marginVertical:12},
  tipoCard:{flex:1,backgroundColor:'rgba(255,255,255,0.05)',borderRadius:16,borderWidth:1,borderColor:'rgba(255,255,255,0.1)',padding:14,alignItems:'center',gap:6},
  tipoCardActive:{backgroundColor:'rgba(0,200,255,0.1)',borderColor:'rgba(0,200,255,0.4)'},
  tipoEmoji:{fontSize:30},
  tipoNombre:{fontFamily:'DaysOne_400Regular',fontSize:12,color:'#fff',textAlign:'center'},
  tipoDesc:{fontFamily:'DaysOne_400Regular',fontSize:9,color:'rgba(255,255,255,0.4)',textAlign:'center',lineHeight:13},
  tipoActivoBadge:{flexDirection:'row',alignItems:'center',justifyContent:'center',gap:10,marginVertical:10,backgroundColor:'rgba(0,200,255,0.08)',borderRadius:12,borderWidth:1,borderColor:'rgba(0,200,255,0.25)',padding:10},
  tipoActivoEmoji:{fontSize:22},
  tipoActivoNombre:{fontFamily:'DaysOne_400Regular',fontSize:14,color:'#00C8FF'},
  contadorWrap:{alignItems:'center',marginVertical:8},
  contadorCirculo:{width:180,height:180,borderRadius:90,justifyContent:'center',alignItems:'center',borderWidth:2,borderColor:'rgba(0,200,255,0.4)',shadowColor:'#00C8FF',shadowOffset:{width:0,height:0},shadowOpacity:0.5,shadowRadius:20},
  contadorNum:{fontFamily:'DaysOne_400Regular',fontSize:68,color:'#fff',lineHeight:76},
  contadorLbl:{fontFamily:'DaysOne_400Regular',fontSize:11,color:'rgba(0,200,255,0.7)',letterSpacing:2},
  statsRow:{flexDirection:'row',gap:8,marginBottom:10},
  statCard:{flex:1,backgroundColor:'rgba(255,255,255,0.05)',borderRadius:12,borderWidth:1,borderColor:'rgba(255,255,255,0.1)',padding:10,alignItems:'center'},
  statVal:{fontFamily:'DaysOne_400Regular',fontSize:17,color:'#fff'},
  statLbl:{fontFamily:'DaysOne_400Regular',fontSize:8,color:'rgba(255,255,255,0.4)',letterSpacing:1,marginTop:2},
  accelWrap:{marginBottom:10,gap:5},
  accelRow:{flexDirection:'row',justifyContent:'space-between'},
  accelLabel:{fontFamily:'DaysOne_400Regular',fontSize:10,color:'#4CD964'},
  accelVal:{fontFamily:'DaysOne_400Regular',fontSize:10,color:'rgba(255,255,255,0.4)'},
  accelBar:{height:5,backgroundColor:'rgba(255,255,255,0.1)',borderRadius:3,overflow:'hidden'},
  accelFill:{height:'100%',backgroundColor:'#4CD964',borderRadius:3},
  accelHint:{fontFamily:'DaysOne_400Regular',fontSize:9,color:'rgba(255,255,255,0.35)',textAlign:'center'},
  controlesWrap:{marginBottom:14},
  btnIniciar:{borderRadius:14,overflow:'hidden'},
  btnGrad:{height:52,justifyContent:'center',alignItems:'center',borderWidth:1,borderColor:'rgba(76,217,100,0.5)',borderRadius:14},
  btnText:{fontFamily:'DaysOne_400Regular',fontSize:18,color:'#fff',letterSpacing:2},
  btnRow:{flexDirection:'row',gap:10},
  btn:{flex:1,height:48,borderRadius:12,justifyContent:'center',alignItems:'center',borderWidth:1},
  btnPausa:{backgroundColor:'rgba(255,165,0,0.18)',borderColor:'rgba(255,165,0,0.5)'},
  btnStop:{backgroundColor:'rgba(255,59,48,0.18)',borderColor:'rgba(255,59,48,0.5)'},
  btnReanudar:{backgroundColor:'rgba(76,217,100,0.18)',borderColor:'rgba(76,217,100,0.5)'},
  btnTxt:{fontFamily:'DaysOne_400Regular',fontSize:13,color:'#fff',letterSpacing:1},
  resultadoWrap:{backgroundColor:'rgba(0,200,255,0.07)',borderRadius:16,borderWidth:1,borderColor:'rgba(0,200,255,0.25)',padding:16,alignItems:'center',gap:10},
  resultadoTitle:{fontFamily:'DaysOne_400Regular',fontSize:16,color:'#fff'},
  resultadoStats:{flexDirection:'row',gap:14,flexWrap:'wrap',justifyContent:'center'},
  resStat:{fontFamily:'DaysOne_400Regular',fontSize:12,color:'rgba(255,255,255,0.8)'},
  btnNueva:{height:42,paddingHorizontal:22,borderRadius:12,justifyContent:'center',alignItems:'center',backgroundColor:'rgba(0,200,255,0.18)',borderWidth:1,borderColor:'rgba(0,200,255,0.4)'},
  btnNuevaTxt:{fontFamily:'DaysOne_400Regular',fontSize:13,color:'#00C8FF',letterSpacing:1.5},
  histTitle:{fontFamily:'DaysOne_400Regular',fontSize:10,color:'rgba(0,200,255,0.7)',letterSpacing:2,marginBottom:8,marginTop:4},
  histCard:{backgroundColor:'rgba(255,255,255,0.04)',borderRadius:12,borderWidth:1,borderColor:'rgba(255,255,255,0.08)',padding:12,marginBottom:8},
  histRow:{flexDirection:'row',alignItems:'center',gap:8,marginBottom:6},
  histEmoji:{fontSize:16},
  histTipo:{fontFamily:'DaysOne_400Regular',fontSize:12,color:'#fff',flex:1},
  histFecha:{fontFamily:'DaysOne_400Regular',fontSize:9,color:'rgba(255,255,255,0.3)'},
  histStats:{flexDirection:'row',gap:12},
  histStat:{fontFamily:'DaysOne_400Regular',fontSize:11,color:'rgba(255,255,255,0.6)'},
});

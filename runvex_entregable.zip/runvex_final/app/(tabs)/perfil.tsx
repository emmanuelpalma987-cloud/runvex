import React, { useState, useCallback, useEffect } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, StatusBar,
  ScrollView, TextInput, TouchableOpacity, Alert, Image, Switch,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../src/hooks/useAuth';
import ScreenWrapper from '../../src/components/ScreenWrapper';
import { actualizarUsuario, obtenerCarrerasDelMes } from '../../src/database/database';
import {
  getBioInfo, autenticarBiometria, guardarCredencialBio,
  eliminarCredencialBio, hayCredencialBio, BioInfo,
} from '../../src/hooks/useBiometrics';
import { useRouter, useFocusEffect } from 'expo-router';

const MONTHS = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];
const DAYS   = ['L','M','X','J','V','S','D'];

export default function PerfilScreen() {
  const insets = useSafeAreaInsets();
  const { usuario, setUsuario, logout } = useAuth();
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    nombre:    usuario?.nombre    ?? '',
    apellidos: usuario?.apellidos ?? '',
    correo:    usuario?.correo    ?? '',
  });
  const [foto, setFoto]       = useState<string | null>(usuario?.foto_perfil ?? null);
  const [diasCarrera, setDiasCarrera] = useState<Set<number>>(new Set());
  const [calMonth, setCalMonth]       = useState(new Date());
  const [bioInfo, setBioInfo]         = useState<BioInfo>({ disponible: false, inscrita: false, tipo: 'none' });
  const [bioActiva, setBioActiva]     = useState(false);
  const [bioLoading, setBioLoading]   = useState(false);

  useEffect(() => {
    (async () => {
      const info = await getBioInfo();
      setBioInfo(info);
      if (info.disponible) {
        const hay = await hayCredencialBio();
        setBioActiva(hay && !!(usuario as any)?.bio_habilitada);
      }
    })();
  }, [usuario]);

  useFocusEffect(useCallback(() => {
    loadCalendar();
  }, [usuario, calMonth]));

  const loadCalendar = async () => {
    if (!usuario?.id) return;
    const year  = calMonth.getFullYear();
    const month = calMonth.getMonth() + 1;
    const dias  = await obtenerCarrerasDelMes(usuario.id, year, month).catch(() => []);
    setDiasCarrera(new Set(dias));
  };

  const pickPhoto = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permiso requerido', 'Necesitamos acceso a tu galería.'); return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true, aspect: [1, 1], quality: 0.7,
    });
    if (!result.canceled && result.assets[0]) {
      const uri = result.assets[0].uri;
      setFoto(uri);
      if (usuario?.id) {
        await actualizarUsuario(usuario.id, { foto_perfil: uri });
        setUsuario({ ...usuario!, foto_perfil: uri });
      }
    }
  };

  const handleGuardar = async () => {
    if (!usuario?.id) return;
    if (!form.nombre.trim() || !form.apellidos.trim() || !form.correo.trim()) {
      Alert.alert('Campos requeridos', 'Nombre, apellidos y correo son obligatorios.'); return;
    }
    try {
      await actualizarUsuario(usuario.id, form);
      setUsuario({ ...usuario!, ...form });
      setEditing(false);
      Alert.alert('✅ Guardado', 'Perfil actualizado correctamente.');
    } catch (e: any) {
      Alert.alert('Error', e.message ?? 'No se pudo actualizar.');
    }
  };

  const handleToggleBio = async (val: boolean) => {
    if (!bioInfo.disponible) {
      Alert.alert('Sin biometría', 'Tu dispositivo no tiene biometría configurada.'); return;
    }
    setBioLoading(true);
    try {
      if (val) {
        // Habilitar: autenticar primero
        const ok = await autenticarBiometria('Habilita biometría para Runvex');
        if (!ok) { setBioLoading(false); return; }
        // Guardar referencia en SecureStore
        await guardarCredencialBio(usuario!.usuario);
        await actualizarUsuario(usuario!.id, { bio_habilitada: 1, bio_usuario_ref: usuario!.usuario });
        setUsuario({ ...usuario!, bio_habilitada: 1, bio_usuario_ref: usuario!.usuario } as any);
        setBioActiva(true);
        Alert.alert('✅ Biometría habilitada', `Ahora puedes acceder con ${bioInfo.tipo === 'face' ? 'Face ID' : 'huella digital'}.`);
      } else {
        // Deshabilitar
        await eliminarCredencialBio();
        await actualizarUsuario(usuario!.id, { bio_habilitada: 0, bio_usuario_ref: '' });
        setUsuario({ ...usuario!, bio_habilitada: 0, bio_usuario_ref: '' } as any);
        setBioActiva(false);
        Alert.alert('Biometría desactivada', 'Deberás iniciar sesión con contraseña.');
      }
    } finally {
      setBioLoading(false);
    }
  };

  const handleLogout = () => {
    Alert.alert('Cerrar sesión', '¿Estás seguro?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Salir', style: 'destructive', onPress: async () => {
        await logout(); router.replace('/auth');
      }},
    ]);
  };

  // Calendar
  const today = new Date();
  const year  = calMonth.getFullYear();
  const month = calMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = new Date(year, month, 1).getDay();
  const offset   = firstDay === 0 ? 6 : firstDay - 1;
  const calDays: (number | null)[] = [];
  for (let i = 0; i < offset; i++) calDays.push(null);
  for (let d = 1; d <= daysInMonth; d++) calDays.push(d);

  const isToday = (d: number) =>
    d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
  const isPast = (d: number) =>
    new Date(year, month, d) < new Date(today.getFullYear(), today.getMonth(), today.getDate());

  const getDayBg = (day: number | null): string => {
    if (!day) return 'transparent';
    if (isToday(day)) return 'rgba(0,200,255,0.28)';
    if (!isPast(day)) return 'rgba(255,255,255,0.03)';
    return diasCarrera.has(day) ? 'rgba(76,217,100,0.25)' : 'rgba(255,59,48,0.2)';
  };
  const getDotColor = (day: number | null): string => {
    if (!day || !isPast(day)) return 'transparent';
    return diasCarrera.has(day) ? '#4CD964' : '#FF3B30';
  };

  const initials = (usuario?.nombre?.[0] ?? 'R').toUpperCase();

  return (
    <ScreenWrapper>
          <Text style={[s.title, { paddingTop: insets.top + 8 }]}>Perfil</Text>
          <View style={s.divider} />

          <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>

            {/* Avatar */}
            <View style={s.avatarSection}>
              <TouchableOpacity onPress={pickPhoto} activeOpacity={0.85}>
                <LinearGradient
                  colors={['#00C8FF', '#FF6A00', '#00C8FF']}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                  style={s.avatarRing}
                >
                  <View style={s.avatarInner}>
                    {foto
                      ? <Image source={{ uri: foto }} style={s.avatarImg} />
                      : <Text style={s.avatarInitial}>{initials}</Text>
                    }
                  </View>
                </LinearGradient>
                <View style={s.cameraBtn}><Text style={s.cameraIcon}>📷</Text></View>
              </TouchableOpacity>
              <Text style={s.avatarName}>{usuario?.nombre} {usuario?.apellidos}</Text>
              <Text style={s.avatarUser}>@{usuario?.usuario}</Text>
            </View>

            {/* Racha */}
            <View style={s.rachaRow}>
              <Text style={s.rachaEmoji}>🔥</Text>
              <Text style={s.rachaText}>{usuario?.racha ?? 0} días de racha</Text>
            </View>

            {/* Campos de perfil */}
            <View style={s.fieldsCard}>
              {([
                { label:'NOMBRE',    key:'nombre'    as const, editable:true, cap:'words'         as const },
                { label:'APELLIDOS', key:'apellidos' as const, editable:true, cap:'words'         as const },
                { label:'CORREO',    key:'correo'    as const, editable:true, kb:'email-address'  as const },
              ]).map((f, i) => (
                <View key={i} style={[s.fieldRow, i > 0 && s.fieldBorder]}>
                  <Text style={s.fieldLabel}>{f.label}:</Text>
                  {editing ? (
                    <TextInput
                      style={s.fieldInput}
                      value={form[f.key]}
                      onChangeText={v => setForm(p => ({ ...p, [f.key]: v }))}
                      autoCapitalize={f.cap}
                      keyboardType={f.kb}
                      autoCorrect={false}
                      maxLength={80}
                      placeholderTextColor="rgba(255,255,255,0.3)"
                    />
                  ) : (
                    <Text style={s.fieldValue}>{form[f.key] || '—'}</Text>
                  )}
                </View>
              ))}
              <View style={[s.fieldRow, s.fieldBorder]}>
                <Text style={s.fieldLabel}>USUARIO:</Text>
                <Text style={s.fieldValue}>{usuario?.usuario ?? '—'}</Text>
              </View>
              <View style={[s.fieldRow, s.fieldBorder]}>
                <Text style={s.fieldLabel}>CONTRASEÑA:</Text>
                <Text style={s.fieldValue}>••••••••</Text>
              </View>
            </View>

            {/* Biometría */}
            {bioInfo.disponible && (
              <View style={s.bioCard}>
                <View style={s.bioLeft}>
                  <Text style={s.bioEmoji}>{bioInfo.tipo === 'face' ? '😊' : '👆'}</Text>
                  <View>
                    <Text style={s.bioTitle}>{bioInfo.tipo === 'face' ? 'Face ID' : 'Huella Digital'}</Text>
                    <Text style={s.bioSub}>
                      {bioActiva ? '✅ Habilitada — acceso rápido activo' : 'Inicia sesión más rápido'}
                    </Text>
                  </View>
                </View>
                <Switch
                  value={bioActiva}
                  onValueChange={handleToggleBio}
                  disabled={bioLoading}
                  trackColor={{ false: 'rgba(255,255,255,0.15)', true: 'rgba(0,200,255,0.5)' }}
                  thumbColor={bioActiva ? '#00C8FF' : 'rgba(255,255,255,0.6)'}
                />
              </View>
            )}

            {/* Botones */}
            <View style={s.btnWrap}>
              {editing ? (
                <>
                  <TouchableOpacity style={s.btnCyan} onPress={handleGuardar} activeOpacity={0.85}>
                    <Text style={s.btnText}>GUARDAR CAMBIOS</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={s.btnOutline} onPress={() => setEditing(false)} activeOpacity={0.85}>
                    <Text style={s.btnTextGray}>CANCELAR</Text>
                  </TouchableOpacity>
                </>
              ) : (
                <TouchableOpacity style={s.btnCyan} onPress={() => setEditing(true)} activeOpacity={0.85}>
                  <Text style={s.btnText}>EDITAR PERFIL</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity style={s.btnDanger} onPress={handleLogout} activeOpacity={0.85}>
                <Text style={s.btnText}>CERRAR SESIÓN</Text>
              </TouchableOpacity>
            </View>

            <View style={s.divider} />

            {/* Calendario */}
            <View style={s.calCard}>
              <View style={s.calHeader}>
                <TouchableOpacity
                  onPress={() => setCalMonth(d => new Date(d.getFullYear(), d.getMonth() - 1, 1))}
                  hitSlop={{ top:10, bottom:10, left:10, right:10 }}
                >
                  <Text style={s.calNav}>‹</Text>
                </TouchableOpacity>
                <Text style={s.calTitle}>{MONTHS[month]} {year}</Text>
                <TouchableOpacity
                  onPress={() => setCalMonth(d => new Date(d.getFullYear(), d.getMonth() + 1, 1))}
                  hitSlop={{ top:10, bottom:10, left:10, right:10 }}
                >
                  <Text style={s.calNav}>›</Text>
                </TouchableOpacity>
              </View>

              <View style={s.calDaysHeader}>
                {DAYS.map(d => <Text key={d} style={s.calDayName}>{d}</Text>)}
              </View>

              <View style={s.calGrid}>
                {calDays.map((day, i) => (
                  <View key={i} style={[s.calDay, { backgroundColor: getDayBg(day) }]}>
                    <Text style={[
                      s.calNum,
                      !day && { opacity: 0 },
                      day && isToday(day) && s.calToday,
                    ]}>
                      {day ?? ' '}
                    </Text>
                    {day && <View style={[s.calDot, { backgroundColor: getDotColor(day) }]} />}
                  </View>
                ))}
              </View>

              <View style={s.legend}>
                {[
                  ['#4CD964', 'Corriste'],
                  ['rgba(0,200,255,0.7)', 'Hoy'],
                  ['#FF3B30', 'Sin carrera'],
                  ['rgba(255,255,255,0.1)', 'Futuro'],
                ].map(([c, l]) => (
                  <View key={l} style={s.legendItem}>
                    <View style={[s.legendDot, { backgroundColor: c }]} />
                    <Text style={s.legendText}>{l}</Text>
                  </View>
                ))}
              </View>
            </View>

          </ScrollView>
</ScreenWrapper>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  bg: { flex: 1 },
  safe: { flex: 1 },
  title: { fontFamily: 'DaysOne_400Regular', fontSize: 22, color: '#fff', textAlign: 'center', paddingTop: 0 },
  divider: { height: 1, backgroundColor: 'rgba(255,255,255,0.12)', marginHorizontal: 18, marginVertical: 10 },
  scroll: { paddingHorizontal: 16, paddingBottom: 40 },

  avatarSection: { alignItems: 'center', marginBottom: 14, marginTop: 4 },
  avatarRing: {
    width: 130, height: 130, borderRadius: 65, padding: 3,
    shadowColor: '#00C8FF', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.8, shadowRadius: 20,
  },
  avatarInner: {
    flex: 1, borderRadius: 63, backgroundColor: 'rgba(0,10,30,0.9)',
    justifyContent: 'center', alignItems: 'center', overflow: 'hidden',
  },
  avatarImg: { width: '100%', height: '100%', borderRadius: 63 },
  avatarInitial: { fontFamily: 'Audiowide_400Regular', fontSize: 48, color: '#00C8FF' },
  cameraBtn: {
    position: 'absolute', bottom: 0, right: 0, width: 32, height: 32, borderRadius: 16,
    backgroundColor: '#050A15', borderWidth: 1, borderColor: 'rgba(0,200,255,0.4)',
    justifyContent: 'center', alignItems: 'center',
  },
  cameraIcon: { fontSize: 15 },
  avatarName: { fontFamily: 'DaysOne_400Regular', fontSize: 17, color: '#fff', marginTop: 10 },
  avatarUser: { fontFamily: 'DaysOne_400Regular', fontSize: 12, color: 'rgba(0,200,255,0.7)', marginTop: 3 },

  rachaRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    marginBottom: 12, backgroundColor: 'rgba(255,255,255,0.04)',
    borderRadius: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', padding: 12,
  },
  rachaEmoji: { fontSize: 22 },
  rachaText: { fontFamily: 'DaysOne_400Regular', fontSize: 16, color: '#fff' },

  fieldsCard: {
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', marginBottom: 12, overflow: 'hidden',
  },
  fieldRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingVertical: 12 },
  fieldBorder: { borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.07)' },
  fieldLabel: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(0,200,255,0.7)', minWidth: 95, letterSpacing: 1 },
  fieldValue: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff', flex: 1, textAlign: 'right' },
  fieldInput: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#00C8FF', flex: 1, textAlign: 'right' },

  bioCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: 'rgba(0,200,255,0.07)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.25)', padding: 14, marginBottom: 12,
  },
  bioLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  bioEmoji: { fontSize: 28 },
  bioTitle: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff' },
  bioSub: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.45)', marginTop: 2 },

  btnWrap: { gap: 10, marginBottom: 8 },
  btnCyan: {
    height: 48, borderRadius: 12, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(0,200,255,0.18)', borderWidth: 1, borderColor: 'rgba(0,200,255,0.45)',
  },
  btnOutline: {
    height: 48, borderRadius: 12, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.04)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)',
  },
  btnDanger: {
    height: 48, borderRadius: 12, justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(255,59,48,0.15)', borderWidth: 1, borderColor: 'rgba(255,59,48,0.45)',
  },
  btnText: { fontFamily: 'DaysOne_400Regular', fontSize: 15, color: '#fff', letterSpacing: 1.5 },
  btnTextGray: { fontFamily: 'DaysOne_400Regular', fontSize: 15, color: 'rgba(255,255,255,0.5)', letterSpacing: 1.5 },

  // Calendar
  calCard: {
    backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: 16,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', padding: 12,
  },
  calHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  calNav: { fontFamily: 'DaysOne_400Regular', fontSize: 26, color: '#00C8FF', paddingHorizontal: 6 },
  calTitle: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff' },
  calDaysHeader: { flexDirection: 'row', marginBottom: 4 },
  calDayName: { flex: 1, textAlign: 'center', fontFamily: 'DaysOne_400Regular', fontSize: 9, color: 'rgba(255,255,255,0.35)' },
  calGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  calDay: {
    width: `${100 / 7}%`, aspectRatio: 1,
    alignItems: 'center', justifyContent: 'center', borderRadius: 8, marginVertical: 1,
  },
  calNum: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.75)' },
  calToday: { color: '#00C8FF', fontFamily: 'DaysOne_400Regular' },
  calDot: { width: 4, height: 4, borderRadius: 2, marginTop: 1 },

  legend: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 10, marginTop: 10 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendText: { fontFamily: 'DaysOne_400Regular', fontSize: 9, color: 'rgba(255,255,255,0.4)' },
});

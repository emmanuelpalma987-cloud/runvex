import { Tabs } from 'expo-router';
import { View, StyleSheet, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const ICONS = {
  home:       require('../../src/assets/icons/home.png'),
  rutas:      require('../../src/assets/icons/rutas.png'),
  carrera:    require('../../src/assets/icons/carrera.png'),
  ejercicios: require('../../src/assets/icons/ejercicios.png'),
  resultados: require('../../src/assets/icons/resultados.png'),
  perfil:     require('../../src/assets/icons/perfil.png'),
};

function TabIcon({ name, focused }: { name: keyof typeof ICONS; focused: boolean }) {
  return (
    <View style={[t.wrap, focused && t.active]}>
      <Image
        source={ICONS[name]}
        style={[t.img, focused ? t.imgActive : t.imgInactive]}
        resizeMode="contain"
      />
      {focused && <View style={t.dot} />}
    </View>
  );
}

const t = StyleSheet.create({
  wrap: {
    width: 46, height: 40, alignItems: 'center', justifyContent: 'center', borderRadius: 12,
  },
  active: {
    backgroundColor: 'rgba(0,200,255,0.12)',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.3)',
  },
  img: { width: 26, height: 26 },
  imgActive:   { tintColor: '#00C8FF' },
  imgInactive: { tintColor: 'rgba(255,255,255,0.45)' },
  dot: {
    position: 'absolute', bottom: 1, width: 4, height: 4,
    borderRadius: 2, backgroundColor: '#00C8FF',
  },
});

export default function TabsLayout() {
  const insets = useSafeAreaInsets();
  const tabBarH = 56 + insets.bottom;

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#050A15',
          borderTopColor: 'rgba(0,200,255,0.2)',
          borderTopWidth: 1,
          height: tabBarH,
          paddingBottom: insets.bottom + 4,
          paddingTop: 4,
        },
        tabBarLabelStyle: {
          fontFamily: 'DaysOne_400Regular',
          fontSize: 8,
          letterSpacing: 0.3,
        },
        tabBarActiveTintColor: '#00C8FF',
        tabBarInactiveTintColor: 'rgba(255,255,255,0.35)',
      }}
    >
      <Tabs.Screen name="home"
        options={{ title: 'INICIO',    tabBarIcon: ({ focused }) => <TabIcon name="home"       focused={focused} /> }} />
      <Tabs.Screen name="rutas"
        options={{ title: 'RUTAS',     tabBarIcon: ({ focused }) => <TabIcon name="rutas"      focused={focused} /> }} />
      <Tabs.Screen name="carrera"
        options={{ title: 'CARRERA',   tabBarIcon: ({ focused }) => <TabIcon name="carrera"    focused={focused} /> }} />
      <Tabs.Screen name="ejercicios"
        options={{ title: 'EJERC.',    tabBarIcon: ({ focused }) => <TabIcon name="ejercicios" focused={focused} /> }} />
      <Tabs.Screen name="resultados"
        options={{ title: 'STATS',     tabBarIcon: ({ focused }) => <TabIcon name="resultados" focused={focused} /> }} />
      <Tabs.Screen name="perfil"
        options={{ title: 'PERFIL',    tabBarIcon: ({ focused }) => <TabIcon name="perfil"     focused={focused} /> }} />
    </Tabs>
  );
}

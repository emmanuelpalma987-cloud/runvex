import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, StatusBar,
  ScrollView, TouchableOpacity, Dimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from 'expo-router';
import MapView, { Polyline, Marker, PROVIDER_DEFAULT } from 'react-native-maps';
import { useAuth } from '../../src/hooks/useAuth';
import ScreenWrapper from '../../src/components/ScreenWrapper';
import { obtenerUltimaCarrera, obtenerCarreras } from '../../src/database/database';

const { width: W } = Dimensions.get('window');

// ─── Formatters ───────────────────────────────────────────────────────────────
const fmtTime = (s: number) => {
  const m = Math.floor(s / 60), sec = s % 60;
  return `${String(m).padStart(2, '0')}m ${String(sec).padStart(2, '0')}s`;
};
const fmtPace = (dist: number, seg: number) => {
  if (!dist) return '--:--';
  const p = seg / dist;
  return `${Math.floor(p / 60)}:${String(Math.floor(p % 60)).padStart(2, '0')} /km`;
};
const fmtDate = (d: string) => {
  const dt = new Date(d);
  return `${dt.getDate()}/${dt.getMonth() + 1}/${dt.getFullYear()} ${String(dt.getHours()).padStart(2,'0')}:${String(dt.getMinutes()).padStart(2,'0')}`;
};

// ─── Stat Card ────────────────────────────────────────────────────────────────
function StatCard({ icon, value, label, accent = '#00C8FF' }: {
  icon: string; value: string; label: string; accent?: string;
}) {
  return (
    <View style={[sc.wrap, { borderColor: `${accent}44` }]}>
      <View style={[sc.iconBg, { backgroundColor: `${accent}18` }]}>
        <Text style={sc.icon}>{icon}</Text>
      </View>
      <Text style={sc.val}>{value}</Text>
      <Text style={sc.lbl}>{label}</Text>
    </View>
  );
}
const sc = StyleSheet.create({
  wrap: {
    width: '47%', backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 14, borderWidth: 1, padding: 12, alignItems: 'center', gap: 4,
  },
  iconBg: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
  icon: { fontSize: 20 },
  val: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff', textAlign: 'center' },
  lbl: { fontFamily: 'DaysOne_400Regular', fontSize: 9, color: 'rgba(255,255,255,0.4)', textAlign: 'center' },
});

// ─── Bar Chart ────────────────────────────────────────────────────────────────
function BarChart({ data, labels, color, unit }: {
  data: number[]; labels: string[]; color: string; unit: string;
}) {
  if (!data.length) return null;
  const max = Math.max(...data, 0.01);
  const BAR_W = Math.max(14, (W - 96) / data.length - 6);
  return (
    <View style={ch.wrap}>
      <View style={ch.bars}>
        {data.map((v, i) => (
          <View key={i} style={ch.col}>
            <Text style={ch.val}>{v > 0 ? v.toFixed(1) : ''}</Text>
            <View style={ch.track}>
              <LinearGradient
                colors={[color, `${color}44`]}
                style={[ch.bar, { height: `${Math.max(4, (v / max) * 100)}%`, width: BAR_W }]}
              />
            </View>
            <Text style={ch.lbl}>{labels[i]}</Text>
          </View>
        ))}
      </View>
      <Text style={ch.unit}>{unit}</Text>
    </View>
  );
}
const ch = StyleSheet.create({
  wrap: { paddingVertical: 6 },
  bars: { flexDirection: 'row', alignItems: 'flex-end', height: 80, gap: 3, paddingHorizontal: 2 },
  col: { alignItems: 'center', flex: 1 },
  val: { fontFamily: 'DaysOne_400Regular', fontSize: 7, color: 'rgba(255,255,255,0.5)', marginBottom: 1 },
  track: { height: 60, justifyContent: 'flex-end', alignItems: 'center' },
  bar: { borderRadius: 4 },
  lbl: { fontFamily: 'DaysOne_400Regular', fontSize: 7, color: 'rgba(255,255,255,0.35)', marginTop: 2 },
  unit: { fontFamily: 'DaysOne_400Regular', fontSize: 9, color: 'rgba(255,255,255,0.25)', textAlign: 'right', paddingRight: 2 },
});

// ─── RouteMap ─────────────────────────────────────────────────────────────────
function RouteMap({ carrera }: { carrera: any }) {
  if (!carrera?.ruta_json) return null;
  let coords: { latitude: number; longitude: number }[] = [];
  try { coords = JSON.parse(carrera.ruta_json); } catch { return null; }
  if (coords.length < 2) return null;

  const lats = coords.map(c => c.latitude);
  const lons = coords.map(c => c.longitude);
  const region = {
    latitude: (Math.max(...lats) + Math.min(...lats)) / 2,
    longitude: (Math.max(...lons) + Math.min(...lons)) / 2,
    latitudeDelta: (Math.max(...lats) - Math.min(...lats)) * 1.6 + 0.003,
    longitudeDelta: (Math.max(...lons) - Math.min(...lons)) * 1.6 + 0.003,
  };
  const inicio = coords[0];
  const fin    = coords[coords.length - 1];

  return (
    <View style={rm.wrap}>
      <Text style={rm.title}>🗺️ Recorrido realizado</Text>
      <View style={rm.map}>
        <MapView
          style={{ flex: 1 }}
          provider={PROVIDER_DEFAULT}
          region={region}
          mapType="satellite"
          scrollEnabled={false}
          zoomEnabled={false}
          pitchEnabled={false}
          rotateEnabled={false}
        >
          <Polyline coordinates={coords} strokeColor="#00C8FF" strokeWidth={3} />
          <Marker coordinate={inicio} pinColor="#4CD964" />
          <Marker coordinate={fin}    pinColor="#FF3B30" />
        </MapView>
      </View>
      <View style={rm.infoRow}>
        <View style={rm.infoItem}>
          <View style={[rm.dot, { backgroundColor: '#4CD964' }]} />
          <Text style={rm.infoText}>
            Inicio: {inicio.latitude.toFixed(4)}, {inicio.longitude.toFixed(4)}
          </Text>
        </View>
        <View style={rm.infoItem}>
          <View style={[rm.dot, { backgroundColor: '#FF3B30' }]} />
          <Text style={rm.infoText}>
            Fin: {fin.latitude.toFixed(4)}, {fin.longitude.toFixed(4)}
          </Text>
        </View>
      </View>
    </View>
  );
}
const rm = StyleSheet.create({
  wrap: {
    backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: 16,
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.2)', overflow: 'hidden', marginBottom: 12,
  },
  title: {
    fontFamily: 'DaysOne_400Regular', fontSize: 12, color: 'rgba(0,200,255,0.8)',
    padding: 10, paddingBottom: 8,
  },
  map: { height: 180, marginHorizontal: 10, borderRadius: 12, overflow: 'hidden' },
  infoRow: { padding: 10, gap: 4 },
  infoItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  infoText: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.55)' },
});

// ─── Main Screen ──────────────────────────────────────────────────────────────
type Tab = 'ultima' | 'historial' | 'graficas';

export default function ResultadosScreen() {
  const insets = useSafeAreaInsets();
  const { usuario } = useAuth();
  const [carrera, setCarrera]   = useState<any>(null);
  const [historial, setHistorial] = useState<any[]>([]);
  const [tab, setTab]           = useState<Tab>('ultima');
  const [expanded, setExpanded] = useState<number | null>(null);

  useFocusEffect(useCallback(() => {
    if (!usuario?.id) return;
    obtenerUltimaCarrera(usuario.id).then(setCarrera).catch(() => {});
    obtenerCarreras(usuario.id).then(setHistorial).catch(() => {});
  }, [usuario]));

  const last7    = historial.slice(0, 7).reverse();
  const distData = last7.map(c => parseFloat((c.distancia_km ?? 0).toFixed(2)));
  const bpmData  = last7.map(c => c.bpm_promedio ?? 0);
  const calData  = last7.map(c => c.calorias ?? 0);
  const labelsG  = last7.map((c, i) => {
    const d = new Date(c.fecha);
    return `${d.getDate()}/${d.getMonth()+1}`;
  });

  const TABS: { key: Tab; label: string }[] = [
    { key: 'ultima',    label: '🏃 Última' },
    { key: 'historial', label: '📋 Historial' },
    { key: 'graficas',  label: '📊 Gráficas' },
  ];

  return (
    <ScreenWrapper>
          <Text style={[s.title, { paddingTop: insets.top + 8 }]}>Resultados</Text>
          <View style={s.divider} />

          <View style={s.tabRow}>
            {TABS.map(t => (
              <TouchableOpacity
                key={t.key}
                style={[s.tabBtn, tab === t.key && s.tabActive]}
                onPress={() => setTab(t.key)}
              >
                <Text style={[s.tabText, tab === t.key && s.tabTextActive]}>{t.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>

            {/* ── ÚLTIMA CARRERA ── */}
            {tab === 'ultima' && (
              carrera ? (
                <>
                  <Text style={s.dateLabel}>{fmtDate(carrera.fecha)}</Text>

                  {/* Mapa del recorrido */}
                  <RouteMap carrera={carrera} />

                  {/* Stats */}
                  <View style={s.grid}>
                    <StatCard icon="🏃" value={`${carrera.distancia_km?.toFixed(2)} km`}  label="Distancia"    accent="#00C8FF" />
                    <StatCard icon="❤️" value={`${carrera.bpm_promedio} bpm`}             label="BPM Promedio" accent="#FF3B30" />
                    <StatCard icon="⏱️" value={fmtTime(carrera.tiempo_segundos)}          label="Tiempo"       accent="#FF9500" />
                    <StatCard icon="💓" value={`${carrera.bpm_maximo} bpm`}               label="BPM Máximo"   accent="#FF3B30" />
                    <StatCard icon="🔥" value={`${carrera.calorias} kcal`}                label="Calorías"     accent="#FF6A00" />
                    <StatCard icon="👟" value={`${carrera.pasos?.toLocaleString()}`}      label="Pasos"        accent="#4CD964" />
                    <StatCard icon="⚡" value={fmtPace(carrera.distancia_km, carrera.tiempo_segundos)} label="Ritmo" accent="#FFD700" />
                    <StatCard icon="⛰️" value={`+${carrera.elevacion_m?.toFixed(0)} m`}  label="Elevación"    accent="#9B59B6" />
                  </View>
                </>
              ) : (
                <View style={s.emptyWrap}>
                  <Text style={s.emptyIcon}>🏃</Text>
                  <Text style={s.empty}>No hay carreras registradas.{'\n'}¡Inicia tu primera carrera!</Text>
                </View>
              )
            )}

            {/* ── HISTORIAL ── */}
            {tab === 'historial' && (
              historial.length > 0 ? (
                historial.map((c, i) => {
                  const isOpen = expanded === c.id;
                  let coords: any[] = [];
                  try { coords = JSON.parse(c.ruta_json ?? '[]'); } catch {}
                  return (
                    <View key={c.id}>
                      <TouchableOpacity
                        style={s.histCard}
                        onPress={() => setExpanded(isOpen ? null : c.id)}
                        activeOpacity={0.8}
                      >
                        <View style={s.histHeader}>
                          <Text style={s.histNum}>#{historial.length - i}</Text>
                          <Text style={s.histDate}>{fmtDate(c.fecha)}</Text>
                          <Text style={s.histChev}>{isOpen ? '▲' : '▼'}</Text>
                        </View>
                        <View style={s.histStats}>
                          <Text style={s.histStat}>🏃 {c.distancia_km?.toFixed(2)} km</Text>
                          <Text style={s.histStat}>⏱️ {fmtTime(c.tiempo_segundos)}</Text>
                          <Text style={s.histStat}>❤️ {c.bpm_promedio} bpm</Text>
                          <Text style={s.histStat}>🔥 {c.calorias} kcal</Text>
                        </View>
                      </TouchableOpacity>
                      {/* Expandido: mapa de la ruta */}
                      {isOpen && coords.length >= 2 && (
                        <View style={s.histMapWrap}>
                          <RouteMap carrera={c} />
                        </View>
                      )}
                    </View>
                  );
                })
              ) : (
                <View style={s.emptyWrap}>
                  <Text style={s.emptyIcon}>📋</Text>
                  <Text style={s.empty}>No hay historial aún.</Text>
                </View>
              )
            )}

            {/* ── GRÁFICAS ── */}
            {tab === 'graficas' && (
              last7.length > 0 ? (
                <View style={s.chartsWrap}>
                  <View style={s.chartCard}>
                    <Text style={s.chartTitle}>🏃 Distancia (km) — últimas {last7.length} carreras</Text>
                    <BarChart data={distData} labels={labelsG} color="#00C8FF" unit="km" />
                  </View>
                  <View style={s.chartCard}>
                    <Text style={s.chartTitle}>❤️ BPM Promedio</Text>
                    <BarChart data={bpmData} labels={labelsG} color="#FF3B30" unit="bpm" />
                  </View>
                  <View style={s.chartCard}>
                    <Text style={s.chartTitle}>🔥 Calorías (kcal)</Text>
                    <BarChart data={calData} labels={labelsG} color="#FF9500" unit="kcal" />
                  </View>
                  <View style={s.totalesCard}>
                    <Text style={s.chartTitle}>📈 Totales acumulados</Text>
                    <View style={s.totRow}>
                      <View style={s.tot}>
                        <Text style={s.totVal}>{historial.reduce((a,c)=>a+(c.distancia_km??0),0).toFixed(1)}</Text>
                        <Text style={s.totLbl}>km totales</Text>
                      </View>
                      <View style={s.tot}>
                        <Text style={s.totVal}>{historial.length}</Text>
                        <Text style={s.totLbl}>carreras</Text>
                      </View>
                      <View style={s.tot}>
                        <Text style={s.totVal}>{historial.reduce((a,c)=>a+(c.calorias??0),0).toLocaleString()}</Text>
                        <Text style={s.totLbl}>kcal</Text>
                      </View>
                      <View style={s.tot}>
                        <Text style={s.totVal}>{historial.reduce((a,c)=>a+(c.pasos??0),0).toLocaleString()}</Text>
                        <Text style={s.totLbl}>pasos</Text>
                      </View>
                    </View>
                  </View>
                </View>
              ) : (
                <View style={s.emptyWrap}>
                  <Text style={s.emptyIcon}>📈</Text>
                  <Text style={s.empty}>Completa al menos una carrera{'\n'}para ver tus gráficas.</Text>
                </View>
              )
            )}
          </ScrollView>
</ScreenWrapper>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  bg: { flex: 1 },
  safe: { flex: 1 },
  title: { fontFamily: 'DaysOne_400Regular', fontSize: 22, color: '#fff', textAlign: 'center', paddingTop: 0 },
  divider: { height: 1, backgroundColor: 'rgba(255,255,255,0.12)', marginHorizontal: 18, marginVertical: 8 },

  tabRow: { flexDirection: 'row', marginHorizontal: 14, marginBottom: 10, gap: 6 },
  tabBtn: {
    flex: 1, height: 34, borderRadius: 17, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', backgroundColor: 'rgba(255,255,255,0.03)',
  },
  tabActive: { backgroundColor: 'rgba(0,200,255,0.16)', borderColor: 'rgba(0,200,255,0.4)' },
  tabText: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.4)' },
  tabTextActive: { color: '#00C8FF' },

  scroll: { paddingHorizontal: 14, paddingBottom: 24 },
  dateLabel: {
    fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(0,200,255,0.7)',
    textAlign: 'center', letterSpacing: 1, marginBottom: 10,
  },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },

  emptyWrap: { alignItems: 'center', paddingTop: 60 },
  emptyIcon: { fontSize: 52, marginBottom: 14 },
  empty: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: 'rgba(255,255,255,0.3)', textAlign: 'center', lineHeight: 22 },

  histCard: {
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', padding: 12, marginBottom: 6,
  },
  histHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  histNum: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#00C8FF', minWidth: 30 },
  histDate: { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.5)' },
  histChev: { fontFamily: 'DaysOne_400Regular', fontSize: 12, color: 'rgba(255,255,255,0.4)' },
  histStats: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  histStat: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: '#fff', minWidth: '44%' },
  histMapWrap: { marginBottom: 8, marginTop: -4 },

  chartsWrap: { gap: 10 },
  chartCard: {
    backgroundColor: 'rgba(255,255,255,0.04)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)', padding: 12,
  },
  chartTitle: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.6)', marginBottom: 4 },

  totalesCard: {
    backgroundColor: 'rgba(0,200,255,0.06)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.2)', padding: 14,
  },
  totRow: { flexDirection: 'row', justifyContent: 'space-around', marginTop: 10 },
  tot: { alignItems: 'center' },
  totVal: { fontFamily: 'DaysOne_400Regular', fontSize: 20, color: '#00C8FF' },
  totLbl: { fontFamily: 'DaysOne_400Regular', fontSize: 9, color: 'rgba(255,255,255,0.4)', marginTop: 2 },
});

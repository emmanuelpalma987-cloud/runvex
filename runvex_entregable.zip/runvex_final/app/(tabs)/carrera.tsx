import React, { useRef } from 'react';
import {
  View, Text, StyleSheet, StatusBar, TouchableOpacity,
  Alert, ScrollView, Dimensions, Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Polyline, PROVIDER_DEFAULT, PROVIDER_GOOGLE } from 'react-native-maps';
import { useAuth } from '../../src/hooks/useAuth';
import { useRunTracker, formatTiempo, formatPace } from '../../src/hooks/useRunTracker';
import { guardarCarrera } from '../../src/database/database';

// ─── Responsivo ────────────────────────────────────────────────────────────────
const { width: W, height: H } = Dimensions.get('window');
const rs = (n: number) => Math.round((W / 390) * n);
const isSmall  = H < 680;
const isTablet = W > 600;

// Altura del mapa: adaptiva
const MAP_H = Math.round(H * (isSmall ? 0.22 : isTablet ? 0.35 : 0.28));

// ─── Componente métrica ────────────────────────────────────────────────────────
interface MetricProps {
  label: string;
  value: string;
  sub?: string;
  accent?: string;
  size?: 'normal' | 'large';
}
function Metric({ label, value, sub, accent = '#fff', size = 'normal' }: MetricProps) {
  return (
    <View style={m.box}>
      <Text style={[m.val, { color: accent, fontSize: rs(size === 'large' ? 30 : 24) }]} numberOfLines={1} adjustsFontSizeToFit>
        {value}
      </Text>
      {sub ? <Text style={m.sub}>{sub}</Text> : null}
      <Text style={m.label}>{label}</Text>
    </View>
  );
}

// ─── Pantalla ──────────────────────────────────────────────────────────────────
export default function CarreraScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { usuario } = useAuth();
  const { datos, iniciarCarrera, pausarCarrera, reanudarCarrera, terminarCarrera } = useRunTracker();
  const mapRef = useRef<MapView>(null);

  // ── Handlers ────────────────────────────────────────────────────────────────
  const handleAccion = () => {
    if (!datos.corriendo && !datos.pausado) {
      iniciarCarrera();
    } else if (datos.corriendo) {
      pausarCarrera();
    } else {
      reanudarCarrera();
    }
  };

  const handleTerminar = async () => {
    if (!datos.corriendo && !datos.pausado && datos.tiempoSegundos === 0) {
      Alert.alert('Sin carrera', 'Inicia una carrera primero.');
      return;
    }
    Alert.alert(
      'Terminar carrera',
      `Distancia: ${datos.distanciaKm.toFixed(2)} km\nTiempo: ${formatTiempo(datos.tiempoSegundos)}\n\n¿Deseas guardar los resultados?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Guardar',
          onPress: async () => {
            const res = terminarCarrera();
            if (usuario?.id) {
              try {
                const inicio = res.coordenadas[0];
                const fim    = res.coordenadas[res.coordenadas.length - 1];
                await guardarCarrera({
                  usuario_id: usuario.id,
                  distancia_km: res.distanciaKm,
                  tiempo_segundos: res.tiempoSegundos,
                  velocidad_promedio: res.velocidadPromedio,
                  calorias: res.calorias,
                  pasos: res.pasos,
                  bpm_promedio: res.bpmPromedio,
                  bpm_maximo: res.bpmMaximo,
                  elevacion_m: res.elevacionM,
                  ruta_json: JSON.stringify(res.coordenadas),
                  coord_inicio_lat: inicio?.latitude,
                  coord_inicio_lon: inicio?.longitude,
                  coord_fin_lat: fim?.latitude,
                  coord_fin_lon: fim?.longitude,
                });
              } catch (e) {
                console.error('Error guardando carrera:', e);
              }
            }
            router.push('/(tabs)/resultados');
          },
        },
      ]
    );
  };

  // ── Ruta guía precargada ─────────────────────────────────────────────────────
  const { rutaPreview } = useLocalSearchParams<{ rutaPreview?: string }>();
  const coordsPreview: { latitude: number; longitude: number }[] = rutaPreview
    ? (() => { try { return JSON.parse(rutaPreview as string); } catch { return []; } })()
    : [];

  // ── Región del mapa ──────────────────────────────────────────────────────────
  const ultimaCoord = datos.coordenadas[datos.coordenadas.length - 1];
  const region = ultimaCoord
    ? { latitude: ultimaCoord.latitude, longitude: ultimaCoord.longitude, latitudeDelta: 0.004, longitudeDelta: 0.004 }
    : { latitude: 19.2869, longitude: -99.6531, latitudeDelta: 0.01, longitudeDelta: 0.01 };

  // ── Botón principal ──────────────────────────────────────────────────────────
  const btnTexto = datos.corriendo ? 'PAUSAR' : datos.pausado ? 'REANUDAR' : 'INICIAR';
  const btnStyle = datos.corriendo ? s.btnPause : datos.pausado ? s.btnResume : s.btnStart;

  // ── Color BPM por zona ────────────────────────────────────────────────────────
  const bpmColor = datos.bpm === 0         ? 'rgba(255,255,255,0.4)'
                 : datos.bpm < 110         ? '#4CD964'
                 : datos.bpm < 140         ? '#FFD60A'
                 : datos.bpm < 160         ? '#FF9500'
                 :                           '#FF3B30';

  // ── Velocidad a mostrar ──────────────────────────────────────────────────────
  const velDisplay = datos.velocidadActual > 0
    ? datos.velocidadActual.toFixed(1)
    : datos.velocidadPromedio > 0
      ? datos.velocidadPromedio.toFixed(1)
      : '0.0';

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      <ScrollView
        style={s.scroll}
        contentContainerStyle={[s.scrollContent, { paddingTop: insets.top + rs(8) }]}
        showsVerticalScrollIndicator={false}
        scrollEnabled={!datos.corriendo} // bloquea scroll mientras corre
      >
        {/* ── Header ── */}
        <View style={s.header}>
          <Text style={s.title}>Modo Carrera</Text>
          {datos.corriendo && (
            <View style={s.liveBadge}><Text style={s.liveText}>● EN VIVO</Text></View>
          )}
          {datos.pausado && (
            <View style={s.pausedBadge}><Text style={s.pausedText}>PAUSADO</Text></View>
          )}
        </View>
        <View style={s.divider} />

        {/* ── Tiempo grande ── */}
        <Text style={s.timer}>{formatTiempo(datos.tiempoSegundos)}</Text>
        <View style={s.divider} />

        {/* ── Métricas fila 1: Distancia + Velocidad ── */}
        <View style={s.metricsRow}>
          <Metric label="DISTANCIA" value={datos.distanciaKm.toFixed(2)} sub="km" accent="#00C8FF" size="large" />
          <View style={s.metricSep} />
          <Metric label="VELOCIDAD" value={velDisplay} sub="km/h" />
        </View>

        {/* ── Métricas fila 2: Ritmo + Pasos ── */}
        <View style={s.metricsRow}>
          <Metric label="RITMO" value={formatPace(datos.pace)} />
          <View style={s.metricSep} />
          <Metric label="PASOS" value={datos.pasos.toLocaleString()} accent="#4CD964" />
        </View>

        {/* ── Métricas fila 3: Cadencia + Calorías ── */}
        <View style={s.metricsRow}>
          <Metric label="CADENCIA" value={datos.cadencia > 0 ? `${datos.cadencia}` : '--'} sub="p/min" accent="#FF9500" />
          <View style={s.metricSep} />
          <Metric label="CALORÍAS" value={`${datos.calorias}`} sub="kcal" accent="#FF6B35" />
        </View>
        <View style={s.divider} />

        {/* ── Mapa ── */}
        <View style={[s.mapWrap, { height: MAP_H }]}>
          <MapView
            ref={mapRef}
            style={s.map}
            provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : PROVIDER_DEFAULT}
            region={region}
            mapType="standard"
            showsUserLocation
            followsUserLocation={datos.corriendo}
            showsMyLocationButton={false}
            showsCompass={false}
            scrollEnabled={!datos.corriendo}
            zoomEnabled
          >
            {/* Ruta guía precargada */}
            {coordsPreview.length > 1 && (
              <Polyline
                coordinates={coordsPreview}
                strokeColor="rgba(255,165,0,0.55)"
                strokeWidth={rs(3)}
                lineDashPattern={[8, 6]}
              />
            )}
            {/* Ruta recorrida en tiempo real */}
            {datos.coordenadas.length > 1 && (
              <Polyline
                coordinates={datos.coordenadas}
                strokeColor="#00C8FF"
                strokeWidth={rs(5)}
              />
            )}
          </MapView>

          {/* BPM flotante */}
          <View style={[s.bpmBadge, { borderColor: bpmColor }]}>
            <Text style={[s.bpmText, { color: bpmColor }]}>
              ❤️ {datos.bpm > 0 ? `${datos.bpm}` : '--'} bpm
            </Text>
            {datos.bpmMaximo > 0 && (
              <Text style={s.bpmMax}>máx {datos.bpmMaximo}</Text>
            )}
          </View>

          {/* Elevación flotante */}
          <View style={s.elevBadge}>
            <Text style={s.elevText}>⛰️ +{datos.elevacionAcumulada.toFixed(0)} m</Text>
          </View>
        </View>

        {/* ── Fila inferior al mapa: Altitud ── */}
        <View style={s.altRow}>
          <Text style={s.altText}>Altitud: {datos.altitudActual.toFixed(0)} m snm</Text>
          {datos.velocidadPromedio > 0 && (
            <Text style={s.altText}>Prom: {datos.velocidadPromedio.toFixed(1)} km/h</Text>
          )}
        </View>

        {/* ── Botones ── */}
        <View style={[s.btnRow, { paddingBottom: insets.bottom + rs(8) }]}>
          <TouchableOpacity style={[s.btn, btnStyle]} onPress={handleAccion} activeOpacity={0.85}>
            <Text style={s.btnText}>{btnTexto}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[s.btn, s.btnStop]} onPress={handleTerminar} activeOpacity={0.85}>
            <Text style={s.btnText}>TERMINAR</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

// ─── Estilos ──────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  root:   { flex: 1, backgroundColor: '#050A15' },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: rs(16) },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    paddingVertical: rs(8), gap: rs(10),
  },
  title: { fontFamily: 'DaysOne_400Regular', fontSize: rs(20), color: '#fff' },
  liveBadge: {
    backgroundColor: 'rgba(255,59,48,0.18)', borderRadius: rs(8),
    paddingHorizontal: rs(8), paddingVertical: rs(2),
    borderWidth: 1, borderColor: 'rgba(255,59,48,0.5)',
  },
  liveText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(10), color: '#FF3B30' },
  pausedBadge: {
    backgroundColor: 'rgba(255,165,0,0.18)', borderRadius: rs(8),
    paddingHorizontal: rs(8), paddingVertical: rs(2),
    borderWidth: 1, borderColor: 'rgba(255,165,0,0.5)',
  },
  pausedText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(10), color: '#FF9500' },

  divider: {
    height: 1, backgroundColor: 'rgba(255,255,255,0.10)',
    marginVertical: rs(6),
  },

  timer: {
    fontFamily: 'DaysOne_400Regular',
    fontSize: rs(isSmall ? 44 : isTablet ? 64 : 52),
    color: '#fff',
    textAlign: 'center',
    letterSpacing: rs(4),
    paddingVertical: rs(4),
  },

  metricsRow: { flexDirection: 'row', paddingVertical: rs(4) },
  metricSep: {
    width: 1, backgroundColor: 'rgba(255,255,255,0.12)', marginVertical: rs(4),
  },

  mapWrap: {
    borderRadius: rs(16), overflow: 'hidden', position: 'relative',
    marginVertical: rs(8),
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.15)',
  },
  map: { flex: 1 },

  bpmBadge: {
    position: 'absolute', top: rs(10), right: rs(10),
    backgroundColor: 'rgba(0,0,0,0.80)', borderRadius: rs(12),
    paddingHorizontal: rs(12), paddingVertical: rs(6),
    borderWidth: 1, alignItems: 'center',
  },
  bpmText:  { fontFamily: 'DaysOne_400Regular', fontSize: rs(14) },
  bpmMax:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(9), color: 'rgba(255,255,255,0.45)', marginTop: 2 },

  elevBadge: {
    position: 'absolute', top: rs(10), left: rs(10),
    backgroundColor: 'rgba(0,0,0,0.80)', borderRadius: rs(12),
    paddingHorizontal: rs(12), paddingVertical: rs(6),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)',
  },
  elevText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(12), color: '#fff' },

  altRow: {
    flexDirection: 'row', justifyContent: 'space-between',
    paddingHorizontal: rs(4), paddingBottom: rs(6),
  },
  altText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.42)' },

  btnRow: { flexDirection: 'row', gap: rs(12), paddingTop: rs(6) },
  btn: {
    flex: 1, height: rs(isTablet ? 60 : 50), borderRadius: rs(25),
    justifyContent: 'center', alignItems: 'center',
  },
  btnStart:  { backgroundColor: 'rgba(0,200,255,0.18)', borderWidth: 1, borderColor: 'rgba(0,200,255,0.6)' },
  btnPause:  { backgroundColor: 'rgba(255,165,0,0.18)', borderWidth: 1, borderColor: 'rgba(255,165,0,0.6)' },
  btnResume: { backgroundColor: 'rgba(76,217,100,0.18)', borderWidth: 1, borderColor: 'rgba(76,217,100,0.6)' },
  btnStop:   { backgroundColor: 'rgba(255,59,48,0.18)', borderWidth: 1, borderColor: 'rgba(255,59,48,0.6)' },
  btnText:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(15), color: '#fff', letterSpacing: rs(1) },
});

const m = StyleSheet.create({
  box: { flex: 1, alignItems: 'center', paddingVertical: rs(6) },
  val: { fontFamily: 'DaysOne_400Regular', color: '#fff', lineHeight: undefined },
  sub: { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.48)', lineHeight: rs(14) },
  label: { fontFamily: 'DaysOne_400Regular', fontSize: rs(9), color: 'rgba(255,255,255,0.38)', marginTop: rs(2), letterSpacing: 1 },
});

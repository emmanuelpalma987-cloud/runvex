/**
 * rutas.tsx — v3 FINAL
 * ─────────────────────────────────────────────────────────────────
 * • Mapa tipo Google Maps (calles estándar visibles, modo "standard")
 * • Rutas reales por calles usando OSRM (sin API key)
 * • Búsqueda de cualquier lugar con Nominatim geocoding
 * • 3 opciones de ruta (igual que Google Maps: más rápida, alternativa 1, alternativa 2)
 * • Modo CREAR: múltiples waypoints dibujando en el mapa, ruta por calles en tiempo real
 * • Diseño 100% responsivo (móvil pequeño, estándar, tablet)
 * • Botón "Centrar en mi ubicación"
 * • UI tipo Google Maps: marcadores de inicio/fin, polilíneas coloreadas
 * ─────────────────────────────────────────────────────────────────
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Alert, TextInput, ActivityIndicator, StatusBar, Dimensions, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Polyline, PROVIDER_DEFAULT, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import { useFocusEffect, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../src/hooks/useAuth';
import { guardarRuta, obtenerRutas, eliminarRuta } from '../../src/database/database';

// ─── Responsivo ────────────────────────────────────────────────────────────────
const { width: W, height: H } = Dimensions.get('window');
const rs = (n: number) => Math.round((W / 390) * n);
// Mapa ocupa ~42% de la pantalla en teléfonos normales
const MAP_H = Math.round(H * (H < 700 ? 0.36 : H > 900 ? 0.45 : 0.42));

interface Coord { latitude: number; longitude: number; }

// ─── Helpers ───────────────────────────────────────────────────────────────────
function haversineM(a: Coord, b: Coord): number {
  const R = 6371000;
  const dLat = (b.latitude - a.latitude) * Math.PI / 180;
  const dLon = (b.longitude - a.longitude) * Math.PI / 180;
  const x = Math.sin(dLat / 2) ** 2 +
    Math.cos(a.latitude * Math.PI / 180) * Math.cos(b.latitude * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}
function totalDistM(coords: Coord[]): number {
  let d = 0;
  for (let i = 1; i < coords.length; i++) d += haversineM(coords[i - 1], coords[i]);
  return d;
}
function fmtDist(m: number): string {
  return m >= 1000 ? `${(m / 1000).toFixed(2)} km` : `${Math.round(m)} m`;
}
function tiempoEstimado(distM: number, velKmh: number): string {
  const min = Math.round((distM / 1000) / velKmh * 60);
  if (min < 1) return '<1 min';
  if (min < 60) return `~${min} min`;
  return `~${Math.floor(min / 60)}h ${min % 60}min`;
}
function centroBounds(coords: Coord[]): Coord & { latitudeDelta: number; longitudeDelta: number } {
  const lats = coords.map(c => c.latitude);
  const lons = coords.map(c => c.longitude);
  const minLat = Math.min(...lats), maxLat = Math.max(...lats);
  const minLon = Math.min(...lons), maxLon = Math.max(...lons);
  return {
    latitude: (minLat + maxLat) / 2,
    longitude: (minLon + maxLon) / 2,
    latitudeDelta: Math.max((maxLat - minLat) * 1.5, 0.005),
    longitudeDelta: Math.max((maxLon - minLon) * 1.5, 0.005),
  };
}

// ─── OSRM — Rutas reales por calles ───────────────────────────────────────────
// Open Source Routing Machine: 100% gratuito, sin API key
// Perfil "foot" = peatón/corredor (sigue calles peatonales y ciclistas)
const OSRM_BASE = 'https://router.project-osrm.org/route/v1';

function decodePolyline(encoded: string): Coord[] {
  let index = 0, lat = 0, lng = 0;
  const coords: Coord[] = [];
  while (index < encoded.length) {
    let b, shift = 0, result = 0;
    do { b = encoded.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dLat = result & 1 ? ~(result >> 1) : result >> 1; lat += dLat;
    shift = 0; result = 0;
    do { b = encoded.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    const dLng = result & 1 ? ~(result >> 1) : result >> 1; lng += dLng;
    coords.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
  }
  return coords;
}

// Obtiene hasta 3 rutas alternativas entre 2 puntos, siguiendo calles reales
async function getOSRMRoutes(origen: Coord, destino: Coord): Promise<{ puntos: Coord[]; distanciaM: number }[]> {
  try {
    const wpts = `${origen.longitude},${origen.latitude};${destino.longitude},${destino.latitude}`;
    const url = `${OSRM_BASE}/foot/${wpts}?overview=full&geometries=polyline&alternatives=true`;
    const res = await fetch(url, {
      headers: { 'Accept': 'application/json' },
      signal: AbortSignal.timeout(8000),
    });
    const data = await res.json();
    if (data.code !== 'Ok' || !data.routes?.length) return [];
    return data.routes.map((r: any) => ({
      puntos: decodePolyline(r.geometry),
      distanciaM: Math.round(r.distance),
    }));
  } catch {
    return [];
  }
}

// Encadena varios waypoints en una sola ruta OSRM (segmento a segmento)
async function getOSRMMultiWaypoint(waypoints: Coord[]): Promise<Coord[]> {
  if (waypoints.length < 2) return waypoints;
  const wptStr = waypoints.map(p => `${p.longitude},${p.latitude}`).join(';');
  try {
    const url = `${OSRM_BASE}/foot/${wptStr}?overview=full&geometries=polyline`;
    const res = await fetch(url, {
      headers: { 'Accept': 'application/json' },
      signal: AbortSignal.timeout(8000),
    });
    const data = await res.json();
    if (data.code !== 'Ok' || !data.routes?.length) return waypoints;
    return decodePolyline(data.routes[0].geometry);
  } catch {
    return waypoints;
  }
}

// Geocoding con Nominatim (OpenStreetMap)
async function geocodePlace(query: string, cerca: Coord): Promise<Coord | null> {
  try {
    const q = encodeURIComponent(query);
    const url = `https://nominatim.openstreetmap.org/search?q=${q}&format=json&limit=3&lat=${cerca.latitude}&lon=${cerca.longitude}&radius=100000`;
    const res = await fetch(url, {
      headers: { 'User-Agent': 'RunvexApp/3.0 (contact@runvex.app)' },
      signal: AbortSignal.timeout(6000),
    });
    const data = await res.json();
    if (data.length > 0) return { latitude: parseFloat(data[0].lat), longitude: parseFloat(data[0].lon) };
    return null;
  } catch { return null; }
}

// ─── Tipos ─────────────────────────────────────────────────────────────────────
type Modo = 'buscar' | 'crear' | 'guardadas';

interface RutaOpcion {
  nombre: string;
  color: string;
  velKmh: number;
  puntos: Coord[];
  distanciaM: number;
}

const COLORES_RUTA = ['#00C8FF', '#4CD964', '#FF9500'];
const NOMBRES_RUTA = ['Ruta principal', 'Ruta alternativa 1', 'Ruta alternativa 2'];
const VEL_KMH = [9, 8, 7.5];

// ─── Pantalla ──────────────────────────────────────────────────────────────────
export default function RutasScreen() {
  const { usuario } = useAuth();
  const router      = useRouter();
  const insets      = useSafeAreaInsets();
  const mapRef      = useRef<MapView>(null);

  const [modo, setModo]             = useState<Modo>('buscar');
  const [miPos, setMiPos]           = useState<Coord>({ latitude: 19.2869, longitude: -99.6531 });
  const [region, setRegion]         = useState({
    latitude: 19.2869, longitude: -99.6531, latitudeDelta: 0.012, longitudeDelta: 0.012,
  });
  const [buscando, setBuscando]     = useState(false);
  const [destino, setDestino]       = useState('');
  const [rutasOpciones, setRutasOpciones] = useState<RutaOpcion[]>([]);
  const [rutaSeleccionada, setRutaSeleccionada] = useState<number>(0);
  const [destinoCoord, setDestinoCoord] = useState<Coord | null>(null);

  // Modo crear
  const [puntos, setPuntos]         = useState<Coord[]>([]);
  const [nombreRuta, setNombreRuta] = useState('');
  const [rutaDibujada, setRutaDibujada] = useState<Coord[]>([]);
  const [calculandoRuta, setCalculandoRuta] = useState(false);

  // Guardadas
  const [rutasGuardadas, setRutasGuardadas] = useState<any[]>([]);
  const [rutaVista, setRutaVista]   = useState<any | null>(null);

  useFocusEffect(useCallback(() => { loadRutas(); }, [usuario]));

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const pos = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
        setMiPos(pos);
        setRegion({ ...pos, latitudeDelta: 0.012, longitudeDelta: 0.012 });
      }
    })();
  }, []);

  // Cuando el usuario agrega ≥2 puntos en modo crear, recalcula la ruta por calles
  const calcularRutaDibujada = useCallback(async (pts: Coord[]) => {
    if (pts.length < 2) { setRutaDibujada([]); return; }
    setCalculandoRuta(true);
    try {
      const ruta = await getOSRMMultiWaypoint(pts);
      setRutaDibujada(ruta.length > 1 ? ruta : pts);
      if (ruta.length > 1) {
        const bounds = centroBounds(ruta);
        mapRef.current?.animateToRegion(bounds, 600);
      }
    } catch {
      setRutaDibujada(pts);
    } finally {
      setCalculandoRuta(false);
    }
  }, []);

  const loadRutas = async () => {
    if (usuario?.id) {
      const r = await obtenerRutas(usuario.id).catch(() => []);
      setRutasGuardadas(r);
    }
  };

  // ── Buscar destino con rutas OSRM reales ──────────────────────────────────
  const handleBuscar = async () => {
    const query = destino.trim();
    if (!query) return;
    setBuscando(true);
    setRutasOpciones([]);
    setDestinoCoord(null);
    try {
      const coord = await geocodePlace(query, miPos);
      if (!coord) {
        Alert.alert('No encontrado', 'No se encontró ese lugar. Prueba con una dirección más específica o incluye la ciudad.');
        return;
      }
      setDestinoCoord(coord);

      // Obtener hasta 3 rutas alternativas por calles
      const osrmRoutes = await getOSRMRoutes(miPos, coord);

      if (osrmRoutes.length === 0) {
        // Fallback: línea recta si OSRM no responde
        const distM = haversineM(miPos, coord);
        setRutasOpciones([{
          nombre: 'Ruta directa',
          color: COLORES_RUTA[0],
          velKmh: 9,
          puntos: [miPos, coord],
          distanciaM: distM,
        }]);
        const bounds = centroBounds([miPos, coord]);
        mapRef.current?.animateToRegion(bounds, 800);
        return;
      }

      const opciones: RutaOpcion[] = osrmRoutes.slice(0, 3).map((r, i) => ({
        nombre: NOMBRES_RUTA[i] ?? `Ruta ${i + 1}`,
        color: COLORES_RUTA[i] ?? '#fff',
        velKmh: VEL_KMH[i] ?? 8,
        puntos: r.puntos,
        distanciaM: r.distanciaM,
      }));

      setRutasOpciones(opciones);
      setRutaSeleccionada(0);

      // Ajustar mapa para mostrar la ruta completa
      const todosLosPuntos = [...opciones.flatMap(o => o.puntos)];
      const bounds = centroBounds(todosLosPuntos);
      mapRef.current?.animateToRegion(bounds, 800);
    } catch (e) {
      Alert.alert('Error', 'No se pudo calcular la ruta. Revisa tu conexión.');
    } finally {
      setBuscando(false);
    }
  };

  const handleIniciarRuta = () => {
    const ruta = rutasOpciones[rutaSeleccionada];
    if (!ruta) return;
    router.push({
      pathname: '/(tabs)/carrera',
      params: { rutaPreview: JSON.stringify(ruta.puntos) },
    });
  };

  // ── Agregar punto en modo crear ────────────────────────────────────────────
  const agregarPunto = useCallback((coord: Coord) => {
    setPuntos(prev => {
      const nuevos = [...prev, coord];
      calcularRutaDibujada(nuevos);
      return nuevos;
    });
  }, [calcularRutaDibujada]);

  const deshacerPunto = useCallback(() => {
    setPuntos(prev => {
      const nuevos = prev.slice(0, -1);
      calcularRutaDibujada(nuevos);
      return nuevos;
    });
  }, [calcularRutaDibujada]);

  const limpiarPuntos = useCallback(() => {
    setPuntos([]);
    setRutaDibujada([]);
    setNombreRuta('');
  }, []);

  const handleGuardarCreada = async () => {
    if (puntos.length < 2 || calculandoRuta) return;
    const coordsFinal = rutaDibujada.length > 1 ? rutaDibujada : puntos;
    const distM = totalDistM(coordsFinal);
    const nombre = nombreRuta.trim() || `Ruta ${new Date().toLocaleDateString('es-MX')}`;
    try {
      await guardarRuta({
        usuario_id: usuario?.id ?? 0,
        nombre,
        distancia_km: distM / 1000,
        tiempo_estimado_min: Math.round(distM / 1000 / 9 * 60),
        coordenadas_json: JSON.stringify(coordsFinal),
      });
      Alert.alert('✅ Guardada', `"${nombre}" guardada correctamente.`);
      limpiarPuntos();
      setModo('guardadas');
      loadRutas();
    } catch {
      Alert.alert('Error', 'No se pudo guardar la ruta.');
    }
  };

  const verRutaGuardada = (r: any) => {
    setRutaVista(r);
    try {
      const coords: Coord[] = JSON.parse(r.coordenadas_json);
      if (coords.length > 1) {
        mapRef.current?.animateToRegion(centroBounds(coords), 700);
      }
    } catch {}
  };

  const initRutaGuardada = (r: any) => {
    try {
      const coords: Coord[] = JSON.parse(r.coordenadas_json);
      router.push({ pathname: '/(tabs)/carrera', params: { rutaPreview: JSON.stringify(coords) } });
    } catch { Alert.alert('Error', 'No se pudo cargar la ruta.'); }
  };

  const centrarMiPosicion = () => {
    mapRef.current?.animateToRegion({ ...miPos, latitudeDelta: 0.008, longitudeDelta: 0.008 }, 500);
  };

  const rutaActual = rutasOpciones[rutaSeleccionada];

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <LinearGradient colors={['#050A15', '#0A1020']} style={s.bg}>

        {/* Header */}
        <View style={[s.headerWrap, { paddingTop: insets.top + rs(8) }]}>
          <Text style={s.title}>Rutas de Carrera</Text>
          <View style={s.modeRow}>
            {([
              { key: 'buscar', label: '🔍 Buscar' },
              { key: 'crear',  label: '✏️ Crear' },
              { key: 'guardadas', label: '📂 Mis Rutas' },
            ] as const).map(m => (
              <TouchableOpacity
                key={m.key}
                style={[s.modeBtn, modo === m.key && s.modeBtnActive]}
                onPress={() => { setModo(m.key); setRutaVista(null); }}
                activeOpacity={0.75}
              >
                <Text style={[s.modeBtnText, modo === m.key && s.modeBtnTextActive]}>{m.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ── MAPA tipo Google Maps ── */}
        <View style={[s.mapWrap, { height: MAP_H }]}>
          <MapView
            ref={mapRef}
            style={s.map}
            // En Android usa Google Maps nativo (calles exactas como Google Maps)
            // En iOS usa Apple Maps en modo estándar
            provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : PROVIDER_DEFAULT}
            region={region}
            mapType="standard"          // calles visibles, mismo estilo que Google Maps
            showsUserLocation
            showsMyLocationButton={false}
            showsTraffic={false}
            showsCompass={false}
            showsScale
            onPress={(e) => {
              if (modo === 'crear') agregarPunto(e.nativeEvent.coordinate);
            }}
          >
            {/* ── MODO BUSCAR: rutas por calles ── */}
            {modo === 'buscar' && rutasOpciones.map((r, i) => (
              <Polyline
                key={i}
                coordinates={r.puntos}
                strokeColor={i === rutaSeleccionada ? r.color : `${r.color}55`}
                strokeWidth={i === rutaSeleccionada ? rs(6) : rs(3)}
                lineDashPattern={i === rutaSeleccionada ? undefined : [8, 5]}
                zIndex={i === rutaSeleccionada ? 10 : i}
              />
            ))}
            {modo === 'buscar' && destinoCoord && (
              <>
                {/* Marcador inicio (verde, con A) */}
                <Marker coordinate={miPos} title="Mi posición" anchor={{ x: 0.5, y: 1 }}>
                  <View style={s.markerStart}>
                    <Text style={s.markerLetter}>A</Text>
                  </View>
                </Marker>
                {/* Marcador destino (rojo, con B) */}
                <Marker coordinate={destinoCoord} title="Destino" anchor={{ x: 0.5, y: 1 }}>
                  <View style={s.markerEnd}>
                    <Text style={s.markerLetter}>B</Text>
                  </View>
                </Marker>
              </>
            )}

            {/* ── MODO CREAR: polilínea en tiempo real ── */}
            {modo === 'crear' && rutaDibujada.length > 1 && (
              <Polyline
                coordinates={rutaDibujada}
                strokeColor="#00C8FF"
                strokeWidth={rs(5)}
                zIndex={5}
              />
            )}
            {/* Línea punteada provisional mientras calcula */}
            {modo === 'crear' && rutaDibujada.length < 2 && puntos.length > 1 && (
              <Polyline
                coordinates={puntos}
                strokeColor="rgba(0,200,255,0.45)"
                strokeWidth={rs(3)}
                lineDashPattern={[6, 5]}
                zIndex={4}
              />
            )}
            {/* Waypoints del dibujo */}
            {modo === 'crear' && puntos.map((p, i) => (
              <Marker
                key={i}
                coordinate={p}
                anchor={{ x: 0.5, y: 1 }}
                title={i === 0 ? 'Inicio' : i === puntos.length - 1 ? 'Fin' : `Punto ${i + 1}`}
              >
                <View style={[
                  s.waypointDot,
                  i === 0 && s.waypointStart,
                  i === puntos.length - 1 && i > 0 && s.waypointEnd,
                ]}>
                  <Text style={s.waypointNum}>{i === 0 ? 'S' : i + 1}</Text>
                </View>
              </Marker>
            ))}

            {/* ── MODO GUARDADAS: ruta vista ── */}
            {modo === 'guardadas' && rutaVista && (() => {
              try {
                const coords: Coord[] = JSON.parse(rutaVista.coordenadas_json);
                return (
                  <>
                    <Polyline coordinates={coords} strokeColor="#FF9500" strokeWidth={rs(5)} zIndex={5} />
                    {coords.length > 0 && (
                      <Marker coordinate={coords[0]} anchor={{ x: 0.5, y: 1 }}>
                        <View style={s.markerStart}><Text style={s.markerLetter}>A</Text></View>
                      </Marker>
                    )}
                    {coords.length > 1 && (
                      <Marker coordinate={coords[coords.length - 1]} anchor={{ x: 0.5, y: 1 }}>
                        <View style={s.markerEnd}><Text style={s.markerLetter}>B</Text></View>
                      </Marker>
                    )}
                  </>
                );
              } catch { return null; }
            })()}
          </MapView>

          {/* Botón centrar en mi posición (igual que Google Maps) */}
          <TouchableOpacity style={s.myLocBtn} onPress={centrarMiPosicion} activeOpacity={0.8}>
            <Text style={s.myLocIcon}>⊕</Text>
          </TouchableOpacity>

          {/* Hint para modo crear */}
          {modo === 'crear' && (
            <View style={s.mapHint}>
              {calculandoRuta
                ? <><ActivityIndicator color="#00C8FF" size="small" /><Text style={[s.mapHintText, { marginLeft: rs(8) }]}>Calculando ruta por calles...</Text></>
                : <Text style={s.mapHintText}>
                    {puntos.length === 0
                      ? '📍 Toca el mapa para agregar puntos'
                      : `${puntos.length} punto${puntos.length > 1 ? 's' : ''} · ${fmtDist(totalDistM(rutaDibujada.length > 1 ? rutaDibujada : puntos))}`}
                  </Text>
              }
            </View>
          )}

          {/* Buscando overlay */}
          {buscando && (
            <View style={s.mapOverlay}>
              <ActivityIndicator color="#00C8FF" size="large" />
              <Text style={s.mapOverlayText}>Calculando rutas por calles...</Text>
            </View>
          )}
        </View>

        {/* ── Panel inferior ── */}
        <View style={[s.panel, { paddingBottom: insets.bottom + rs(6) }]}>

          {/* MODO BUSCAR */}
          {modo === 'buscar' && (
            <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
              <View style={s.searchRow}>
                <View style={s.searchBox}>
                  <Text style={s.searchIcon}>🔍</Text>
                  <TextInput
                    style={s.searchInput}
                    placeholder="¿A dónde quieres correr?"
                    placeholderTextColor="rgba(255,255,255,0.32)"
                    value={destino}
                    onChangeText={setDestino}
                    onSubmitEditing={handleBuscar}
                    returnKeyType="search"
                    autoCorrect={false}
                  />
                  {destino.length > 0 && (
                    <TouchableOpacity onPress={() => { setDestino(''); setRutasOpciones([]); setDestinoCoord(null); }}>
                      <Text style={s.clearBtn}>✕</Text>
                    </TouchableOpacity>
                  )}
                </View>
                <TouchableOpacity
                  style={[s.searchBtn, buscando && { opacity: 0.5 }]}
                  onPress={handleBuscar}
                  disabled={buscando}
                >
                  <Text style={s.searchBtnText}>IR</Text>
                </TouchableOpacity>
              </View>

              {rutasOpciones.length > 0 && (
                <>
                  <Text style={s.sectionLabel}>RUTAS POR CALLES REALES</Text>
                  {rutasOpciones.map((r, i) => {
                    const sel = i === rutaSeleccionada;
                    return (
                      <TouchableOpacity
                        key={i}
                        style={[s.rutaCard, sel && { borderColor: r.color, backgroundColor: `${r.color}10` }]}
                        onPress={() => setRutaSeleccionada(i)}
                        activeOpacity={0.8}
                      >
                        <View style={[s.rutaColorBar, { backgroundColor: r.color }]} />
                        <View style={s.rutaInfo}>
                          <Text style={[s.rutaNombre, sel && { color: r.color }]}>{r.nombre}</Text>
                          <View style={s.rutaStats}>
                            <Text style={s.rutaStat}>📍 {fmtDist(r.distanciaM)}</Text>
                            <Text style={s.rutaStat}>⏱ {tiempoEstimado(r.distanciaM, r.velKmh)}</Text>
                            <Text style={s.rutaStat}>⚡ {r.velKmh} km/h</Text>
                          </View>
                        </View>
                        {sel && <Text style={[s.checkBadge, { color: r.color }]}>✓</Text>}
                      </TouchableOpacity>
                    );
                  })}

                  <TouchableOpacity style={s.btnIniciar} onPress={handleIniciarRuta} activeOpacity={0.85}>
                    <LinearGradient
                      colors={['rgba(0,200,255,0.42)', 'rgba(0,200,255,0.15)']}
                      style={s.btnIniciarGrad}
                    >
                      <Text style={s.btnIniciarText}>
                        🏃 INICIAR {rutaActual?.nombre?.toUpperCase()}
                      </Text>
                      <Text style={s.btnIniciarSub}>
                        {fmtDist(rutaActual?.distanciaM ?? 0)} · {tiempoEstimado(rutaActual?.distanciaM ?? 0, rutaActual?.velKmh ?? 9)}
                      </Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              )}

              {rutasOpciones.length === 0 && !buscando && (
                <Text style={s.emptyHint}>
                  Escribe un parque, calle, colonia o dirección para calcular rutas reales por las calles desde tu posición.
                </Text>
              )}
            </ScrollView>
          )}

          {/* MODO CREAR */}
          {modo === 'crear' && (
            <View style={s.creadorPanel}>
              <View style={s.nameRow}>
                <TextInput
                  style={s.nameInput}
                  placeholder="Nombre de la ruta (opcional)"
                  placeholderTextColor="rgba(255,255,255,0.30)"
                  value={nombreRuta}
                  onChangeText={setNombreRuta}
                  maxLength={40}
                />
              </View>
              {puntos.length > 1 && (
                <View style={s.statsRow}>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{fmtDist(totalDistM(rutaDibujada.length > 1 ? rutaDibujada : puntos))}</Text>
                    <Text style={s.statLbl}>DISTANCIA</Text>
                  </View>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{tiempoEstimado(totalDistM(rutaDibujada.length > 1 ? rutaDibujada : puntos), 9)}</Text>
                    <Text style={s.statLbl}>TIEMPO EST.</Text>
                  </View>
                  <View style={s.statItem}>
                    <Text style={s.statVal}>{puntos.length}</Text>
                    <Text style={s.statLbl}>WAYPOINTS</Text>
                  </View>
                </View>
              )}
              <View style={s.btnRow}>
                <TouchableOpacity
                  style={[s.btnSec, puntos.length === 0 && { opacity: 0.3 }]}
                  onPress={deshacerPunto}
                  disabled={puntos.length === 0}
                >
                  <Text style={s.btnSecText}>↩ Deshacer</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[s.btnSec, puntos.length === 0 && { opacity: 0.3 }]}
                  onPress={limpiarPuntos}
                  disabled={puntos.length === 0}
                >
                  <Text style={s.btnSecText}>🗑️ Limpiar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[s.btnGuardar, (puntos.length < 2 || calculandoRuta) && { opacity: 0.35 }]}
                  onPress={handleGuardarCreada}
                  disabled={puntos.length < 2 || calculandoRuta}
                >
                  <Text style={s.btnGuardarText}>{calculandoRuta ? '⏳ Calculando...' : '💾 Guardar'}</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* MODO GUARDADAS */}
          {modo === 'guardadas' && (
            <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>
              {rutasGuardadas.length === 0
                ? <Text style={s.emptyHint}>Aún no tienes rutas guardadas. Crea una en la pestaña "Crear".</Text>
                : rutasGuardadas.map(r => {
                  const activa = rutaVista?.id === r.id;
                  return (
                    <TouchableOpacity
                      key={r.id}
                      style={[s.savedCard, activa && s.savedCardActive]}
                      onPress={() => verRutaGuardada(r)}
                      activeOpacity={0.8}
                    >
                      <View style={s.savedHeader}>
                        <Text style={s.savedNombre} numberOfLines={1}>{r.nombre}</Text>
                        <TouchableOpacity
                          onPress={() => Alert.alert('Eliminar', `¿Eliminar "${r.nombre}"?`, [
                            { text: 'Cancelar', style: 'cancel' },
                            {
                              text: 'Eliminar', style: 'destructive', onPress: async () => {
                                await eliminarRuta(r.id); loadRutas();
                                if (rutaVista?.id === r.id) setRutaVista(null);
                              },
                            },
                          ])}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <Text style={{ fontSize: rs(16) }}>🗑️</Text>
                        </TouchableOpacity>
                      </View>
                      <View style={s.savedStats}>
                        <Text style={s.savedStat}>🏃 {r.distancia_km?.toFixed(2)} km</Text>
                        <Text style={s.savedStat}>⏱ ~{r.tiempo_estimado_min} min</Text>
                      </View>
                      <TouchableOpacity style={s.btnIniciarSmall} onPress={() => initRutaGuardada(r)}>
                        <Text style={s.btnIniciarSmallText}>▶ INICIAR ESTA RUTA</Text>
                      </TouchableOpacity>
                    </TouchableOpacity>
                  );
                })}
            </ScrollView>
          )}
        </View>
      </LinearGradient>
    </View>
  );
}

// ─── Estilos ───────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  bg:   { flex: 1 },

  headerWrap: { paddingHorizontal: rs(16), paddingBottom: rs(6) },
  title: {
    fontFamily: 'DaysOne_400Regular', fontSize: rs(20), color: '#fff',
    textAlign: 'center', marginBottom: rs(10),
  },
  modeRow: { flexDirection: 'row', gap: rs(6), marginBottom: rs(6) },
  modeBtn: {
    flex: 1, height: rs(34), borderRadius: rs(17),
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
  },
  modeBtnActive:     { backgroundColor: 'rgba(0,200,255,0.16)', borderColor: 'rgba(0,200,255,0.45)' },
  modeBtnText:       { fontFamily: 'DaysOne_400Regular', fontSize: rs(10), color: 'rgba(255,255,255,0.38)' },
  modeBtnTextActive: { color: '#00C8FF' },

  // Mapa
  mapWrap: {
    marginHorizontal: rs(12), borderRadius: rs(16), overflow: 'hidden', position: 'relative',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.15)',
  },
  map: { flex: 1 },

  // Marcadores estilo Google Maps
  markerStart: {
    width: rs(28), height: rs(28), borderRadius: rs(14),
    backgroundColor: '#4CD964', justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: '#fff',
    shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 4, elevation: 5,
  },
  markerEnd: {
    width: rs(28), height: rs(28), borderRadius: rs(14),
    backgroundColor: '#FF3B30', justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: '#fff',
    shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 4, elevation: 5,
  },
  markerLetter: {
    fontFamily: 'DaysOne_400Regular', fontSize: rs(12), color: '#fff', fontWeight: 'bold',
  },

  // Waypoints del creador
  waypointDot: {
    width: rs(24), height: rs(24), borderRadius: rs(12),
    backgroundColor: '#00C8FF', justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: '#fff',
    shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 3, elevation: 4,
  },
  waypointStart: { backgroundColor: '#4CD964' },
  waypointEnd:   { backgroundColor: '#FF3B30' },
  waypointNum:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(9), color: '#fff' },

  // Botón centrar (estilo FAB de Google Maps)
  myLocBtn: {
    position: 'absolute', bottom: rs(44), right: rs(10),
    width: rs(42), height: rs(42), borderRadius: rs(21),
    backgroundColor: 'rgba(5,10,21,0.92)',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.4)',
    shadowColor: '#00C8FF', shadowOpacity: 0.3, shadowRadius: 6, elevation: 5,
  },
  myLocIcon: { fontSize: rs(22), color: '#00C8FF' },

  // Hint modo crear
  mapHint: {
    position: 'absolute', bottom: rs(8), left: rs(8), right: rs(54),
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.80)', borderRadius: rs(10),
    paddingHorizontal: rs(12), paddingVertical: rs(7),
  },
  mapHintText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: '#00C8FF' },

  // Overlay calculando
  mapOverlay: {
    ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(5,10,21,0.65)',
    justifyContent: 'center', alignItems: 'center', gap: rs(10),
  },
  mapOverlayText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: '#00C8FF' },

  // Panel inferior
  panel: { flex: 1, paddingHorizontal: rs(14), paddingTop: rs(10) },

  // Búsqueda
  searchRow: { flexDirection: 'row', gap: rs(8), marginBottom: rs(10) },
  searchBox: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: rs(12),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)',
    height: rs(48), paddingHorizontal: rs(12), gap: rs(8),
  },
  searchIcon:  { fontSize: rs(16) },
  searchInput: { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: '#fff' },
  clearBtn:    { color: 'rgba(255,255,255,0.4)', fontSize: rs(16) },
  searchBtn: {
    width: rs(56), height: rs(48), borderRadius: rs(12),
    justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(0,200,255,0.25)',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)',
  },
  searchBtnText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(14), color: '#fff', letterSpacing: 1 },

  sectionLabel: {
    fontFamily: 'DaysOne_400Regular', fontSize: rs(10),
    color: 'rgba(0,200,255,0.7)', letterSpacing: 2, marginBottom: rs(8),
  },

  rutaCard: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: rs(12),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    padding: rs(12), marginBottom: rs(8), gap: rs(10),
  },
  rutaColorBar: { width: rs(4), height: rs(44), borderRadius: rs(2) },
  rutaInfo:     { flex: 1 },
  rutaNombre:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: '#fff', marginBottom: rs(4) },
  rutaStats:    { flexDirection: 'row', gap: rs(8), flexWrap: 'wrap' },
  rutaStat:     { fontFamily: 'DaysOne_400Regular', fontSize: rs(10), color: 'rgba(255,255,255,0.52)' },
  checkBadge:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(20) },

  btnIniciar:    { borderRadius: rs(14), overflow: 'hidden', marginTop: rs(4), marginBottom: rs(10) },
  btnIniciarGrad: {
    paddingVertical: rs(14), paddingHorizontal: rs(16), alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)', borderRadius: rs(14),
  },
  btnIniciarText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(14), color: '#fff', letterSpacing: 1 },
  btnIniciarSub:  { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.5)', marginTop: rs(4) },

  emptyHint: {
    fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: 'rgba(255,255,255,0.3)',
    textAlign: 'center', marginTop: rs(20), lineHeight: rs(22),
  },

  // Creador
  creadorPanel: { gap: rs(8) },
  nameRow: {
    backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: rs(12),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
    height: rs(44), paddingHorizontal: rs(14), justifyContent: 'center',
  },
  nameInput: { fontFamily: 'DaysOne_400Regular', fontSize: rs(13), color: '#fff' },
  statsRow:  { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: rs(4) },
  statItem:  { alignItems: 'center' },
  statVal:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(17), color: '#00C8FF' },
  statLbl:   { fontFamily: 'DaysOne_400Regular', fontSize: rs(8), color: 'rgba(255,255,255,0.38)', letterSpacing: 1 },
  btnRow:    { flexDirection: 'row', gap: rs(6) },
  btnSec: {
    flex: 1, height: rs(38), borderRadius: rs(10),
    justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
  },
  btnSecText:     { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.62)' },
  btnGuardar: {
    flex: 1.5, height: rs(38), borderRadius: rs(10),
    justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(0,200,255,0.2)',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.45)',
  },
  btnGuardarText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: '#fff' },

  // Guardadas
  savedCard: {
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: rs(12),
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    padding: rs(12), marginBottom: rs(8),
  },
  savedCardActive:  { borderColor: 'rgba(255,165,0,0.6)', backgroundColor: 'rgba(255,165,0,0.07)' },
  savedHeader:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: rs(6) },
  savedNombre:      { fontFamily: 'DaysOne_400Regular', fontSize: rs(14), color: '#fff', flex: 1 },
  savedStats:       { flexDirection: 'row', gap: rs(12), marginBottom: rs(8) },
  savedStat:        { fontFamily: 'DaysOne_400Regular', fontSize: rs(11), color: 'rgba(255,255,255,0.52)' },
  btnIniciarSmall: {
    height: rs(34), borderRadius: rs(8),
    justifyContent: 'center', alignItems: 'center',
    backgroundColor: 'rgba(76,217,100,0.18)',
    borderWidth: 1, borderColor: 'rgba(76,217,100,0.4)',
  },
  btnIniciarSmallText: { fontFamily: 'DaysOne_400Regular', fontSize: rs(12), color: '#4CD964', letterSpacing: 1 },
});

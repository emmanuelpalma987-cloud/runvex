# 🏃 RUNVEX — SDK 55 (versión estable)

## Requisitos
- Node.js v20+ → https://nodejs.org
- Expo Go (última versión) en tu teléfono
- PC y teléfono en la MISMA red WiFi

---

## Pasos exactos

### 1. Extrae el ZIP → entra a la carpeta `runvex`

### 2. Instalar dependencias
```
npm install
```

### 3. Arrancar la app
```
npx expo start --clear
```

### 4. En Expo Go → escanear el QR

---

## Si hay error de dependencias
```
npm install --legacy-peer-deps
```

## Si hay error de caché
```
npx expo start --clear --reset-cache
```

# RUNVEX v11 — SDK 54 FINAL

## Instalación y build

```bash
# 1. Instalar dependencias
npm install --legacy-peer-deps

# 2. Login en Expo (solo primera vez)
npx eas-cli login

# 3. Generar APK
npx eas build --platform android --profile preview
```

## Para probar en el celular sin compilar

```bash
npx expo start
```
Escanea el QR con **Expo Go** (debe ser la versión SDK 54, la más reciente).

## Versiones exactas usadas (SDK 54)

- expo: ~54.0.21
- react: 19.0.0
- react-native: 0.79.6
- expo-router: ~5.1.11
- minSdkVersion: 24 (Android 7.0+)

## Correcciones en v11

- Versiones exactas para SDK 54 (sin warnings de incompatibilidad)
- Eliminado react-native-worklets (causa crash en Gradle)
- minSdkVersion: 24 → compatible con Android 7.0 en adelante
- adaptiveIcon configurado (evita crash en Android 8+)
- Pedómetro: delta relativo desde inicio de carrera
- Acelerómetro: cooldown 260ms, cadencia limitada a 220 ppm
- formatTiempo: muestra HH:MM:SS si la carrera supera 1 hora
- formatPace: devuelve '--:--' si valor inválido o infinito

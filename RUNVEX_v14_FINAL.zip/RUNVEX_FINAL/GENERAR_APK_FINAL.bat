@echo off
chcp 65001 >nul
echo.
echo  RUNVEX — Generando APK para Android
echo ================================================
echo.
echo  Requisitos:
echo  [1] Haber corrido INSTALAR_FINAL.bat
echo  [2] Tener cuenta en expo.dev
echo  [3] Haber hecho login: npx eas-cli login
echo.
pause

echo Iniciando build en EAS...
call npx eas build --platform android --profile preview

if errorlevel 1 (
    echo.
    echo [ERROR] Build fallido. Revisa los logs en https://expo.dev
) else (
    echo.
    echo [OK] Build enviado a EAS.
    echo     Descarga el APK en: https://expo.dev
)
pause

@echo off
chcp 65001 >nul
echo.
echo  ██████╗ ██╗   ██╗███╗   ██╗██╗   ██╗███████╗██╗  ██╗
echo  ██╔══██╗██║   ██║████╗  ██║██║   ██║██╔════╝╚██╗██╔╝
echo  ██████╔╝██║   ██║██╔██╗ ██║██║   ██║█████╗   ╚███╔╝
echo  ██╔══██╗██║   ██║██║╚██╗██║╚██╗ ██╔╝██╔══╝   ██╔██╗
echo  ██║  ██║╚██████╔╝██║ ╚████║ ╚████╔╝ ███████╗██╔╝ ██╗
echo  ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝
echo.
echo  INSTALADOR v12 FINAL
echo ================================================
echo.

node --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js no encontrado. Descarga de https://nodejs.org
    pause & exit /b 1
)
echo [OK] Node.js listo

echo.
echo Limpiando instalacion anterior...
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del package-lock.json

echo.
echo Instalando dependencias (Expo SDK 54)...
call npm install --legacy-peer-deps
if errorlevel 1 (
    echo [ERROR] Fallo npm install
    pause & exit /b 1
)
echo [OK] Dependencias instaladas

npx eas-cli --version >nul 2>&1
if errorlevel 1 (
    echo Instalando EAS CLI...
    call npm install -g eas-cli --legacy-peer-deps
)
echo [OK] EAS CLI listo

echo.
echo ================================================
echo  Instalacion completa.
echo.
echo  Siguiente paso: ejecuta GENERAR_APK_FINAL.bat
echo ================================================
pause

@echo off
echo ===================================================
echo   RUNVEX v9  -  SDK 54
echo ===================================================

echo Limpiando...
if exist node_modules rmdir /s /q node_modules
if exist .expo rmdir /s /q .expo
if exist package-lock.json del package-lock.json

echo Instalando...
npm install --legacy-peer-deps

echo Iniciando...
npx expo start --clear

pause

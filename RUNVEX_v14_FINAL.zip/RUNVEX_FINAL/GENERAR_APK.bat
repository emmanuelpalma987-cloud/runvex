@echo off
echo ===================================================
echo   RUNVEX - Generar APK con EAS Build
echo ===================================================
echo.

echo Paso 1: Limpiar instalacion anterior...
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del package-lock.json

echo.
echo Paso 2: Instalar dependencias limpias...
npm install --legacy-peer-deps

echo.
echo Paso 3: Iniciar sesion en Expo (solo la primera vez)...
eas login

echo.
echo Paso 4: Generar APK con cache limpio...
eas build --platform android --profile preview --clear-cache

echo.
echo ===================================================
echo   Cuando termine, descarga el APK desde:
echo   https://expo.dev/accounts/palma1/projects/runvex
echo ===================================================
pause

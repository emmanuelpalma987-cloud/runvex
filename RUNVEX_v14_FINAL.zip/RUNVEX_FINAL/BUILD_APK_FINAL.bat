@echo off
echo ===================================================
echo   RUNVEX - Generar APK Final
echo ===================================================

echo [1/4] Actualizando dependencias correctas...
npm install --legacy-peer-deps
npx expo install --fix
npx expo install react-native-worklets

echo [2/4] Regenerando carpeta android...
npx expo prebuild --clean

echo [3/4] Build en EAS...
eas build --platform android --clear-cache

echo [4/4] Listo! Descarga el AAB/APK desde expo.dev
pause

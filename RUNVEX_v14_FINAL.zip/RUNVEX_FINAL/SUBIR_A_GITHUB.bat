@echo off
echo ============================================
echo   RUNVEX - Subir a GitHub
echo ============================================
echo.
echo PASO 1: Configura tu usuario de Git
echo (Solo la primera vez en este equipo)
echo.
set /p GIT_USER="Tu nombre de usuario de GitHub: "
set /p GIT_EMAIL="Tu correo de GitHub: "
set /p REPO_URL="URL de tu repositorio (ej: https://github.com/usuario/runvex.git): "

echo.
echo Configurando Git...
git config --global user.name "%GIT_USER%"
git config --global user.email "%GIT_EMAIL%"

echo.
echo Inicializando repositorio local...
git init
git add .
git commit -m "feat: RUNVEX v9 - App de running con React Native + Expo SDK 54"

echo.
echo Conectando con GitHub...
git branch -M main
git remote add origin %REPO_URL%
git push -u origin main

echo.
echo ============================================
echo   Listo! Revisa tu repositorio en GitHub
echo ============================================
pause

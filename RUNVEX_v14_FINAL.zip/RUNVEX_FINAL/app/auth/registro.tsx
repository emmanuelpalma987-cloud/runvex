import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, ImageBackground, SafeAreaView,
  StatusBar, ScrollView, Alert, KeyboardAvoidingView,
  Platform, TextInput, TouchableOpacity, Switch,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { crearUsuario } from '../../src/database/database';
import { getBioInfo, autenticarBiometria, guardarCredencialBio, BioInfo } from '../../src/hooks/useBiometrics';

const BG = require('../../src/assets/images/bg_city.jpg');

const INITIAL = { nombre: '', apellidos: '', correo: '', usuario: '', contrasena: '' };

const FIELDS = [
  { key: 'nombre'    as const, placeholder: 'NOMBRE',     icon: '👤', capitalize: 'words'  as const, maxLength: 40 },
  { key: 'apellidos' as const, placeholder: 'APELLIDOS',  icon: '👥', capitalize: 'words'  as const, maxLength: 60 },
  { key: 'correo'    as const, placeholder: 'CORREO',     icon: '📧', keyboard: 'email-address' as const, maxLength: 80 },
  { key: 'usuario'   as const, placeholder: 'USUARIO',    icon: '🆔', maxLength: 20 },
  { key: 'contrasena'as const, placeholder: 'CONTRASEÑA', icon: '🔑', secure: true, maxLength: 50 },
];

export default function RegistroScreen() {
  const router = useRouter();
  const [form, setForm]     = useState(INITIAL);
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading]   = useState(false);
  const [habilitarBio, setHabilitarBio] = useState(false);
  const [bioInfo, setBioInfo] = useState<BioInfo>({ disponible: false, inscrita: false, tipo: 'none' });
  const refs = useRef<Record<string, TextInput | null>>({});

  useEffect(() => {
    getBioInfo().then(setBioInfo);
  }, []);

  const upd = (k: keyof typeof INITIAL) => (v: string) =>
    setForm(p => ({ ...p, [k]: v }));

  const handleRegister = async () => {
    const { nombre, apellidos, correo, usuario, contrasena } = form;
    if (!nombre.trim() || !apellidos.trim() || !correo.trim() || !usuario.trim() || !contrasena.trim()) {
      Alert.alert('Campos requeridos', 'Completa todos los campos para continuar.');
      return;
    }
    if (!/\S+@\S+\.\S+/.test(correo.trim())) {
      Alert.alert('Correo inválido', 'Ingresa un correo electrónico válido.');
      return;
    }
    if (contrasena.length < 6) {
      Alert.alert('Contraseña corta', 'La contraseña debe tener mínimo 6 caracteres.');
      return;
    }

    // Si quiere biometría, autenticar antes de crear cuenta
    if (habilitarBio && bioInfo.disponible) {
      const ok = await autenticarBiometria('Registra tu biometría para Runvex');
      if (!ok) {
        Alert.alert('Biometría cancelada', 'La cuenta se creará sin biometría. Puedes habilitarla desde tu perfil.');
        setHabilitarBio(false);
      }
    }

    setLoading(true);
    try {
      await crearUsuario(
        nombre.trim(), apellidos.trim(),
        correo.trim().toLowerCase(), usuario.trim(), contrasena
      );

      // Guardar referencia biométrica si fue habilitada
      if (habilitarBio && bioInfo.disponible) {
        await guardarCredencialBio(usuario.trim());
      }

      Alert.alert('¡Cuenta creada!', 'Tu cuenta fue registrada exitosamente.', [
        { text: 'Iniciar sesión', onPress: () => router.replace('/auth/login') },
      ]);
    } catch (e: any) {
      const msg = e.message?.includes('UNIQUE')
        ? 'El correo o usuario ya está registrado.'
        : (e.message ?? 'Error al registrar. Intenta de nuevo.');
      Alert.alert('Error', msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <ImageBackground source={BG} style={s.bg} resizeMode="cover">
        <LinearGradient colors={['rgba(0,5,20,0.35)', 'rgba(0,5,20,0.75)', 'rgba(0,5,20,0.97)']} locations={[0, 0.4, 1]} style={s.overlay}>
          <SafeAreaView style={s.safe}>
            <KeyboardAvoidingView
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
              style={{ flex: 1 }}
            >
              <ScrollView
                contentContainerStyle={s.scroll}
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
              >
                <TouchableOpacity style={s.backBtn} onPress={() => router.back()}>
                  <Text style={s.backText}>← Volver</Text>
                </TouchableOpacity>

                <Text style={s.title}>CREAR CUENTA</Text>
                <Text style={s.subtitle}>Completa todos los campos</Text>

                <View style={s.form}>
                  {FIELDS.map((f, i) => (
                    <View key={f.key} style={s.fieldWrap}>
                      <Text style={s.fieldLabel}>{f.placeholder}:</Text>
                      <View style={s.inputBox}>
                        <Text style={s.inputIcon}>{f.icon}</Text>
                        <TextInput
                          ref={r => { refs.current[f.key] = r; }}
                          style={s.input}
                          placeholder={`Ingresa tu ${f.placeholder.toLowerCase()}`}
                          placeholderTextColor="rgba(255,255,255,0.3)"
                          value={form[f.key]}
                          onChangeText={upd(f.key)}
                          secureTextEntry={f.secure && !showPass}
                          autoCapitalize={f.capitalize ?? 'none'}
                          keyboardType={f.keyboard ?? 'default'}
                          autoCorrect={false}
                          maxLength={f.maxLength}
                          returnKeyType={i < FIELDS.length - 1 ? 'next' : 'done'}
                          onSubmitEditing={() => {
                            if (i < FIELDS.length - 1) {
                              refs.current[FIELDS[i + 1].key]?.focus();
                            } else handleRegister();
                          }}
                          blurOnSubmit={false}
                        />
                        {f.secure && (
                          <TouchableOpacity
                            onPress={() => setShowPass(p => !p)}
                            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                          >
                            <Text style={{ fontSize: 17 }}>{showPass ? '👁️' : '🙈'}</Text>
                          </TouchableOpacity>
                        )}
                      </View>
                    </View>
                  ))}

                  {/* Opción biométrica */}
                  {bioInfo.disponible && (
                    <View style={s.bioRow}>
                      <View style={s.bioInfo}>
                        <Text style={s.bioEmoji}>
                          {bioInfo.tipo === 'face' ? '😊' : '👆'}
                        </Text>
                        <View>
                          <Text style={s.bioTitle}>
                            {bioInfo.tipo === 'face' ? 'Face ID' : 'Huella Digital'}
                          </Text>
                          <Text style={s.bioSub}>Acceso rápido al iniciar sesión</Text>
                        </View>
                      </View>
                      <Switch
                        value={habilitarBio}
                        onValueChange={setHabilitarBio}
                        trackColor={{ false: 'rgba(255,255,255,0.15)', true: 'rgba(0,200,255,0.5)' }}
                        thumbColor={habilitarBio ? '#00C8FF' : 'rgba(255,255,255,0.6)'}
                      />
                    </View>
                  )}

                  <TouchableOpacity
                    style={[s.btnCyan, loading && s.btnDisabled]}
                    onPress={handleRegister}
                    disabled={loading}
                    activeOpacity={0.85}
                  >
                    <LinearGradient
                      colors={['rgba(0,200,255,0.35)', 'rgba(0,200,255,0.12)']}
                      style={s.btnGrad}
                    >
                      <Text style={s.btnText}>{loading ? 'CREANDO...' : 'CREAR CUENTA'}</Text>
                    </LinearGradient>
                  </TouchableOpacity>

                  <TouchableOpacity onPress={() => router.replace('/auth/login')}>
                    <Text style={s.link}>
                      ¿Ya tienes cuenta? <Text style={s.linkAccent}>Inicia sesión</Text>
                    </Text>
                  </TouchableOpacity>
                </View>
              </ScrollView>
            </KeyboardAvoidingView>
          </SafeAreaView>
        </LinearGradient>
      </ImageBackground>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  bg: { flex: 1 },
  overlay: { flex: 1 },
  safe: { flex: 1 },
  scroll: { flexGrow: 1, paddingHorizontal: 28, paddingTop: 20, paddingBottom: 48 },

  backBtn: { marginBottom: 8 },
  backText: { fontFamily: 'DaysOne_400Regular', color: 'rgba(0,200,255,0.7)', fontSize: 13 },

  title: {
    fontFamily: 'Audiowide_400Regular', fontSize: 22, color: '#fff',
    textAlign: 'center', letterSpacing: 3, marginBottom: 4,
    textShadowColor: '#00C8FF', textShadowOffset: { width: 0, height: 0 }, textShadowRadius: 12,
  },
  subtitle: {
    fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.4)',
    textAlign: 'center', letterSpacing: 1, marginBottom: 20,
  },
  form: { gap: 10 },

  fieldWrap: { gap: 3 },
  fieldLabel: {
    fontFamily: 'DaysOne_400Regular', fontSize: 10,
    color: 'rgba(0,200,255,0.8)', letterSpacing: 1.5, marginLeft: 4,
  },
  inputBox: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)',
    height: 50, paddingHorizontal: 14, gap: 10,
  },
  inputIcon: { fontSize: 15 },
  input: { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff' },

  bioRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: 'rgba(0,200,255,0.07)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.25)', padding: 14, marginTop: 4,
  },
  bioInfo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  bioEmoji: { fontSize: 28 },
  bioTitle: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff' },
  bioSub: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(255,255,255,0.45)', marginTop: 2 },

  btnCyan: { borderRadius: 14, overflow: 'hidden', marginTop: 6 },
  btnDisabled: { opacity: 0.5 },
  btnGrad: {
    height: 52, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)', borderRadius: 14,
  },
  btnText: { fontFamily: 'DaysOne_400Regular', fontSize: 17, color: '#fff', letterSpacing: 2 },

  link: {
    fontFamily: 'DaysOne_400Regular', color: 'rgba(255,255,255,0.45)',
    fontSize: 13, textAlign: 'center', marginTop: 4,
  },
  linkAccent: { color: '#00C8FF', textDecorationLine: 'underline' },
});

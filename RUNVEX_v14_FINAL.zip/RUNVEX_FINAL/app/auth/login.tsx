import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ImageBackground, SafeAreaView,
  StatusBar, ScrollView, Alert, KeyboardAvoidingView,
  Platform, TextInput, TouchableOpacity, Image,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { loginUsuario, loginBiometrico, obtenerSesionActiva } from '../../src/database/database';
import { useAuth } from '../../src/hooks/useAuth';
import {
  getBioInfo, autenticarBiometria, leerCredencialBio,
  hayCredencialBio, BioInfo,
} from '../../src/hooks/useBiometrics';

// Imagen local — no requiere internet
const BG = require('../../src/assets/images/bg_runner.jpg');

export default function LoginScreen() {
  const router = useRouter();
  const { setUsuario } = useAuth();

  const [usuarioField, setU]   = useState('');
  const [contrasena,   setC]   = useState('');
  const [loading,  setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);

  const [bioInfo,         setBioInfo]         = useState<BioInfo>({ disponible: false, inscrita: false, tipo: 'none' });
  const [tieneBioReg,     setTieneBioReg]     = useState(false);
  const [fotoPerfil,      setFotoPerfil]      = useState<string | null>(null);
  const [nombreGuardado,  setNombreGuardado]  = useState<string | null>(null);
  const [usuarioGuardado, setUsuarioGuardado] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      // Cargar foto y nombre del último usuario con sesión guardada
      try {
        const sesion = await obtenerSesionActiva();
        if (sesion) {
          setFotoPerfil(sesion.foto_perfil ?? null);
          setNombreGuardado(sesion.nombre ?? null);
          setUsuarioGuardado(sesion.usuario ?? null);
        }
      } catch {}

      const info = await getBioInfo();
      setBioInfo(info);
      if (info.disponible) {
        const hay = await hayCredencialBio();
        setTieneBioReg(hay);
        if (hay) setTimeout(() => handleBiometrico(info), 600);
      }
    })();
  }, []);

  const handleBiometrico = async (info?: BioInfo) => {
    const bi = info ?? bioInfo;
    if (!bi.disponible) {
      Alert.alert('Sin biometría', 'Este dispositivo no tiene biometría configurada.');
      return;
    }
    const ok = await autenticarBiometria('Accede a Runvex');
    if (!ok) return;

    const ref = await leerCredencialBio();
    if (!ref) {
      Alert.alert('Sin cuenta vinculada', 'Primero inicia sesión con contraseña y habilita la biometría en tu perfil.');
      return;
    }
    setLoading(true);
    try {
      const user = await loginBiometrico(ref);
      if (user) {
        setUsuario(user);
        router.replace('/(tabs)/home');
      } else {
        Alert.alert('Error', 'No se encontró la cuenta vinculada.');
      }
    } catch (e: any) {
      Alert.alert('Error', e.message ?? 'Error al iniciar sesión.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    if (!usuarioField.trim() || !contrasena.trim()) {
      Alert.alert('Campos requeridos', 'Ingresa tu usuario y contraseña.');
      return;
    }
    setLoading(true);
    try {
      const user = await loginUsuario(usuarioField.trim(), contrasena);
      if (user) {
        setUsuario(user);
        router.replace('/(tabs)/home');
      } else {
        Alert.alert('Error', 'Usuario o contraseña incorrectos.');
      }
    } catch (e: any) {
      Alert.alert('Error', e.message ?? 'Error al iniciar sesión.');
    } finally {
      setLoading(false);
    }
  };

  const bioLabel = bioInfo.tipo === 'face' ? 'FACE ID' : 'HUELLA DIGITAL';
  const bioEmoji = bioInfo.tipo === 'face' ? '😊' : '👆';
  const inicial  = (nombreGuardado?.[0] ?? usuarioField?.[0] ?? 'R').toUpperCase();

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <ImageBackground source={BG} style={s.bg} resizeMode="cover">
        <LinearGradient colors={['rgba(0,5,20,0.25)', 'rgba(0,5,20,0.70)', 'rgba(0,5,20,0.97)']} locations={[0, 0.45, 1]} style={s.overlay}>
          <SafeAreaView style={s.safe}>
            <KeyboardAvoidingView
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
              style={{ flex: 1 }}
            >
              <ScrollView
                contentContainerStyle={s.scroll}
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
              >

                {/* Avatar con foto de perfil del usuario */}
                <View style={s.avatarWrap}>
                  <LinearGradient
                    colors={['#00C8FF', '#FF6A00', '#00C8FF']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                    style={s.avatarRing}
                  >
                    <View style={s.avatarInner}>
                      {fotoPerfil ? (
                        <Image source={{ uri: fotoPerfil }} style={s.avatarImg} />
                      ) : (
                        <Text style={s.avatarInitial}>{inicial}</Text>
                      )}
                    </View>
                  </LinearGradient>

                  {(nombreGuardado || usuarioGuardado) && (
                    <Text style={s.avatarName}>
                      {nombreGuardado ?? `@${usuarioGuardado}`}
                    </Text>
                  )}
                </View>

                <Text style={s.title}>INICIAR SESIÓN</Text>

                {/* Biometría */}
                {bioInfo.disponible && (
                  <TouchableOpacity
                    style={s.bioPrimary}
                    onPress={() => handleBiometrico()}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={['rgba(0,200,255,0.25)', 'rgba(0,200,255,0.08)']}
                      style={s.bioPrimaryGrad}
                    >
                      <Text style={s.bioPrimaryEmoji}>{bioEmoji}</Text>
                      <View>
                        <Text style={s.bioPrimaryTitle}>{bioLabel}</Text>
                        <Text style={s.bioPrimarySub}>
                          {tieneBioReg ? 'Toca para acceder' : 'Vincula tu cuenta primero'}
                        </Text>
                      </View>
                    </LinearGradient>
                  </TouchableOpacity>
                )}

                <View style={s.separatorRow}>
                  <View style={s.sepLine} />
                  <Text style={s.sepText}>o con contraseña</Text>
                  <View style={s.sepLine} />
                </View>

                <View style={s.form}>
                  <View style={s.inputBox}>
                    <Text style={s.inputIcon}>👤</Text>
                    <TextInput
                      style={s.input}
                      placeholder="USUARIO"
                      placeholderTextColor="rgba(255,255,255,0.35)"
                      value={usuarioField}
                      onChangeText={setU}
                      autoCapitalize="none"
                      autoCorrect={false}
                      returnKeyType="next"
                      maxLength={30}
                    />
                  </View>

                  <View style={s.inputBox}>
                    <Text style={s.inputIcon}>🔒</Text>
                    <TextInput
                      style={s.input}
                      placeholder="CONTRASEÑA"
                      placeholderTextColor="rgba(255,255,255,0.35)"
                      value={contrasena}
                      onChangeText={setC}
                      secureTextEntry={!showPass}
                      returnKeyType="done"
                      onSubmitEditing={handleLogin}
                      maxLength={50}
                    />
                    <TouchableOpacity
                      onPress={() => setShowPass(p => !p)}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                    >
                      <Text style={{ fontSize: 18 }}>{showPass ? '👁️' : '🙈'}</Text>
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity onPress={() => router.push('/auth/recuperar')}>
                    <Text style={s.forgot}>¿Olvidaste tu contraseña?</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[s.btnPrimary, loading && s.btnDisabled]}
                    onPress={handleLogin}
                    disabled={loading}
                    activeOpacity={0.85}
                  >
                    <LinearGradient
                      colors={['rgba(0,200,255,0.35)', 'rgba(0,200,255,0.12)']}
                      style={s.btnGrad}
                    >
                      <Text style={s.btnText}>{loading ? 'VERIFICANDO...' : 'ACCEDER'}</Text>
                    </LinearGradient>
                  </TouchableOpacity>

                  <TouchableOpacity onPress={() => router.push('/auth/registro')}>
                    <Text style={s.link}>
                      ¿No tienes cuenta? <Text style={s.linkAccent}>Regístrate</Text>
                    </Text>
                  </TouchableOpacity>
                </View>

              </ScrollView>
            </KeyboardAvoidingView>
          </SafeAreaView>
        </LinearGradient>
      </ImageBackground>
    </View>
  );
}

const s = StyleSheet.create({
  root:    { flex: 1, backgroundColor: '#000' },
  bg:      { flex: 1 },
  overlay: { flex: 1 },
  safe:    { flex: 1 },
  scroll:  { flexGrow: 1, paddingHorizontal: 28, paddingTop: 24, paddingBottom: 48 },

  avatarWrap: { alignItems: 'center', marginBottom: 16, marginTop: 8 },
  avatarRing: {
    width: 130, height: 130, borderRadius: 65, padding: 3,
    shadowColor: '#00C8FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.9, shadowRadius: 24, elevation: 12,
  },
  avatarInner: {
    flex: 1, borderRadius: 62,
    backgroundColor: 'rgba(0,10,30,0.88)',
    justifyContent: 'center', alignItems: 'center',
    overflow: 'hidden',
  },
  avatarImg:     { width: '100%', height: '100%', borderRadius: 62 },
  avatarInitial: { fontFamily: 'Audiowide_400Regular', fontSize: 46, color: '#00C8FF' },
  avatarName: {
    fontFamily: 'DaysOne_400Regular', fontSize: 13,
    color: 'rgba(255,255,255,0.75)', marginTop: 8, letterSpacing: 1,
  },

  title: {
    fontFamily: 'DaysOne_400Regular', fontSize: 20, color: '#fff',
    textAlign: 'center', letterSpacing: 3, marginBottom: 20,
  },

  bioPrimary:     { borderRadius: 16, overflow: 'hidden', marginBottom: 8, borderWidth: 1, borderColor: 'rgba(0,200,255,0.4)' },
  bioPrimaryGrad: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 14 },
  bioPrimaryEmoji:{ fontSize: 36 },
  bioPrimaryTitle:{ fontFamily: 'DaysOne_400Regular', fontSize: 16, color: '#00C8FF', letterSpacing: 1 },
  bioPrimarySub:  { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 2 },

  separatorRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 14 },
  sepLine:      { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.12)' },
  sepText:      { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.35)' },

  form:     { gap: 12 },
  inputBox: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)',
    height: 52, paddingHorizontal: 16, gap: 10,
  },
  inputIcon: { fontSize: 16 },
  input:     { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: 15, color: '#fff' },

  forgot:     { fontFamily: 'DaysOne_400Regular', color: 'rgba(0,200,255,0.7)', fontSize: 12, textAlign: 'right', textDecorationLine: 'underline' },
  btnPrimary: { borderRadius: 14, overflow: 'hidden' },
  btnDisabled:{ opacity: 0.5 },
  btnGrad:    { height: 52, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)', borderRadius: 14 },
  btnText:    { fontFamily: 'DaysOne_400Regular', fontSize: 17, color: '#fff', letterSpacing: 2 },

  link:       { fontFamily: 'DaysOne_400Regular', color: 'rgba(255,255,255,0.45)', fontSize: 13, textAlign: 'center' },
  linkAccent: { color: '#00C8FF', textDecorationLine: 'underline' },
});

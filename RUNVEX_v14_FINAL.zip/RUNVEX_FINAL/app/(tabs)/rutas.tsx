import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView,
  Alert, TextInput, ActivityIndicator, StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Polyline } from 'react-native-maps';
import * as Location from 'expo-location';
import { useFocusEffect, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../src/hooks/useAuth';
import { guardarRuta, obtenerRutas, eliminarRuta } from '../../src/database/database';

interface Coord { latitude: number; longitude: number; }
interface RutaOpcion { nombre: string; color: string; puntos: Coord[]; distM: number; minutos: number; }
interface Sugerencia { nombre: string; coord: Coord; tipo: string; }

// ─── Helpers ──────────────────────────────────────────────────────────────────
function haversineM(a: Coord, b: Coord): number {
  const R = 6371000;
  const dLat = (b.latitude - a.latitude) * Math.PI / 180;
  const dLon = (b.longitude - a.longitude) * Math.PI / 180;
  const x = Math.sin(dLat / 2) ** 2 +
    Math.cos(a.latitude * Math.PI / 180) * Math.cos(b.latitude * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function fmtDist(m: number) {
  return m >= 1000 ? `${(m / 1000).toFixed(2)} km` : `${Math.round(m)} m`;
}

function distanciaKm(a: Coord, b: Coord) {
  return haversineM(a, b) / 1000;
}

// ─── Decodificar polyline de OSRM ────────────────────────────────────────────
function decodePolyline(encoded: string): Coord[] {
  const result: Coord[] = [];
  let index = 0, lat = 0, lng = 0;
  while (index < encoded.length) {
    let b, shift = 0, result2 = 0;
    do { b = encoded.charCodeAt(index++) - 63; result2 |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lat += (result2 & 1) ? ~(result2 >> 1) : (result2 >> 1);
    shift = 0; result2 = 0;
    do { b = encoded.charCodeAt(index++) - 63; result2 |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lng += (result2 & 1) ? ~(result2 >> 1) : (result2 >> 1);
    result.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
  }
  return result;
}

// ─── Rutas reales por calles via OSRM (gratuito) ─────────────────────────────
async function fetchRutasReales(origen: Coord, destino: Coord): Promise<RutaOpcion[]> {
  try {
    const url = `https://router.project-osrm.org/route/v1/foot/${origen.longitude},${origen.latitude};${destino.longitude},${destino.latitude}?alternatives=true&geometries=polyline&overview=full&steps=false`;
    const res = await fetch(url, { headers: { 'User-Agent': 'RunvexApp/1.0' } });
    const data = await res.json();
    if (!data.routes || data.routes.length === 0) return [];
    const colores = ['#00C8FF', '#4CD964', '#FF9500'];
    const nombres = ['Ruta Principal', 'Ruta Alternativa', 'Ruta Escénica'];
    return data.routes.slice(0, 3).map((route: any, i: number) => {
      const pts = decodePolyline(route.geometry);
      const distM = route.distance;
      const minutos = Math.round(route.duration / 60);
      return { nombre: nombres[i] ?? `Ruta ${i + 1}`, color: colores[i] ?? '#fff', puntos: pts, distM, minutos };
    });
  } catch { return []; }
}

// ─── Búsqueda de lugares cercanos (Nominatim, sin API key) ───────────────────
async function buscarLugaresCercanos(query: string, cerca: Coord): Promise<Sugerencia[]> {
  try {
    // Calcular viewbox de 15 km alrededor del usuario
    const delta = 0.15; // ~15 km
    const viewbox = `${cerca.longitude - delta},${cerca.latitude - delta},${cerca.longitude + delta},${cerca.latitude + delta}`;
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=8&countrycodes=mx&viewbox=${viewbox}&bounded=1&lat=${cerca.latitude}&lon=${cerca.longitude}`;
    const res = await fetch(url, { headers: { 'User-Agent': 'RunvexApp/1.0' } });
    const data = await res.json();
    if (!data || data.length === 0) return [];
    // Filtrar solo resultados dentro de 20 km
    return data
      .map((item: any) => ({
        nombre: item.display_name.split(',').slice(0, 3).join(', '),
        coord: { latitude: parseFloat(item.lat), longitude: parseFloat(item.lon) },
        tipo: item.type ?? 'lugar',
        distKm: distanciaKm(cerca, { latitude: parseFloat(item.lat), longitude: parseFloat(item.lon) }),
      }))
      .filter((s: any) => s.distKm <= 20)
      .sort((a: any, b: any) => a.distKm - b.distKm)
      .slice(0, 6);
  } catch { return []; }
}

// ─── Pantalla ─────────────────────────────────────────────────────────────────
type Modo = 'buscar' | 'crear' | 'guardadas';

export default function RutasScreen() {
  const { usuario } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const mapRef = useRef<MapView>(null);

  const [modo, setModo] = useState<Modo>('buscar');
  const [miPos, setMiPos] = useState<Coord>({ latitude: 19.2869, longitude: -99.6531 });
  const [region, setRegion] = useState({ latitude: 19.2869, longitude: -99.6531, latitudeDelta: 0.015, longitudeDelta: 0.015 });
  const [buscando, setBuscando] = useState(false);
  const [destino, setDestino] = useState('');
  const [sugerencias, setSugerencias] = useState<Sugerencia[]>([]);
  const [showSugerencias, setShowSugerencias] = useState(false);
  const [rutasOpciones, setRutasOpciones] = useState<RutaOpcion[]>([]);
  const [rutaSeleccionada, setRutaSeleccionada] = useState(0);
  const [destinoCoord, setDestinoCoord] = useState<Coord | null>(null);
  const [puntos, setPuntos] = useState<Coord[]>([]);
  const [nombreRuta, setNombreRuta] = useState('');
  const [rutasGuardadas, setRutasGuardadas] = useState<any[]>([]);
  const [rutaVista, setRutaVista] = useState<any | null>(null);
  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  useFocusEffect(useCallback(() => { loadRutas(); }, [usuario]));

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const pos = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
        setMiPos(pos);
        setRegion({ ...pos, latitudeDelta: 0.015, longitudeDelta: 0.015 });
      }
    })();
  }, []);

  // Autocompletar con debounce
  const onChangeDestino = (text: string) => {
    setDestino(text);
    setRutasOpciones([]);
    setDestinoCoord(null);
    if (searchTimeout.current) clearTimeout(searchTimeout.current);
    if (text.length < 3) { setSugerencias([]); setShowSugerencias(false); return; }
    searchTimeout.current = setTimeout(async () => {
      const sugs = await buscarLugaresCercanos(text, miPos);
      setSugerencias(sugs);
      setShowSugerencias(sugs.length > 0);
    }, 500);
  };

  const seleccionarSugerencia = async (sug: Sugerencia) => {
    setDestino(sug.nombre);
    setShowSugerencias(false);
    setSugerencias([]);
    await calcularRutas(sug.coord);
  };

  const calcularRutas = async (coord: Coord) => {
    setBuscando(true);
    setDestinoCoord(coord);
    try {
      const opciones = await fetchRutasReales(miPos, coord);
      if (opciones.length === 0) {
        Alert.alert('Sin rutas', 'No se encontraron rutas por calles a ese destino.\nVerifica que el destino sea accesible a pie.');
        return;
      }
      setRutasOpciones(opciones);
      setRutaSeleccionada(0);
      // Ajustar mapa para ver toda la ruta
      const allPts = opciones[0].puntos;
      const lats = allPts.map(p => p.latitude);
      const lons = allPts.map(p => p.longitude);
      mapRef.current?.animateToRegion({
        latitude: (Math.max(...lats) + Math.min(...lats)) / 2,
        longitude: (Math.max(...lons) + Math.min(...lons)) / 2,
        latitudeDelta: (Math.max(...lats) - Math.min(...lats)) * 1.6 + 0.005,
        longitudeDelta: (Math.max(...lons) - Math.min(...lons)) * 1.6 + 0.005,
      }, 900);
    } finally { setBuscando(false); }
  };

  const handleBuscar = async () => {
    if (!destino.trim()) return;
    setShowSugerencias(false);
    const sugs = await buscarLugaresCercanos(destino.trim(), miPos);
    if (sugs.length === 0) {
      Alert.alert('No encontrado', `No se encontró "${destino}" cerca de tu ubicación.\n\nSugerencias:\n• Escribe el nombre de un parque, colonia o calle\n• Asegúrate de estar en México`);
      return;
    }
    await calcularRutas(sugs[0].coord);
    setDestino(sugs[0].nombre);
  };

  const handleIniciarRuta = async () => {
    const ruta = rutasOpciones[rutaSeleccionada];
    if (!ruta) return;
    Alert.alert(`Iniciar ${ruta.nombre}`,
      `Distancia: ${fmtDist(ruta.distM)}\nTiempo estimado: ~${ruta.minutos} min\n\n¿Guardar y empezar esta ruta?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Guardar e Iniciar', onPress: async () => {
          if (usuario?.id) await guardarRuta(usuario.id, ruta.nombre, ruta.distM / 1000, ruta.minutos, ruta.puntos);
          router.push('/(tabs)/carrera');
        }},
      ]);
  };

  const loadRutas = async () => {
    if (usuario?.id) {
      const r = await obtenerRutas(usuario.id).catch(() => []);
      setRutasGuardadas(r);
    }
  };

  const handleGuardarCreada = async () => {
    if (puntos.length < 2) { Alert.alert('Ruta incompleta', 'Agrega al menos 2 puntos.'); return; }
    const nombre = nombreRuta.trim() || `Mi ruta ${rutasGuardadas.length + 1}`;
    let distM = 0;
    for (let i = 1; i < puntos.length; i++) distM += haversineM(puntos[i - 1], puntos[i]);
    if (usuario?.id) {
      await guardarRuta(usuario.id, nombre, distM / 1000, Math.round(distM / 1000 / 9 * 60), puntos);
      Alert.alert('✅ Guardada', `"${nombre}" guardada.`);
      setPuntos([]); setNombreRuta(''); loadRutas();
    }
  };

  const verRutaGuardada = (ruta: any) => {
    const coords: Coord[] = JSON.parse(ruta.coordenadas_json);
    setRutaVista(ruta);
    if (coords.length > 0) {
      const lats = coords.map((c: Coord) => c.latitude);
      const lons = coords.map((c: Coord) => c.longitude);
      mapRef.current?.animateToRegion({
        latitude: (Math.max(...lats) + Math.min(...lats)) / 2,
        longitude: (Math.max(...lons) + Math.min(...lons)) / 2,
        latitudeDelta: (Math.max(...lats) - Math.min(...lats)) * 1.8 + 0.005,
        longitudeDelta: (Math.max(...lons) - Math.min(...lons)) * 1.8 + 0.005,
      }, 600);
    }
  };

  const rutaActual = modo === 'buscar' && rutasOpciones.length > 0 ? rutasOpciones[rutaSeleccionada] : null;
  const MODOS: { key: Modo; label: string }[] = [
    { key: 'buscar', label: '🔍 Buscar' },
    { key: 'crear', label: '✏️ Dibujar' },
    { key: 'guardadas', label: '📋 Guardadas' },
  ];

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />
      <LinearGradient colors={['#050A15', '#0A1020']} style={s.bg}>

        <View style={[s.headerWrap, { paddingTop: insets.top + 8 }]}>
          <Text style={s.title}>Rutas</Text>
          <View style={s.modeRow}>
            {MODOS.map(m => (
              <TouchableOpacity key={m.key} style={[s.modeBtn, modo === m.key && s.modeBtnActive]}
                onPress={() => { setModo(m.key); setRutaVista(null); setShowSugerencias(false); }}>
                <Text style={[s.modeBtnText, modo === m.key && s.modeBtnTextActive]}>{m.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* MAPA */}
        <View style={s.mapWrap}>
          <MapView ref={mapRef} style={s.map} provider={undefined}
            region={region} mapType="standard" showsUserLocation
            onPress={(e) => { if (modo === 'crear') setPuntos(prev => [...prev, e.nativeEvent.coordinate]); }}>

            {modo === 'buscar' && rutasOpciones.map((r, i) => (
              <Polyline key={i} coordinates={r.puntos}
                strokeColor={i === rutaSeleccionada ? r.color : `${r.color}44`}
                strokeWidth={i === rutaSeleccionada ? 5 : 2} />
            ))}
            {modo === 'buscar' && destinoCoord && (
              <Marker coordinate={destinoCoord} title="Destino" pinColor="#FF3B30" />
            )}
            {modo === 'crear' && puntos.length > 1 && (
              <Polyline coordinates={puntos} strokeColor="#00C8FF" strokeWidth={4} />
            )}
            {modo === 'crear' && puntos.map((p, i) => (
              <Marker key={i} coordinate={p} pinColor={i === 0 ? '#4CD964' : '#00C8FF'} />
            ))}
            {modo === 'guardadas' && rutaVista && (() => {
              const coords: Coord[] = JSON.parse(rutaVista.coordenadas_json);
              return <Polyline coordinates={coords} strokeColor="#FF9500" strokeWidth={4} />;
            })()}
          </MapView>

          {modo === 'crear' && (
            <View style={s.mapHint}>
              <Text style={s.mapHintText}>
                {puntos.length === 0 ? '📍 Toca el mapa para dibujar tu ruta'
                  : `${puntos.length} puntos · ${fmtDist(puntos.reduce((acc, p, i) => i === 0 ? 0 : acc + haversineM(puntos[i - 1], p), 0))}`}
              </Text>
            </View>
          )}
        </View>

        {/* PANEL INFERIOR */}
        <View style={[s.panel, { paddingBottom: insets.bottom + 8 }]}>

          {/* MODO BUSCAR */}
          {modo === 'buscar' && (
            <View style={{ flex: 1 }}>
              {/* Buscador */}
              <View style={s.searchRow}>
                <View style={s.searchBox}>
                  <Text style={s.searchIcon}>🔍</Text>
                  <TextInput style={s.searchInput}
                    placeholder="Buscar lugar cercano..."
                    placeholderTextColor="rgba(255,255,255,0.35)"
                    value={destino} onChangeText={onChangeDestino}
                    onSubmitEditing={handleBuscar} returnKeyType="search" autoCorrect={false} />
                  {destino.length > 0 && (
                    <TouchableOpacity onPress={() => { setDestino(''); setRutasOpciones([]); setDestinoCoord(null); setSugerencias([]); setShowSugerencias(false); }}>
                      <Text style={{ color: 'rgba(255,255,255,0.5)', fontSize: 16 }}>✕</Text>
                    </TouchableOpacity>
                  )}
                </View>
                <TouchableOpacity style={[s.searchBtn, buscando && { opacity: 0.5 }]}
                  onPress={handleBuscar} disabled={buscando}>
                  {buscando ? <ActivityIndicator color="#fff" size="small" />
                    : <Text style={s.searchBtnText}>IR</Text>}
                </TouchableOpacity>
              </View>

              {/* Sugerencias autocomplete */}
              {showSugerencias && (
                <View style={s.sugerenciasBox}>
                  {sugerencias.map((sug, i) => (
                    <TouchableOpacity key={i} style={s.sugerenciaItem}
                      onPress={() => seleccionarSugerencia(sug)}>
                      <Text style={s.sugerenciaIcon}>📍</Text>
                      <Text style={s.sugerenciaText} numberOfLines={2}>{sug.nombre}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )}

              {/* Rutas encontradas */}
              {!showSugerencias && rutasOpciones.length > 0 && (
                <ScrollView showsVerticalScrollIndicator={false}>
                  <Text style={s.sectionLabel}>RUTAS POR CALLES REALES</Text>
                  {rutasOpciones.map((r, i) => {
                    const sel = i === rutaSeleccionada;
                    return (
                      <TouchableOpacity key={i}
                        style={[s.rutaOpcion, sel && { borderColor: r.color, backgroundColor: `${r.color}14` }]}
                        onPress={() => setRutaSeleccionada(i)} activeOpacity={0.8}>
                        <View style={[s.rutaOpcionDot, { backgroundColor: r.color }]} />
                        <View style={s.rutaOpcionInfo}>
                          <Text style={[s.rutaOpcionNombre, sel && { color: r.color }]}>{r.nombre}</Text>
                          <View style={s.rutaOpcionStats}>
                            <Text style={s.rutaOpcionStat}>📍 {fmtDist(r.distM)}</Text>
                            <Text style={s.rutaOpcionStat}>⏱️ ~{r.minutos} min</Text>
                          </View>
                        </View>
                        {sel && <View style={s.rutaOpcionCheck}><Text style={{ color: r.color, fontFamily: 'DaysOne_400Regular', fontSize: 11 }}>✓</Text></View>}
                      </TouchableOpacity>
                    );
                  })}
                  <TouchableOpacity style={s.btnIniciarRuta} onPress={handleIniciarRuta}>
                    <LinearGradient colors={['rgba(0,200,255,0.3)', 'rgba(0,200,255,0.1)']} style={s.btnIniciarGrad}>
                      <Text style={s.btnIniciarText}>🏃 INICIAR ESTA RUTA</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </ScrollView>
              )}

              {!showSugerencias && rutasOpciones.length === 0 && !buscando && (
                <View style={s.emptyHint}>
                  <Text style={s.emptyEmoji}>🗺️</Text>
                  <Text style={s.emptyTitle}>Busca tu destino</Text>
                  <Text style={s.emptyText}>Escribe el nombre de un parque, colonia, calle o lugar. Las rutas se calculan por calles reales.</Text>
                </View>
              )}
            </View>
          )}

          {/* MODO CREAR */}
          {modo === 'crear' && (
            <View style={{ flex: 1 }}>
              <TextInput style={s.nombreInput}
                placeholder="Nombre de la ruta (opcional)"
                placeholderTextColor="rgba(255,255,255,0.35)"
                value={nombreRuta} onChangeText={setNombreRuta} />
              <View style={s.botonesCrear}>
                {puntos.length > 0 && (
                  <TouchableOpacity style={s.btnCrearAcc} onPress={() => setPuntos(p => p.slice(0, -1))}>
                    <Text style={s.btnCrearAccTxt}>↩ Deshacer</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity style={[s.btnCrearAcc, { backgroundColor: 'rgba(76,217,100,0.2)', borderColor: 'rgba(76,217,100,0.5)' }]}
                  onPress={handleGuardarCreada}>
                  <Text style={[s.btnCrearAccTxt, { color: '#4CD964' }]}>💾 Guardar</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* MODO GUARDADAS */}
          {modo === 'guardadas' && (
            <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
              {rutasGuardadas.length === 0 ? (
                <View style={s.emptyHint}>
                  <Text style={s.emptyEmoji}>📋</Text>
                  <Text style={s.emptyTitle}>Sin rutas guardadas</Text>
                  <Text style={s.emptyText}>Busca un destino o dibuja tu ruta y guárdala aquí.</Text>
                </View>
              ) : rutasGuardadas.map((ruta, i) => (
                <View key={i} style={s.rutaGuardadaCard}>
                  <TouchableOpacity style={{ flex: 1 }} onPress={() => verRutaGuardada(ruta)}>
                    <Text style={s.rutaGuardadaNombre}>{ruta.nombre}</Text>
                    <Text style={s.rutaGuardadaStats}>
                      📍 {ruta.distancia_km.toFixed(2)} km  ·  ⏱️ ~{ruta.tiempo_estimado_min} min
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => Alert.alert('Eliminar', `¿Eliminar "${ruta.nombre}"?`, [
                    { text: 'Cancelar', style: 'cancel' },
                    { text: 'Eliminar', style: 'destructive', onPress: async () => { await eliminarRuta(ruta.id); loadRutas(); } },
                  ])}>
                    <Text style={{ fontSize: 18, color: 'rgba(255,59,48,0.8)', paddingHorizontal: 8 }}>🗑️</Text>
                  </TouchableOpacity>
                  {rutaVista?.id === ruta.id && (
                    <TouchableOpacity style={s.btnIniciarGuardada}
                      onPress={() => Alert.alert(`Iniciar ${ruta.nombre}`,
                        `${ruta.distancia_km.toFixed(2)} km · ~${ruta.tiempo_estimado_min} min\n\n¿Empezar esta ruta?`,
                        [{ text: 'Cancelar', style: 'cancel' }, { text: 'Iniciar', onPress: () => router.push('/(tabs)/carrera') }])}>
                      <Text style={s.btnIniciarGuardadaTxt}>▶ Iniciar</Text>
                    </TouchableOpacity>
                  )}
                </View>
              ))}
            </ScrollView>
          )}
        </View>
      </LinearGradient>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#050A15' },
  bg: { flex: 1 },
  headerWrap: { paddingHorizontal: 14, paddingBottom: 8 },
  title: { fontFamily: 'DaysOne_400Regular', fontSize: 20, color: '#fff', textAlign: 'center', marginBottom: 8 },
  modeRow: { flexDirection: 'row', gap: 8 },
  modeBtn: { flex: 1, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.07)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', justifyContent: 'center', alignItems: 'center' },
  modeBtnActive: { backgroundColor: 'rgba(0,200,255,0.15)', borderColor: 'rgba(0,200,255,0.5)' },
  modeBtnText: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.5)' },
  modeBtnTextActive: { color: '#00C8FF' },
  mapWrap: { height: 210, marginHorizontal: 12, borderRadius: 16, overflow: 'hidden', position: 'relative' },
  map: { flex: 1 },
  mapHint: { position: 'absolute', bottom: 8, left: 8, right: 8, backgroundColor: 'rgba(0,0,0,0.72)', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 5, alignItems: 'center' },
  mapHintText: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: '#00C8FF' },
  panel: { flex: 1, paddingHorizontal: 14, paddingTop: 10 },
  searchRow: { flexDirection: 'row', gap: 8, marginBottom: 6 },
  searchBox: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)', height: 46, paddingHorizontal: 12, gap: 8 },
  searchIcon: { fontSize: 15 },
  searchInput: { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff' },
  searchBtn: { width: 54, height: 46, borderRadius: 12, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,200,255,0.25)', borderWidth: 1, borderColor: 'rgba(0,200,255,0.5)' },
  searchBtnText: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff', letterSpacing: 1 },
  sugerenciasBox: { backgroundColor: 'rgba(10,16,32,0.98)', borderRadius: 12, borderWidth: 1, borderColor: 'rgba(0,200,255,0.25)', marginBottom: 8, overflow: 'hidden' },
  sugerenciaItem: { flexDirection: 'row', alignItems: 'center', padding: 10, gap: 8, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.06)' },
  sugerenciaIcon: { fontSize: 14 },
  sugerenciaText: { flex: 1, fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.85)' },
  sectionLabel: { fontFamily: 'DaysOne_400Regular', fontSize: 10, color: 'rgba(0,200,255,0.7)', letterSpacing: 2, marginBottom: 8 },
  rutaOpcion: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', padding: 12, marginBottom: 8, gap: 10 },
  rutaOpcionDot: { width: 10, height: 10, borderRadius: 5 },
  rutaOpcionInfo: { flex: 1 },
  rutaOpcionNombre: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff', marginBottom: 4 },
  rutaOpcionStats: { flexDirection: 'row', gap: 12 },
  rutaOpcionStat: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.5)' },
  rutaOpcionCheck: { width: 22, height: 22, borderRadius: 11, backgroundColor: 'rgba(0,200,255,0.15)', justifyContent: 'center', alignItems: 'center' },
  btnIniciarRuta: { borderRadius: 12, overflow: 'hidden', marginTop: 4 },
  btnIniciarGrad: { height: 46, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(0,200,255,0.4)', borderRadius: 12 },
  btnIniciarText: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff', letterSpacing: 1 },
  emptyHint: { alignItems: 'center', paddingVertical: 20, gap: 8 },
  emptyEmoji: { fontSize: 36 },
  emptyTitle: { fontFamily: 'DaysOne_400Regular', fontSize: 14, color: '#fff' },
  emptyText: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.4)', textAlign: 'center', lineHeight: 16 },
  nombreInput: { backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)', height: 44, paddingHorizontal: 14, fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff', marginBottom: 10 },
  botonesCrear: { flexDirection: 'row', gap: 10 },
  btnCrearAcc: { flex: 1, height: 42, borderRadius: 12, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(255,59,48,0.15)', borderWidth: 1, borderColor: 'rgba(255,59,48,0.4)' },
  btnCrearAccTxt: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#FF3B30' },
  rutaGuardadaCard: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)', padding: 12, marginBottom: 8, flexDirection: 'row', alignItems: 'center' },
  rutaGuardadaNombre: { fontFamily: 'DaysOne_400Regular', fontSize: 13, color: '#fff', marginBottom: 4 },
  rutaGuardadaStats: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: 'rgba(255,255,255,0.5)' },
  btnIniciarGuardada: { backgroundColor: 'rgba(0,200,255,0.2)', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, borderWidth: 1, borderColor: 'rgba(0,200,255,0.4)' },
  btnIniciarGuardadaTxt: { fontFamily: 'DaysOne_400Regular', fontSize: 11, color: '#00C8FF' },
});

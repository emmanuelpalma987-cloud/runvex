/**
 * LeafletMap.tsx — Mapa WebView con Leaflet + OpenStreetMap
 * Sin API key, sin Google Maps, 100% gratis.
 * Drop-in replacement para react-native-maps en RUNVEX.
 */
import React, {
  forwardRef, useCallback, useEffect, useImperativeHandle, useRef,
} from 'react';
import { StyleSheet } from 'react-native';
import WebView from 'react-native-webview';

// ─── Tipos públicos ────────────────────────────────────────────────────────────

export interface MapRegion {
  latitude: number;
  longitude: number;
  latitudeDelta: number;
  longitudeDelta: number;
}

export interface MapCoord {
  latitude: number;
  longitude: number;
}

export interface MapPolyline {
  coordinates: MapCoord[];
  strokeColor?: string;
  strokeWidth?: number;
  strokeDashPattern?: number[];
}

export interface MapMarker {
  coordinate: MapCoord;
  pinColor?: string;
  title?: string;
}

export interface LeafletMapHandle {
  animateToRegion: (region: MapRegion, duration?: number) => void;
}

interface LeafletMapProps {
  region: MapRegion;
  showsUserLocation?: boolean;
  followsUserLocation?: boolean;
  userLocation?: MapCoord | null;
  polylines?: MapPolyline[];
  markers?: MapMarker[];
  onPress?: (coord: MapCoord) => void;
  style?: object;
}

// ─── HTML de Leaflet (auto-contenido) ─────────────────────────────────────────

const LEAFLET_HTML = `<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
  *{box-sizing:border-box;margin:0;padding:0;}
  body,html{background:#050A15;width:100%;height:100%;}
  #map{width:100%;height:100vh;}
  .leaflet-tile-pane{filter:brightness(0.92) saturate(0.85);}
  .leaflet-control-attribution{display:none;}
  .user-dot{
    width:16px;height:16px;
    background:#00C8FF;border:3px solid #fff;border-radius:50%;
    box-shadow:0 0 0 4px rgba(0,200,255,0.25);
  }
</style>
</head>
<body>
<div id="map"></div>
<script>
(function(){
  var map = L.map('map',{
    zoomControl:false, attributionControl:false, tap:true
  }).setView([19.2869,-99.6531],15);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
    maxZoom:19, subdomains:['a','b','c']
  }).addTo(map);

  var userMarker=null, polylines=[], markers=[], followUser=false;

  // Tap / click → enviar al RN
  map.on('click',function(e){
    if(window.ReactNativeWebView){
      window.ReactNativeWebView.postMessage(JSON.stringify({
        type:'press', lat:e.latlng.lat, lng:e.latlng.lng
      }));
    }
  });

  // Delta → zoom aproximado
  function deltaToZoom(delta){
    var z = Math.round(Math.log2(360/Math.max(delta,0.001)))-1;
    return Math.max(10,Math.min(18,z));
  }

  // Color con opacidad (soporta #rrggbbaa y rgba(...))
  function parseColor(c){
    if(!c) return {color:'#00C8FF',opacity:1};
    if(c.startsWith('rgba')){
      var m=c.match(/rgba\((\d+),(\d+),(\d+),([\d.]+)\)/);
      if(m) return {color:'rgb('+m[1]+','+m[2]+','+m[3]+')',opacity:parseFloat(m[4])};
    }
    if(c.startsWith('#')&&c.length===9){
      var alpha=parseInt(c.slice(7,9),16)/255;
      return {color:c.slice(0,7),opacity:alpha};
    }
    return {color:c,opacity:1};
  }

  window.handleMessage=function(msg){
    switch(msg.type){

      case 'setRegion':
        map.setView([msg.region.latitude,msg.region.longitude],
          deltaToZoom(msg.region.latitudeDelta));
        break;

      case 'animateToRegion':
        map.flyTo([msg.region.latitude,msg.region.longitude],
          deltaToZoom(msg.region.latitudeDelta),
          {duration:(msg.duration||500)/1000, easeLinearity:0.5});
        break;

      case 'setFollow':
        followUser=!!msg.follow;
        break;

      case 'updateUser':
        var latlng=[msg.lat,msg.lng];
        if(!userMarker){
          var icon=L.divIcon({className:'',
            html:'<div class="user-dot"></div>',
            iconSize:[16,16],iconAnchor:[8,8]});
          userMarker=L.marker(latlng,{icon:icon,zIndexOffset:2000}).addTo(map);
        } else {
          userMarker.setLatLng(latlng);
        }
        if(followUser) map.panTo(latlng,{animate:true,duration:0.4});
        break;

      case 'setPolylines':
        polylines.forEach(function(p){map.removeLayer(p);});
        polylines=[];
        (msg.polylines||[]).forEach(function(pl){
          if(!pl.coordinates||pl.coordinates.length<2) return;
          var latlngs=pl.coordinates.map(function(c){return [c.latitude,c.longitude];});
          var pc=parseColor(pl.strokeColor);
          var opts={color:pc.color,opacity:pc.opacity,weight:pl.strokeWidth||3,lineJoin:'round',lineCap:'round'};
          if(pl.strokeDashPattern&&pl.strokeDashPattern.length>=2)
            opts.dashArray=pl.strokeDashPattern.join(' ');
          polylines.push(L.polyline(latlngs,opts).addTo(map));
        });
        break;

      case 'setMarkers':
        markers.forEach(function(m){map.removeLayer(m);});
        markers=[];
        (msg.markers||[]).forEach(function(mk){
          var color=mk.pinColor||'#FF3B30';
          var icon=L.divIcon({className:'',
            html:'<div style="width:14px;height:14px;background:'+color+
              ';border:2px solid #fff;border-radius:50%;box-shadow:0 1px 4px rgba(0,0,0,0.5);"></div>',
            iconSize:[14,14],iconAnchor:[7,7]});
          var m=L.marker([mk.coordinate.latitude,mk.coordinate.longitude],{icon:icon});
          if(mk.title) m.bindTooltip(mk.title,{permanent:false,direction:'top'});
          m.addTo(map);
          markers.push(m);
        });
        break;
    }
  };
})();
</script>
</body>
</html>`;

// ─── Componente ───────────────────────────────────────────────────────────────

const LeafletMap = forwardRef<LeafletMapHandle, LeafletMapProps>((props, ref) => {
  const webRef = useRef<WebView>(null);
  const isReady = useRef(false);
  const queue = useRef<object[]>([]);

  const send = useCallback((msg: object) => {
    const js = `window.handleMessage(${JSON.stringify(msg)}); true;`;
    if (isReady.current) {
      webRef.current?.injectJavaScript(js);
    } else {
      queue.current.push(msg);
    }
  }, []);

  useImperativeHandle(ref, () => ({
    animateToRegion: (region, duration = 500) =>
      send({ type: 'animateToRegion', region, duration }),
  }));

  // Sincronizar props con el mapa
  useEffect(() => { send({ type: 'setRegion', region: props.region }); }, [props.region]);
  useEffect(() => { send({ type: 'setPolylines', polylines: props.polylines ?? [] }); }, [props.polylines]);
  useEffect(() => { send({ type: 'setMarkers', markers: props.markers ?? [] }); }, [props.markers]);
  useEffect(() => { send({ type: 'setFollow', follow: !!props.followsUserLocation }); }, [props.followsUserLocation]);
  useEffect(() => {
    if (props.userLocation) {
      send({ type: 'updateUser', lat: props.userLocation.latitude, lng: props.userLocation.longitude });
    }
  }, [props.userLocation]);

  const onLoadEnd = useCallback(() => {
    isReady.current = true;
    // Vaciar cola
    queue.current.forEach(msg => {
      webRef.current?.injectJavaScript(`window.handleMessage(${JSON.stringify(msg)}); true;`);
    });
    queue.current = [];
    // Estado inicial
    send({ type: 'setRegion', region: props.region });
    send({ type: 'setPolylines', polylines: props.polylines ?? [] });
    send({ type: 'setMarkers', markers: props.markers ?? [] });
    send({ type: 'setFollow', follow: !!props.followsUserLocation });
    if (props.userLocation) {
      send({ type: 'updateUser', lat: props.userLocation.latitude, lng: props.userLocation.longitude });
    }
  }, []); // solo se ejecuta una vez al montar

  return (
    <WebView
      ref={webRef}
      source={{ html: LEAFLET_HTML }}
      style={[styles.map, props.style]}
      javaScriptEnabled
      domStorageEnabled
      scrollEnabled={false}
      bounces={false}
      showsHorizontalScrollIndicator={false}
      showsVerticalScrollIndicator={false}
      onLoadEnd={onLoadEnd}
      onMessage={(event) => {
        try {
          const data = JSON.parse(event.nativeEvent.data);
          if (data.type === 'press' && props.onPress) {
            props.onPress({ latitude: data.lat, longitude: data.lng });
          }
        } catch { /* silencioso */ }
      }}
    />
  );
});

LeafletMap.displayName = 'LeafletMap';

const styles = StyleSheet.create({
  map: { flex: 1 },
});

export default LeafletMap;

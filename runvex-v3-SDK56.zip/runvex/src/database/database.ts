import * as SQLite from 'expo-sqlite';

let db: SQLite.SQLiteDatabase | null = null;

export async function getDatabase(): Promise<SQLite.SQLiteDatabase> {
  if (!db) {
    db = await SQLite.openDatabaseAsync('runvex.db');
    await initDB(db);
  }
  return db;
}

async function initDB(d: SQLite.SQLiteDatabase) {
  await d.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS usuarios (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre      TEXT NOT NULL,
      apellidos   TEXT NOT NULL,
      correo      TEXT UNIQUE NOT NULL,
      usuario     TEXT UNIQUE NOT NULL,
      contrasena  TEXT NOT NULL,
      racha       INTEGER DEFAULT 0,
      foto_perfil TEXT,
      fecha_registro TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS carreras (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id        INTEGER NOT NULL,
      fecha             TEXT DEFAULT (datetime('now')),
      distancia_km      REAL NOT NULL DEFAULT 0,
      tiempo_segundos   INTEGER NOT NULL DEFAULT 0,
      velocidad_promedio REAL DEFAULT 0,
      calorias          INTEGER DEFAULT 0,
      pasos             INTEGER DEFAULT 0,
      bpm_promedio      INTEGER DEFAULT 0,
      bpm_maximo        INTEGER DEFAULT 0,
      elevacion_m       REAL DEFAULT 0,
      ruta_json         TEXT,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS rutas_guardadas (
      id                  INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id          INTEGER NOT NULL,
      nombre              TEXT NOT NULL,
      distancia_km        REAL NOT NULL,
      tiempo_estimado_min INTEGER NOT NULL,
      coordenadas_json    TEXT NOT NULL,
      fecha_creacion      TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sesion_activa (
      id         INTEGER PRIMARY KEY CHECK (id = 1),
      usuario_id INTEGER,
      token      TEXT,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
    );
  `);
}

// ─── AUTH ────────────────────────────────────────────────────
export async function crearUsuario(
  nombre: string, apellidos: string, correo: string,
  usuario: string, contrasena: string
): Promise<number> {
  const d = await getDatabase();
  const r = await d.runAsync(
    `INSERT INTO usuarios (nombre,apellidos,correo,usuario,contrasena) VALUES (?,?,?,?,?)`,
    [nombre, apellidos, correo, usuario, contrasena]
  );
  return r.lastInsertRowId;
}

export async function loginUsuario(usuario: string, contrasena: string): Promise<any | null> {
  const d = await getDatabase();
  const row = await d.getFirstAsync<any>(
    `SELECT * FROM usuarios WHERE (usuario=? OR correo=?) AND contrasena=?`,
    [usuario, usuario, contrasena]
  );
  if (row) {
    await d.runAsync(
      `INSERT OR REPLACE INTO sesion_activa (id,usuario_id,token) VALUES (1,?,?)`,
      [row.id, `tk_${Date.now()}`]
    );
    await d.runAsync(`UPDATE usuarios SET fecha_registro=datetime('now') WHERE id=?`, [row.id]);
  }
  return row;
}

export async function obtenerSesionActiva(): Promise<any | null> {
  const d = await getDatabase();
  return d.getFirstAsync<any>(
    `SELECT u.* FROM sesion_activa s JOIN usuarios u ON s.usuario_id=u.id WHERE s.id=1`
  );
}

export async function cerrarSesion(): Promise<void> {
  const d = await getDatabase();
  await d.runAsync(`DELETE FROM sesion_activa WHERE id=1`);
}

export async function actualizarUsuario(
  id: number,
  datos: Partial<{ nombre:string; apellidos:string; correo:string; usuario:string; foto_perfil:string }>
): Promise<void> {
  const d = await getDatabase();
  const cols = Object.keys(datos).map(k => `${k}=?`).join(',');
  await d.runAsync(`UPDATE usuarios SET ${cols} WHERE id=?`, [...Object.values(datos), id]);
}

export async function actualizarRacha(id: number, racha: number): Promise<void> {
  const d = await getDatabase();
  await d.runAsync(`UPDATE usuarios SET racha=? WHERE id=?`, [racha, id]);
}

// ─── CARRERAS ────────────────────────────────────────────────
export interface Carrera {
  usuario_id: number; distancia_km: number; tiempo_segundos: number;
  velocidad_promedio: number; calorias: number; pasos: number;
  bpm_promedio: number; bpm_maximo: number; elevacion_m: number; ruta_json: string;
}

export async function guardarCarrera(c: Carrera): Promise<number> {
  const d = await getDatabase();
  const r = await d.runAsync(
    `INSERT INTO carreras
     (usuario_id,distancia_km,tiempo_segundos,velocidad_promedio,
      calorias,pasos,bpm_promedio,bpm_maximo,elevacion_m,ruta_json)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    [c.usuario_id,c.distancia_km,c.tiempo_segundos,c.velocidad_promedio,
     c.calorias,c.pasos,c.bpm_promedio,c.bpm_maximo,c.elevacion_m,c.ruta_json]
  );
  return r.lastInsertRowId;
}

export async function obtenerCarrerasUsuario(uid: number): Promise<any[]> {
  const d = await getDatabase();
  return d.getAllAsync<any>(`SELECT * FROM carreras WHERE usuario_id=? ORDER BY fecha DESC`, [uid]);
}

export async function obtenerUltimaCarrera(uid: number): Promise<any | null> {
  const d = await getDatabase();
  return d.getFirstAsync<any>(
    `SELECT * FROM carreras WHERE usuario_id=? ORDER BY fecha DESC LIMIT 1`, [uid]
  );
}

// ─── RUTAS ────────────────────────────────────────────────────
export async function guardarRuta(
  uid: number, nombre: string, distKm: number, minEst: number, coords: any[]
): Promise<number> {
  const d = await getDatabase();
  const r = await d.runAsync(
    `INSERT INTO rutas_guardadas (usuario_id,nombre,distancia_km,tiempo_estimado_min,coordenadas_json)
     VALUES (?,?,?,?,?)`,
    [uid, nombre, distKm, minEst, JSON.stringify(coords)]
  );
  return r.lastInsertRowId;
}

export async function obtenerRutasUsuario(uid: number): Promise<any[]> {
  const d = await getDatabase();
  return d.getAllAsync<any>(
    `SELECT * FROM rutas_guardadas WHERE usuario_id=? ORDER BY fecha_creacion DESC`, [uid]
  );
}
